"""Tests for the ML Academy code.   Run from the ml-academy-code folder:   pytest -q

* test_lessons     — every lesson script runs and prints the same output as when the course was published
                     (numbers may differ by tiny rounding; library updates can change them — see tests/expected/).
* test_projects    — every project solution runs and all its checks pass.
* test_challenges  — every challenge solution produces the expected answer, and every starter does not (yet).
"""
import os, re, subprocess, sys, pathlib, pytest
ROOT = pathlib.Path(__file__).resolve().parent.parent
NUM = re.compile(r"[-+]?(?:\d+\.\d*|\.\d+|\d+)(?:[eE][-+]?\d+)?")
ENV = dict(os.environ, MPLBACKEND="Agg", PYTHONIOENCODING="utf-8", PYTHONWARNINGS="ignore")

def run(path):
    return subprocess.run([sys.executable, str(path)], cwd=path.parent, env=ENV, capture_output=True, text=True, encoding="utf-8", timeout=900)

def same(a, b, tol=1e-6):
    ta, tb = a.split(), b.split()
    if len(ta) != len(tb): return False
    for x, y in zip(ta, tb):
        if x == y: continue
        nx, ny = NUM.findall(x), NUM.findall(y)
        if NUM.sub("#", x) != NUM.sub("#", y) or len(nx) != len(ny): return False
        if any(abs(float(p) - float(q)) > max(tol * max(abs(float(p)), abs(float(q))), 1e-9) for p, q in zip(nx, ny)): return False
    return True

@pytest.mark.parametrize("script", sorted((ROOT / "lessons").glob("lesson-??.py")), ids=lambda p: p.name)
def test_lessons(script):
    r = run(script)
    assert r.returncode == 0, r.stderr[-2000:]
    expected = (ROOT / "tests" / "expected" / (script.stem + ".txt")).read_text(encoding="utf-8")
    assert same(r.stdout, expected), "output changed — compare with tests/expected/" + script.stem + ".txt\n" + r.stdout[-2000:]

@pytest.mark.parametrize("script", sorted((ROOT / "projects").glob("*-solution.py")), ids=lambda p: p.name)
def test_projects(script):
    r = run(script)
    assert r.returncode == 0, r.stderr[-2000:]
    assert "Not yet" not in r.stdout and "✅" in r.stdout, r.stdout[-2000:]

SOLUTIONS = [
    (0, 1, 'prices = [58, 82, 55, 88, 96]\ntotal = 0\nfor p in prices:\n    total = total + p\naverage = total / len(prices)', 'average', 75.8),
    (0, 2, 'import pandas as pd\ndf = pd.read_csv(DATA / "houses.csv")\ncentral = df[df["area"] == "Central"]\nn_central = len(central)', 'n_central', 4),
    (1, 1, 'import numpy as np\ny = np.array([3.0, 5.0, 7.0, 9.0])\ny_hat = np.array([2.5, 5.0, 8.0, 8.0])\nmse = np.mean((y_hat - y) ** 2)', 'mse', 0.5625),
    (1, 2, 'import numpy as np\nx = np.array([0, 1, 2, 3, 4])\ny_hat = 2 * x + 1', 'y_hat', [1, 3, 5, 7, 9]),
    (2, 1, 'import numpy as np\na = np.array([1.0, 2.0, 2.0])\nb = np.array([2.0, 0.0, 1.0])\ncos_sim = a @ b / (np.linalg.norm(a) * np.linalg.norm(b))', 'cos_sim', 0.5962847939999439),
    (2, 2, 'import numpy as np\nX = np.array([[1, 2], [3, 4], [5, 6]])\nw = np.array([0.5, -1.0])\npreds = X @ w', 'preds', [-1.5, -2.5, -3.5]),
    (3, 1, 'def f(x):\n    return x ** 2\nh = 1e-6\nslope = (f(3 + h) - f(3)) / h', 'slope', 6.000001000927568),
    (3, 2, 'w, lr = 0.0, 0.25\ngrad = 2 * (w - 4)\nw_new = w - lr * grad', 'w_new', 2.0),
    (4, 1, 'import numpy as np\nx = np.array([2, 4, 4, 4, 5, 5, 7, 9])\nm = x.mean()\nsd = np.sqrt(np.mean((x - m) ** 2))', 'sd', 2.0),
    (4, 2, 'p_d, p_pos_d, p_pos_h = 0.01, 0.90, 0.05\np_pos = p_pos_d * p_d + p_pos_h * (1 - p_d)\nposterior = p_pos_d * p_d / p_pos', 'posterior', 0.15384615384615385),
    (5, 1, 'import numpy as np\nfrom sklearn.model_selection import train_test_split\nX = np.arange(80).reshape(40, 2); y = np.arange(40) % 2\nX_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, random_state=0)\nn_test = len(X_test)', 'n_test', 10),
    (5, 2, 'from sklearn.datasets import load_iris\nfrom sklearn.linear_model import LogisticRegression\nfrom sklearn.model_selection import cross_val_score\nX, y = load_iris(return_X_y=True)\nscores = cross_val_score(LogisticRegression(max_iter=1000), X, y, cv=5)\nmean_acc = scores.mean()', 'mean_acc', 0.9733333333333334),
    (6, 1, 'import numpy as np\nx = np.array([1, 2, 3, 4, 5.0]); y = np.array([2, 4, 5, 4, 5.0])\nxm, ym = x.mean(), y.mean()\nw = np.sum((x - xm) * (y - ym)) / np.sum((x - xm) ** 2)', 'w', 0.6),
    (6, 2, 'import numpy as np\nx = np.array([1, 2, 3, 4, 5.0]); y = np.array([2, 4, 5, 4, 5.0])\ny_hat = 0.6 * x + 2.2\nss_res = np.sum((y - y_hat) ** 2)\nss_tot = np.sum((y - y.mean()) ** 2)\nr2 = 1 - ss_res / ss_tot', 'r2', 0.6000000000000001),
    (7, 1, 'import numpy as np\nx = np.array([1, 2, 3, 4, 5.0]); y = np.array([2, 4, 5, 4, 5.0])\nw, b = 0.0, 0.0\nerr = w * x + b - y\ngrad_w = 2 * np.mean(err * x)', 'grad_w', -26.4),
    (7, 2, 'import numpy as np\nx = np.array([1, 2, 3, 4, 5.0]); y = np.array([2, 4, 5, 4, 5.0])\nw, b, lr = 0.0, 0.0, 0.05\nfor step in range(1000):\n    err = w * x + b - y\n    grad_w, grad_b = 2 * np.mean(err * x), 2 * np.mean(err)\n    w = w - lr * grad_w\n    b = b - lr * grad_b\nw_final = w', 'w_final', 0.6000000206173624),
    (8, 1, 'import numpy as np\nz = np.array([-2.0, 0.0, 1.5])\np = 1 / (1 + np.exp(-z))', 'p', [0.11920292202211755, 0.5, 0.8175744761936437]),
    (8, 2, 'import numpy as np\ny = np.array([1, 0, 1, 0])\np = np.array([0.9, 0.2, 0.6, 0.4])\nloss = -np.mean(y * np.log(p) + (1 - y) * np.log(1 - p))', 'loss', 0.3375388286260044),
    (9, 1, 'tp, fp, fn, tn = 40, 10, 20, 130\nprecision = tp / (tp + fp)', 'precision', 0.8),
    (9, 2, 'precision, recall = 0.8, 2 / 3\nf1 = 2 * precision * recall / (precision + recall)', 'f1', 0.7272727272727272),
    (10, 1, 'sum_xy, sum_xx, lam = 50.0, 20.0, 5.0\nw = sum_xy / (sum_xx + lam)', 'w', 2.0),
    (10, 2, 'import numpy as np\nfrom sklearn.datasets import load_diabetes\nfrom sklearn.linear_model import Lasso\nX, y = load_diabetes(return_X_y=True)\nmodel = Lasso(alpha=1.0).fit(X, y)\nn_zero = int(np.sum(model.coef_ == 0))', 'n_zero', 7),
    (11, 1, 'import numpy as np\nX = np.array([[0, 0], [1, 1], [4, 4], [5, 4], [1, 4.0]])\nq = np.array([2, 1.0])\nd = np.sqrt(((X - q) ** 2).sum(axis=1))', 'd', [2.23606797749979, 1.0, 3.605551275463989, 4.242640687119285, 3.1622776601683795]),
    (11, 2, 'import numpy as np\nd = np.array([2.24, 1.0, 3.61, 4.24, 3.16])\nnearest = np.argsort(d)[:3]', 'nearest', [1, 0, 4]),
    (12, 1, 'count, total_words, vocab_size = 3, 200, 100\np_word = (count + 1) / (total_words + vocab_size)', 'p_word', 0.013333333333333334),
    (12, 2, 'import numpy as np\nprior = 0.4\nlikelihoods = np.array([0.02, 0.15, 0.003])\nlog_score = np.log(prior) + np.sum(np.log(likelihoods))', 'log_score', -12.53457671250221),
    (13, 1, 'import numpy as np\ncounts = np.array([3, 1])\np = counts / counts.sum()\ngini = 1 - np.sum(p ** 2)', 'gini', 0.375),
    (13, 2, 'n_left, g_left = 5, 0.32\nn_right, g_right = 5, 0.32\nweighted = (n_left * g_left + n_right * g_right) / (n_left + n_right)', 'weighted', 0.32),
    (14, 1, 'p = 0.7\nvote = p ** 3 + 3 * p ** 2 * (1 - p)', 'vote', 0.7839999999999999),
    (14, 2, 'import numpy as np\nrng = np.random.default_rng(0)\nn = 1000\nidx = rng.integers(0, n, size=n)\nshare_unique = len(np.unique(idx)) / n', 'share_unique', 0.622),
    (15, 1, 'import numpy as np\nw = np.array([3.0, 4.0])\nmargin = 2 / np.linalg.norm(w)', 'margin', 0.4),
    (15, 2, 'import numpy as np\ny = np.array([1, -1, 1, -1])\ns = np.array([2.0, -0.5, 0.3, 1.0])\nhinge = np.mean(np.maximum(0, 1 - y * s))', 'hinge', 0.8),
    (16, 1, 'import numpy as np\nx = np.array([1, 2, 6, 7, 8.0])\ncentroids = np.array([1.0, 8.0])\nlabels = np.argmin(np.abs(x[:, None] - centroids[None, :]), axis=1)', 'labels', [0, 0, 1, 1, 1]),
    (16, 2, 'import numpy as np\nx = np.array([1, 2, 6, 7, 8.0])\nlabels = np.array([0, 0, 1, 1, 1])\nnew_centroids = np.array([x[labels == k].mean() for k in range(2)])', 'new_centroids', [1.5, 7.0]),
    (17, 1, 'import numpy as np\nX = np.array([[2, 0], [0, 2], [4, 4.0]])\nXc = X - X.mean(axis=0)', 'Xc', [[0.0, -2.0], [-2.0, 0.0], [2.0, 2.0]]),
    (17, 2, 'import numpy as np\neigenvalues = np.array([8.0, 4.0, 2.0, 1.0, 1.0])\nratio = eigenvalues / eigenvalues.sum()', 'ratio', [0.5, 0.25, 0.125, 0.0625, 0.0625]),
    (18, 1, 'import numpy as np\nz = np.array([-2.0, 0.0, 3.5])\nh = np.maximum(0, z)', 'h', [0.0, 0.0, 3.5]),
    (18, 2, 'import numpy as np\nsigmoid = lambda z: 1 / (1 + np.exp(-z))\nx = np.array([1.0, 0.0])\nW = np.array([[0.5, 0.3], [-0.5, 0.8]])\nv = np.array([1.0, -1.0])\nh = sigmoid(W @ x)\np = sigmoid(v @ h)', 'p', 0.5609254179424822),
    (19, 1, 'n, k, p, s = 32, 5, 2, 1\nout = (n - k + 2 * p) // s + 1', 'out', 32),
    (19, 2, 'import numpy as np\nscores = np.array([2.0, 0.0, 1.0])\nweights = np.exp(scores) / np.exp(scores).sum()', 'weights', [0.6652409557748219, 0.09003057317038046, 0.24472847105479764]),
    (20, 1, 'import numpy as np\ntrain = np.array([10.0, 20.0, 30.0])\nnew = 40.0\nz = (new - train.mean()) / train.std()', 'z', 2.449489742783178),
    (20, 2, 'import pandas as pd\ndf = pd.DataFrame({"colour": ["red", "green", "blue", "green"]})\nonehot = pd.get_dummies(df["colour"])\nn_cols = onehot.shape[1]', 'n_cols', 3),
    (21, 1, 'import pandas as pd\ndf = pd.DataFrame({"group": ["A", "A", "A", "A", "B", "B", "B", "B"], "approved": [1, 1, 0, 1, 0, 1, 0, 0]})\nrates = df.groupby("group")["approved"].mean()\nratio = round(rates.min() / rates.max(), 3)', 'ratio', 0.333),
    (21, 2, 'import numpy as np\nrepay = np.array([1, 1, 1, 1, 0, 0, 0, 0, 0, 0])\napprove = np.array([1, 1, 1, 0, 1, 0, 0, 0, 0, 0])\ntpr = (approve[repay == 1] == 1).mean()', 'tpr', 0.75),
    (22, 1, 'import sqlite3\nimport pandas as pd\ncon = sqlite3.connect(":memory:")\npd.DataFrame({"area": ["A", "A", "B", "B", "B"], "price": [10, 20, 30, 40, 50]}).to_sql("t", con, index=False)\nq = "SELECT area, AVG(price) AS avg_price FROM t GROUP BY area ORDER BY area"\nresult = pd.read_sql(q, con)["avg_price"].round(2).tolist()', 'result', [15.0, 40.0]),
    (22, 2, 'import pandas as pd\ncustomers = pd.DataFrame({"id": [1, 2, 3, 4]})\norders = pd.DataFrame({"customer_id": [1, 1, 3]})\ncounts = orders.groupby("customer_id").size().rename("n").reset_index()\nmerged = customers.merge(counts, left_on="id", right_on="customer_id", how="left").fillna({"n": 0})\nresult = merged["n"].tolist()', 'result', [2.0, 0.0, 1.0, 0.0]),
    (23, 1, 'grid = {"C": [0.1, 1, 10], "gamma": [0.01, 0.1, 1, 10], "kernel": ["rbf", "sigmoid"]}\nfolds = 5\nfits = len(grid["C"]) * len(grid["gamma"]) * len(grid["kernel"]) * folds', 'fits', 120),
    (23, 2, 'import numpy as np\nrates = np.logspace(-3, 0, 5)\nresult = [round(float(v), 4) for v in rates]', 'result', [0.001, 0.0056, 0.0316, 0.1778, 1.0]),
    (24, 1, 'import numpy as np\nrng = np.random.default_rng(0)\nX = rng.normal(size=(500, 2)); y = 3 * X[:, 0] + 0.1 * rng.normal(size=500)\nw = np.array([3.0, 0.0])\nscore = lambda X: -np.mean((X @ w - y) ** 2)\nXp = X.copy(); Xp[:, 0] = rng.permutation(Xp[:, 0])\ndrop = score(X) - score(Xp)\nresult = round(float(drop), 1)', 'result', 17.3),
    (24, 2, 'f = lambda a, b: 2 * a + 4 * a * b\nphi_a = ((f(1, 0) - f(0, 0)) + (f(1, 1) - f(0, 1))) / 2', 'phi_a', 4.0),
    (25, 1, 'flagged, true_in_flagged, total_anomalies = 30, 12, 20\nrecall = true_in_flagged / total_anomalies', 'recall', 0.6),
    (25, 2, 'import numpy as np\nx = np.array([10, 11, 9, 10, 12, 30, 10, 11])\nz = (x - x.mean()) / x.std()\nflags = np.abs(z) > 2\nresult = x[flags].tolist()', 'result', [30]),
    (26, 1, 'import numpy as np\ny = np.array([50, 52, 49, 70, 75, 51, 53, 54, 51, 50, 72, 78, 50, 55])\nactual = y[7:]\nforecast = y[:7]\nresult = round(float(np.mean(np.abs(actual - forecast))), 2)', 'result', 2.0),
    (26, 2, 'import pandas as pd\ns = pd.Series([10, 12, 14, 16, 18])\nroll = s.shift(1).rolling(3).mean()\nresult = roll.tolist()[3:]', 'result', [12.0, 14.0]),
    (27, 1, 'mu, item_avg, user_avg = 3.5, 4.2, 3.1\npred = mu + (item_avg - mu) + (user_avg - mu)', 'pred', 3.8000000000000003),
    (27, 2, 'recommended = [4, 9, 1, 7, 3]\nliked = {1, 2, 3, 8}\nresult = len(set(recommended) & liked) / 5', 'result', 0.4),
    (28, 1, 'a, b = 2, 2\ns, f = 7, 3\nmean = (a + s) / (a + s + b + f)', 'mean', 0.6428571428571429),
    (28, 2, 'current, proposal = 0.25, 0.05\naccept = min(1, proposal / current)', 'accept', 0.2)
]

@pytest.mark.parametrize("lesson,k,code,name,want", SOLUTIONS, ids=[f"lesson{s[0]}-challenge{s[1]}" for s in SOLUTIONS])
def test_challenges(lesson, k, code, name, want):
    import numpy as np, contextlib, io
    cwd = os.getcwd(); os.chdir(ROOT / "lessons")
    try:
        ns = {"DATA": ROOT / "data"}
        with contextlib.redirect_stdout(io.StringIO()): exec(code, ns)
    finally: os.chdir(cwd)
    got = ns[name]
    assert np.shape(got) == np.shape(want) and np.allclose(np.asarray(got, dtype=float), np.asarray(want, dtype=float), rtol=1e-4, atol=1e-6)

@pytest.mark.parametrize("script", sorted((ROOT / "challenges").glob("*.py")), ids=lambda p: p.name)
def test_challenge_starters_are_unsolved(script):
    r = run(script)
    assert "Not yet" in r.stdout or r.returncode != 0
