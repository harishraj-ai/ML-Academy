"""Lesson 19: Deep Learning Architectures — all the code from the lesson, as one script.

Part of the ML Academy course. Run it with:  python lesson-19.py
(works from any folder; the data is read from ../data/)
"""
from pathlib import Path
DATA = Path(__file__).resolve().parent.parent / "data"   # the course's data folder

##############################################################################
# 9. In Python
##############################################################################
import numpy as np

def conv2d(image, kernel):
    kh, kw = kernel.shape
    out = np.zeros((image.shape[0] - kh + 1, image.shape[1] - kw + 1))
    for i in range(out.shape[0]):
        for j in range(out.shape[1]):
            out[i, j] = np.sum(image[i:i+kh, j:j+kw] * kernel)
    return out

image = np.array([[0, 0, 0, 9, 9, 9]] * 4, dtype=float)
edge = np.array([[-1, 0, 1]] * 3, dtype=float)
print(conv2d(image, edge))

fmap = np.array([[1, 3, 2, 0], [4, 6, 1, 1], [0, 2, 5, 7], [1, 1, 3, 2]], dtype=float)
print(fmap.reshape(2, 2, 2, 2).max(axis=(1, 3)))      # 2x2 max pooling

def attention(Q, K, V):
    scores = Q @ K.T / np.sqrt(K.shape[1])
    weights = np.exp(scores) / np.exp(scores).sum(axis=1, keepdims=True)   # softmax per row
    return weights, weights @ V

Q = K = np.array([[1, 0], [0, 1], [1, 1]], dtype=float)
V = np.array([[1, 0], [0, 1], [0.5, 0.5]])
weights, out = attention(Q, K, V)
print(weights.round(3))
print(out.round(3))
# (The PyTorch example for this section is in lesson-19-pytorch.py — it needs PyTorch installed.)

##############################################################################
# 12. Going deeper: attention and residual connections, from scratch
##############################################################################
import numpy as np

# Scaled dot-product attention from scratch, for a "sentence" of 4 tokens with 8-number vectors
rng = np.random.default_rng(0)
X = rng.normal(size=(4, 8))                                    # one row per token
Wq, Wk, Wv = (rng.normal(0, 1 / np.sqrt(8), size=(8, 8)) for _ in range(3))
Q, K, V = X @ Wq, X @ Wk, X @ Wv

def softmax(s):
    e = np.exp(s - s.max(axis=-1, keepdims=True))
    return e / e.sum(axis=-1, keepdims=True)

A = softmax(Q @ K.T / np.sqrt(8))                              # attention weights, one row per token
out = A @ V                                                    # each output mixes the value vectors
print("attention weights (row i: how much token i looks at each token):")
print(A.round(2))
print("each row sums to:", A.sum(axis=1).round(3), "  output shape:", out.shape)
# Why divide by sqrt(d)? Dot products of random vectors grow with d, making softmax nearly one-hot
for d in [8, 64, 512]:
    q, k = rng.normal(size=(1000, d)), rng.normal(size=(1000, 10, d))
    raw = np.einsum("nd,nkd->nk", q, k)
    top_raw = softmax(raw).max(axis=1).mean()
    top_scaled = softmax(raw / np.sqrt(d)).max(axis=1).mean()
    print(f"d {d:3d}: spread of dot products {raw.std():6.1f}   average top weight, unscaled {top_raw:.2f}, scaled {top_scaled:.2f}")
# Residual connections: gradient reaching the first of 50 layers, with and without a shortcut h + f(h)
def first_layer_grad(residual, depth=50, width=64):
    W = [rng.normal(0, 0.5 / np.sqrt(width), size=(width, width)) for _ in range(depth)]   # small weights
    h = rng.normal(size=(32, width)); zs = []
    for Wl in W:
        z = h @ Wl; zs.append(z)
        h = h + np.tanh(z) if residual else np.tanh(z)
    g = np.ones_like(h)
    for Wl, z in zip(reversed(W), reversed(zs)):
        local = (g * (1 - np.tanh(z) ** 2)) @ Wl.T              # gradient through the layer itself
        g = g + local if residual else local                    # the shortcut adds an identity path
    return np.linalg.norm(g)

print("plain 50-layer network, gradient at layer 1:   ", f"{first_layer_grad(False):.2e}")
print("residual 50-layer network, gradient at layer 1:", f"{first_layer_grad(True):.2e}")

##############################################################################
# Running example: Chennai Homes
#
# The same 12-house dataset used in every lesson (data/houses.csv in the course folder).
##############################################################################
import pandas as pd
import numpy as np
df = pd.read_csv(DATA / "houses.csv")
# A Transformer would read the listing text word by word; here we just look at what it would see.
for d in df["description"].head(3):
    tokens = d.split()
    print(len(tokens), "tokens:", tokens)
print("vocabulary size:", len({w for d in df["description"] for w in d.split()}))
