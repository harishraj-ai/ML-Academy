"""Lesson 19: Deep Learning Architectures — all the code from the lesson, as one script.

Part of the ML Academy course. Run it with:  python lesson-19.py
(works from any folder; the data is read from ../data/)
"""
from pathlib import Path
DATA = Path(__file__).resolve().parent.parent / "data"   # the course's data folder

##############################################################################
# 9. In Python
##############################################################################
import numpy as np

def conv2d(image, kernel):
    kh, kw = kernel.shape
    out = np.zeros((image.shape[0] - kh + 1, image.shape[1] - kw + 1))
    for i in range(out.shape[0]):
        for j in range(out.shape[1]):
            out[i, j] = np.sum(image[i:i+kh, j:j+kw] * kernel)
    return out

image = np.array([[0, 0, 0, 9, 9, 9]] * 4, dtype=float)
edge = np.array([[-1, 0, 1]] * 3, dtype=float)
print(conv2d(image, edge))

fmap = np.array([[1, 3, 2, 0], [4, 6, 1, 1], [0, 2, 5, 7], [1, 1, 3, 2]], dtype=float)
print(fmap.reshape(2, 2, 2, 2).max(axis=(1, 3)))      # 2x2 max pooling

def attention(Q, K, V):
    scores = Q @ K.T / np.sqrt(K.shape[1])
    weights = np.exp(scores) / np.exp(scores).sum(axis=1, keepdims=True)   # softmax per row
    return weights, weights @ V

Q = K = np.array([[1, 0], [0, 1], [1, 1]], dtype=float)
V = np.array([[1, 0], [0, 1], [0.5, 0.5]])
weights, out = attention(Q, K, V)
print(weights.round(3))
print(out.round(3))
# (The PyTorch example for this section is in lesson-19-pytorch.py — it needs PyTorch installed.)

##############################################################################
# Running example: Chennai Homes
#
# The same 12-house dataset used in every lesson (data/houses.csv in the course folder).
##############################################################################
import pandas as pd
import numpy as np
df = pd.read_csv(DATA / "houses.csv")
# A Transformer would read the listing text word by word; here we just look at what it would see.
for d in df["description"].head(3):
    tokens = d.split()
    print(len(tokens), "tokens:", tokens)
print("vocabulary size:", len({w for d in df["description"] for w in d.split()}))
