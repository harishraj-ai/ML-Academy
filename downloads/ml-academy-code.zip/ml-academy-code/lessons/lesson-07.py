"""Lesson 7: Gradient Descent — all the code from the lesson, as one script.

Part of the ML Academy course. Run it with:  python lesson-07.py
(works from any folder; the data is read from ../data/)
"""
from pathlib import Path
DATA = Path(__file__).resolve().parent.parent / "data"   # the course's data folder

##############################################################################
# 11. In Python
##############################################################################
import numpy as np

x = np.array([1, 2, 3, 4, 5], dtype=float)
y = np.array([2, 4, 5, 4, 5], dtype=float)

w, b = 0.0, 0.0
lr = 0.05
for step in range(1000):
    y_hat = w * x + b
    error = y_hat - y
    grad_w = 2 * np.mean(error * x)     # dL/dw
    grad_b = 2 * np.mean(error)         # dL/db
    w -= lr * grad_w
    b -= lr * grad_b
    if step in (0, 9, 99, 999):
        print(step + 1, round(w, 3), round(b, 3), round(np.mean((w * x + b - y) ** 2), 3))
from sklearn.datasets import load_diabetes
from sklearn.model_selection import train_test_split
from sklearn.linear_model import SGDRegressor
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline

X, y = load_diabetes(return_X_y=True)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

model = make_pipeline(StandardScaler(),
                      SGDRegressor(learning_rate="invscaling", eta0=0.01, max_iter=1000, random_state=0))
model.fit(X_train, y_train)
print(round(model.score(X_test, y_test), 3))     # R² on the test set

##############################################################################
# Running example: Chennai Homes
#
# The same 12-house dataset used in every lesson (data/houses.csv in the course folder).
##############################################################################
import pandas as pd
import numpy as np
df = pd.read_csv(DATA / "houses.csv")
x = df["size_m2"].to_numpy(); y = df["price_lakh"].to_numpy()
xs = (x - x.mean()) / x.std()            # standardise so one learning rate suits both parameters
w, b, lr = 0.0, 0.0, 0.1
for step in range(200):
    err = w * xs + b - y
    w -= lr * 2 * np.mean(err * xs)
    b -= lr * 2 * np.mean(err)
print("in standardised units: w =", round(w, 3), " b =", round(b, 3))
print("back in m2: slope =", round(w / x.std(), 3), " intercept =", round(b - w * x.mean() / x.std(), 2))
