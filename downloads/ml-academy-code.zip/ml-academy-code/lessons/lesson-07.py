"""Lesson 7: Gradient Descent — all the code from the lesson, as one script.

Part of the ML Academy course. Run it with:  python lesson-07.py
(works from any folder; the data is read from ../data/)
"""
from pathlib import Path
DATA = Path(__file__).resolve().parent.parent / "data"   # the course's data folder

##############################################################################
# 11. In Python
##############################################################################
import numpy as np

x = np.array([1, 2, 3, 4, 5], dtype=float)
y = np.array([2, 4, 5, 4, 5], dtype=float)

w, b = 0.0, 0.0
lr = 0.05
for step in range(1000):
    y_hat = w * x + b
    error = y_hat - y
    grad_w = 2 * np.mean(error * x)     # dL/dw
    grad_b = 2 * np.mean(error)         # dL/db
    w -= lr * grad_w
    b -= lr * grad_b
    if step in (0, 9, 99, 999):
        print(step + 1, round(w, 3), round(b, 3), round(np.mean((w * x + b - y) ** 2), 3))
from sklearn.datasets import load_diabetes
from sklearn.model_selection import train_test_split
from sklearn.linear_model import SGDRegressor
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline

X, y = load_diabetes(return_X_y=True)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

model = make_pipeline(StandardScaler(),
                      SGDRegressor(learning_rate="invscaling", eta0=0.01, max_iter=1000, random_state=0))
model.fit(X_train, y_train)
print(round(model.score(X_test, y_test), 3))     # R² on the test set

##############################################################################
# 14. Going deeper: modern optimisers and learning-rate schedules
##############################################################################
import numpy as np

def run(update, grad, start, steps=20000, tol=1e-3):
    """Steps until w is within tol of the minimum at (0, 0)."""
    w, state = np.array(start, dtype=float), {}
    for k in range(1, steps + 1):
        w = update(w, grad(w), state, k)
        if np.linalg.norm(w) < tol: return k
    return None

def plain(lr):
    return lambda w, g, s, k: w - lr * g

def momentum(lr, beta):
    def step(w, g, s, k):
        s["v"] = beta * s.get("v", 0) + g                  # a running "velocity"
        return w - lr * s["v"]
    return step

def adam(lr, b1=0.9, b2=0.999, eps=1e-8):
    def step(w, g, s, k):
        s["m"] = b1 * s.get("m", 0) + (1 - b1) * g         # average gradient
        s["v"] = b2 * s.get("v", 0) + (1 - b2) * g**2      # average squared gradient
        m_hat, v_hat = s["m"] / (1 - b1**k), s["v"] / (1 - b2**k)   # bias correction
        return w - lr * m_hat / (np.sqrt(v_hat) + eps)
    return step

valleys = {"narrow (curvatures 2 and 20)":     (lambda w: np.array([2 * w[0], 20 * w[1]]), 20),
           "very narrow (curvatures 2 and 2000)": (lambda w: np.array([2 * w[0], 2000 * w[1]]), 2000)}
for name, (g, top) in valleys.items():
    lr = 1.8 / top                                         # just under the stability limit 2 / top
    print(name)
    print(f"  plain gradient descent: {run(plain(lr), g, [10, 1])} steps")
    print(f"  momentum (beta 0.3):    {run(momentum(lr * 1.2, 0.3), g, [10, 1])} steps")
    print(f"  Adam (lr 0.1):          {run(adam(0.1), g, [10, 1])} steps")
from sklearn.datasets import load_diabetes

# Mini-batch SGD on the diabetes data: constant learning rate vs a decaying schedule
Xd, yd = load_diabetes(return_X_y=True)
Xd = (Xd - Xd.mean(0)) / Xd.std(0); yd = (yd - yd.mean()) / yd.std()
w_best = np.linalg.lstsq(Xd, yd, rcond=None)[0]
best = np.mean((Xd @ w_best - yd) ** 2)

def sgd(schedule, epochs=60, batch=16, seed=0):
    rng = np.random.default_rng(seed); w = np.zeros(10); step = 0; tail = []
    for ep in range(epochs):
        for idx in np.array_split(rng.permutation(len(yd)), len(yd) // batch):
            g = 2 * Xd[idx].T @ (Xd[idx] @ w - yd[idx]) / len(idx)
            w -= schedule(step) * g; step += 1
        if ep >= epochs - 10: tail.append(np.mean((Xd @ w - yd) ** 2))
    return np.mean(tail) - best, np.std(tail)

for name, sch in [("constant 0.05", lambda t: 0.05),
                  ("decay 0.05/(1 + t/200)", lambda t: 0.05 / (1 + t / 200))]:
    gap, wobble = sgd(sch)
    print(f"{name:24}: extra loss above the best {gap:.4f}, wobble between epochs {wobble:.4f}")
# Gradient clipping: cap the gradient's length before stepping
def clip(g, max_norm=1.0):
    n = np.linalg.norm(g)
    return g * (max_norm / n) if n > max_norm else g

huge = np.array([300.0, -400.0])                 # an exploding gradient, length 500
print("before clipping:", huge, " length", np.linalg.norm(huge))
print("after clipping: ", clip(huge), " length", np.linalg.norm(clip(huge)))

##############################################################################
# Running example: Chennai Homes
#
# The same 12-house dataset used in every lesson (data/houses.csv in the course folder).
##############################################################################
import pandas as pd
import numpy as np
df = pd.read_csv(DATA / "houses.csv")
x = df["size_m2"].to_numpy(); y = df["price_lakh"].to_numpy()
xs = (x - x.mean()) / x.std()            # standardise so one learning rate suits both parameters
w, b, lr = 0.0, 0.0, 0.1
for step in range(200):
    err = w * xs + b - y
    w -= lr * 2 * np.mean(err * xs)
    b -= lr * 2 * np.mean(err)
print("in standardised units: w =", round(w, 3), " b =", round(b, 3))
print("back in m2: slope =", round(w / x.std(), 3), " intercept =", round(b - w * x.mean() / x.std(), 2))
