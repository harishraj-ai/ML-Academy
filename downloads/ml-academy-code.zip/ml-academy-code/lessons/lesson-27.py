"""Lesson 27: Recommender Systems — all the code from the lesson, as one script.

Part of the ML Academy course. Run it with:  python lesson-27.py
(works from any folder; the data is read from ../data/)
"""
from pathlib import Path
DATA = Path(__file__).resolve().parent.parent / "data"   # the course's data folder

##############################################################################
# 2. Explicit and implicit feedback
##############################################################################
import numpy as np
import pandas as pd

# 300 users, 60 films. Each user and film has 3 hidden "tastes"; users rate about 15% of films
rng = np.random.default_rng(0)
n_users, n_items, k = 300, 60, 3
U, V = rng.normal(size=(n_users, k)), rng.normal(size=(n_items, k))
popularity = rng.normal(0, 0.5, n_items)
true = 3.2 + U @ V.T * 0.6 + popularity + rng.normal(0, 0.4, (n_users, n_items))
R = np.clip(np.round(true), 1, 5)
mask = rng.random((n_users, n_items)) < 0.15
ratings = pd.DataFrame([(u, i, R[u, i]) for u, i in zip(*np.nonzero(mask))], columns=["user", "item", "rating"])
print(ratings.head(4).to_string(index=False))
print("ratings:", len(ratings), " share of the matrix filled:", round(mask.mean(), 3))

##############################################################################
# 3. Baselines: averages and biases
##############################################################################
# Hold out one rating per user (for evaluation) and train on the rest
test = ratings.groupby("user").sample(1, random_state=0)
train = ratings.drop(test.index)
mu = train.rating.mean()
item_mean = train.groupby("item").rating.mean()
user_bias = (train.rating - mu).groupby(train.user).mean()
rmse = lambda p: np.sqrt(np.mean((test.rating.to_numpy() - p) ** 2))
print("global mean      RMSE:", round(rmse(np.full(len(test), mu)), 3))
print("item average     RMSE:", round(rmse(test.item.map(item_mean).fillna(mu).to_numpy()), 3))
print("item + user bias RMSE:", round(rmse((test.item.map(item_mean).fillna(mu) + test.user.map(user_bias).fillna(0)).to_numpy()), 3))

##############################################################################
# 4. Collaborative filtering: neighbours
##############################################################################
# Item-item collaborative filtering: films are similar if the same users rate them alike
M = np.full((n_users, n_items), np.nan)
M[train.user, train.item] = train.rating
centred = M - np.nanmean(M, axis=1, keepdims=True)            # remove each user's personal scale
C = np.nan_to_num(centred)
norms = np.linalg.norm(C, axis=0) + 1e-9
S = (C.T @ C) / np.outer(norms, norms)                         # cosine similarity between films
np.fill_diagonal(S, 0)

def predict_item_item(u, i, k=10):
    rated = np.flatnonzero(~np.isnan(M[u]))
    top = rated[np.argsort(S[i, rated])[::-1][:k]]
    w = S[i, top]
    base = np.nanmean(M[u])
    return base + (w @ centred[u, top]) / (np.abs(w).sum() + 1e-9) if len(top) else mu

p_ii = np.array([predict_item_item(u, i) for u, i in zip(test.user, test.item)])
print("item-item CF     RMSE:", round(rmse(p_ii), 3))

##############################################################################
# 6. Matrix factorisation
##############################################################################
# Matrix factorisation with SGD: learn a vector for every user and film so that rating ≈ mu + b_u + b_i + p_u · q_i
def factorise(train, k=3, epochs=40, lr=0.02, reg=0.05, seed=0):
    g = np.random.default_rng(seed)
    P, Q = g.normal(0, 0.1, (n_users, k)), g.normal(0, 0.1, (n_items, k))
    bu, bi = np.zeros(n_users), np.zeros(n_items)
    data = train[["user", "item", "rating"]].to_numpy()
    for ep in range(epochs):
        for u, i, r in data[g.permutation(len(data))]:
            u, i = int(u), int(i)
            e = r - (mu + bu[u] + bi[i] + P[u] @ Q[i])
            bu[u] += lr * (e - reg * bu[u]); bi[i] += lr * (e - reg * bi[i])
            P[u], Q[i] = P[u] + lr * (e * Q[i] - reg * P[u]), Q[i] + lr * (e * P[u] - reg * Q[i])
    return P, Q, bu, bi

P, Q, bu, bi = factorise(train)
p_mf = mu + bu[test.user] + bi[test.item] + np.sum(P[test.user] * Q[test.item], axis=1)
print("matrix factorisation RMSE:", round(rmse(p_mf), 3))

##############################################################################
# 7. Evaluating recommendations: rankings, not ratings
##############################################################################
# Ranking quality: of the 10 unseen films we recommend, how many would the user really like (true rating 4 or 5)?
# (We can check this only because the data is simulated and we know every true rating.)
liked = R >= 4
def precision_at_10(score_fn):
    hits = []
    for u in range(n_users):
        scores = score_fn(u).astype(float).copy()
        scores[mask[u]] = -np.inf                                   # don't recommend films they've rated
        top = np.argsort(scores)[::-1][:10]
        hits.append(liked[u, top].mean())
    return np.mean(hits)

pop = train.groupby("item").rating.mean().reindex(range(n_items), fill_value=mu).to_numpy()
rand = np.random.default_rng(1)
print("precision@10, random films:          ", round(precision_at_10(lambda u: rand.random(n_items)), 3))
print("precision@10, highest-rated films:   ", round(precision_at_10(lambda u: pop), 3))
print("precision@10, matrix factorisation:  ", round(precision_at_10(lambda u: bi + Q @ P[u]), 3))

##############################################################################
# 9. In Python: content-based recommendations
##############################################################################
import numpy as np
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

df = pd.read_csv(DATA / "houses.csv")   # download it from Lesson 1
T = TfidfVectorizer().fit_transform(df["description"])
sim = cosine_similarity(T) + 0.2 * (df["area"].to_numpy()[:, None] == df["area"].to_numpy()[None, :])
np.fill_diagonal(sim, -1)                         # never recommend the house itself
viewed = 5                                         # a buyer looked at house id 5
row = df.index[df.id == viewed][0]
top = np.argsort(sim[row])[::-1][:3]
print("viewed:", df.description[row])
print(df.loc[top, ["id", "area", "description"]].to_string(index=False))

##############################################################################
# 12. Going deeper: alternating least squares and popularity bias
##############################################################################
import numpy as np
rng = np.random.default_rng(0)
n_users, n_items, k = 200, 40, 3
P_true, Q_true = rng.normal(0, 1, (n_users, k)), rng.normal(0, 1, (n_items, k))
R = P_true @ Q_true.T + rng.normal(0, 0.3, (n_users, n_items))
mask = rng.random((n_users, n_items)) < 0.2            # only 20% of ratings observed
test = (rng.random((n_users, n_items)) < 0.25) & mask
train = mask & ~test
P, Q, lam = rng.normal(0, 0.1, (n_users, k)), rng.normal(0, 0.1, (n_items, k)), 1.0
for sweep in range(1, 9):
    for u in range(n_users):                           # fix Q, solve a small ridge problem per user
        Qi = Q[train[u]]
        P[u] = np.linalg.solve(Qi.T @ Qi + lam * np.eye(k), Qi.T @ R[u, train[u]])
    for i in range(n_items):                           # fix P, solve per item
        Pu = P[train[:, i]]
        Q[i] = np.linalg.solve(Pu.T @ Pu + lam * np.eye(k), Pu.T @ R[train[:, i], i])
    if sweep in (1, 2, 4, 8):
        rmse = np.sqrt(np.mean((R - P @ Q.T)[test] ** 2))
        print("sweep", sweep, " test RMSE", round(rmse, 3))
popularity = train.sum(axis=0)                         # how many users interacted with each item
scores_pop = np.tile(popularity, (n_users, 1)).astype(float)
scores_mf = P @ Q.T
for name, S in [("popular", scores_pop), ("matrix factorisation", scores_mf)]:
    S = np.where(train, -np.inf, S)                    # don't recommend items already seen
    top = np.argsort(-S, axis=1)[:, :5]
    coverage = len(np.unique(top)) / n_items
    avg_pop = popularity[top].mean()
    print(f"{name:21s} catalogue coverage {coverage:.2f}   average popularity of recommended items {avg_pop:.1f}")
print("average popularity across all items:", round(popularity.mean(), 1))

##############################################################################
# Running example: Chennai Homes
#
# The same 12-house dataset used in every lesson (data/houses.csv in the course folder).
##############################################################################
import pandas as pd
import numpy as np
df = pd.read_csv(DATA / "houses.csv")
from sklearn.preprocessing import StandardScaler
from sklearn.metrics.pairwise import cosine_similarity
cols = ["size_m2", "bedrooms", "dist_km", "age_yrs", "price_lakh"]
Z = StandardScaler().fit_transform(df[cols])
sim = cosine_similarity(Z)
np.fill_diagonal(sim, -1)
for viewed in [2, 11]:
    row = df.index[df.id == viewed][0]
    top = np.argsort(sim[row])[::-1][:3]
    print("viewed", viewed, "→ similar:", df.id.iloc[top].tolist(), " similarity", np.round(sim[row, top], 2).tolist())
