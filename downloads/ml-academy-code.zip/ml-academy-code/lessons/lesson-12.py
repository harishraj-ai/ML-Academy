"""Lesson 12: Naive Bayes — all the code from the lesson, as one script.

Part of the ML Academy course. Run it with:  python lesson-12.py
(works from any folder; the data is read from ../data/)
"""
from pathlib import Path
DATA = Path(__file__).resolve().parent.parent / "data"   # the course's data folder

##############################################################################
# 9. In Python
##############################################################################
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.naive_bayes import MultinomialNB

spam = ["win money now", "free money offer", "win a free prize now", "claim your free prize"]
ham = ["meeting at noon", "lunch with the team now", "project meeting notes",
       "see you at lunch", "your project report is ready", "notes from the team meeting"]

vec = CountVectorizer(token_pattern=r"(?u)\b\w+\b")   # keep 1-letter words like "a"
X = vec.fit_transform(spam + ham)
y = [1] * 4 + [0] * 6                                   # 1 = spam, 0 = ham

nb = MultinomialNB(alpha=1.0).fit(X, y)                 # alpha=1 is Laplace smoothing
tests = ["free money now", "meeting notes for the team", "win lunch now"]
print(nb.predict_proba(vec.transform(tests)).round(3))  # columns: [P(ham), P(spam)]
from sklearn.datasets import load_wine
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import GaussianNB

X, y = load_wine(return_X_y=True)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, stratify=y, random_state=0)
print(round(GaussianNB().fit(X_train, y_train).score(X_test, y_test), 3))   # 0.956

##############################################################################
# 12. Going deeper: smoothing, text pipelines and generative models
##############################################################################
import numpy as np
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.naive_bayes import MultinomialNB

texts = ["win cash prize now", "cheap meds win big", "claim your free prize", "free cash offer now",
         "meeting moved to monday", "lunch on monday?", "project report attached", "see you at the meeting"]
labels = np.array([1, 1, 1, 1, 0, 0, 0, 0])                # 1 = spam
vec = CountVectorizer().fit(texts)
Xc = vec.transform(texts)
for alpha in [1e-10, 1.0]:
    nb = MultinomialNB(alpha=alpha).fit(Xc, labels)
    p = nb.predict_proba(vec.transform(["free lunch on monday", "win a free meeting"]))[:, 1]
    print(f"alpha {alpha:g}: P(spam) for the two new messages {p.round(3)}")
# Which words push towards spam? The log-ratio log P(word | spam) − log P(word | ham)
nb = MultinomialNB(alpha=1.0).fit(Xc, labels)
ratio = nb.feature_log_prob_[1] - nb.feature_log_prob_[0]
words = vec.get_feature_names_out()
order = np.argsort(ratio)
print("most spam-like:", [(str(words[i]), float(round(ratio[i], 2))) for i in order[::-1][:4]])
print("most ham-like: ", [(str(words[i]), float(round(ratio[i], 2))) for i in order[:4]])
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.pipeline import make_pipeline
from sklearn.naive_bayes import ComplementNB

# A text pipeline: words and word pairs, TF-IDF weighting, then naive Bayes
pipe = make_pipeline(TfidfVectorizer(ngram_range=(1, 2)), ComplementNB(alpha=0.5)).fit(texts, labels)
for msg in ["claim your cash now", "report for the monday meeting"]:
    print(f"{msg!r:34} -> {'spam' if pipe.predict([msg])[0] else 'ham'}")
print("number of features (words and word pairs):", len(pipe[0].get_feature_names_out()))

##############################################################################
# Running example: Chennai Homes
#
# The same 12-house dataset used in every lesson (data/houses.csv in the course folder).
##############################################################################
import pandas as pd
import numpy as np
df = pd.read_csv(DATA / "houses.csv")
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.naive_bayes import MultinomialNB
vec = CountVectorizer()
Xw = vec.fit_transform(df["description"])
nb = MultinomialNB(alpha=1.0).fit(Xw, df["sold_fast"])
for text in ["new flat near metro", "old villa needs renovation", "quiet flat with garden"]:
    print(f"{text:28s} P(sells fast) = {nb.predict_proba(vec.transform([text]))[0, 1]:.2f}")
