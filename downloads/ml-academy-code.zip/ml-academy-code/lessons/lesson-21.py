"""Lesson 21: Ethics & Fairness in Machine Learning — all the code from the lesson, as one script.

Part of the ML Academy course. Run it with:  python lesson-21.py
(works from any folder; the data is read from ../data/)
"""
from pathlib import Path
DATA = Path(__file__).resolve().parent.parent / "data"   # the course's data folder

##############################################################################
# 10. In Python: a fairness report from scratch
##############################################################################
import numpy as np
import pandas as pd

# A synthetic loan dataset: two groups with different base rates of repayment
rng = np.random.default_rng(0)
n = 2000
group = rng.choice(["A", "B"], size=n, p=[0.6, 0.4])
base = np.where(group == "A", 0.5, 0.2)              # share who would repay
repay = (rng.random(n) < base).astype(int)
score = np.clip(0.5 + 0.25 * (repay - 0.5) * 2 + rng.normal(0, 0.18, n), 0, 1)  # model's score
df = pd.DataFrame({"group": group, "repay": repay, "score": score})

def group_report(df, threshold):
    d = df.assign(approve=(df["score"] >= threshold).astype(int))
    rows = {}
    for g, s in d.groupby("group"):
        tp = ((s.approve == 1) & (s.repay == 1)).sum(); fp = ((s.approve == 1) & (s.repay == 0)).sum()
        fn = ((s.approve == 0) & (s.repay == 1)).sum(); tn = ((s.approve == 0) & (s.repay == 0)).sum()
        rows[g] = {"selection rate": (tp + fp) / len(s), "TPR": tp / (tp + fn), "FPR": fp / (fp + tn), "PPV": tp / (tp + fp)}
    return pd.DataFrame(rows).T.round(3)

r = group_report(df, threshold=0.6)
print(r)
print("demographic-parity ratio:", round(r.loc["B", "selection rate"] / r.loc["A", "selection rate"], 3))

##############################################################################
# 13. Going deeper: the impossibility result, measured
##############################################################################
import numpy as np

# Two groups with different base rates; a model whose scores are perfectly calibrated in both groups
rng = np.random.default_rng(0)
def make_group(n, a, b):
    risk = rng.beta(a, b, n)                 # each person's true probability
    return risk, (rng.random(n) < risk).astype(int)
groups = {"group A": make_group(20000, 2, 5), "group B": make_group(20000, 4, 4)}

print("group     base rate   calibration (pred 0.6–0.7: actual)   TPR     FPR     PPV")
for g, (score, y) in groups.items():
    flag = score >= 0.5
    sel = (score >= 0.6) & (score < 0.7)
    tpr = flag[y == 1].mean(); fpr = flag[y == 0].mean(); ppv = y[flag].mean()
    print(f"{g:8}   {y.mean():9.3f}   {y[sel].mean():33.3f}   {tpr:.3f}   {fpr:.3f}   {ppv:.3f}")
# Equalise true-positive rates with group-specific thresholds, and see what it costs
def rates(score, y, t):
    flag = score >= t
    return flag[y == 1].mean(), flag[y == 0].mean(), (flag == y).mean()

sA, yA = groups["group A"]; sB, yB = groups["group B"]
target_tpr = rates(sB, yB, 0.5)[0]
ts = np.linspace(0.05, 0.95, 181)
tA = ts[np.argmin([abs(rates(sA, yA, t)[0] - target_tpr) for t in ts])]
for name, t_A in [("one threshold 0.5 for both", 0.5), (f"threshold {tA:.3f} for group A", tA)]:
    tprA, fprA, accA = rates(sA, yA, t_A); tprB, fprB, accB = rates(sB, yB, 0.5)
    print(f"{name:28}: TPR A {tprA:.3f} / B {tprB:.3f}   FPR A {fprA:.3f} / B {fprB:.3f}   accuracy A {accA:.3f}")
# Small groups make fairness metrics noisy: bootstrap interval for a TPR measured on just 400 people
yS, sS = yA[:400], sA[:400]
pos = np.flatnonzero(yS == 1)
boot = [np.mean(sS[rng.choice(pos, len(pos))] >= 0.5) for _ in range(5000)]
print("positives in the small sample:", len(pos), "  TPR:", round(np.mean(sS[pos] >= 0.5), 3),
      "  95% interval:", np.round(np.percentile(boot, [2.5, 97.5]), 3))

##############################################################################
# Running example: Chennai Homes
#
# The same 12-house dataset used in every lesson (data/houses.csv in the course folder).
##############################################################################
import pandas as pd
import numpy as np
df = pd.read_csv(DATA / "houses.csv")
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
from sklearn.model_selection import cross_val_predict
cols = ["dist_km", "age_yrs"]                 # the model never sees "area"
clf = make_pipeline(StandardScaler(), LogisticRegression())
df["pred"] = cross_val_predict(clf, df[cols], df["sold_fast"], cv=4)   # honest out-of-fold predictions
df["group"] = np.where(df["area"] == "Central", "Central", "Not central")
for g, s in df.groupby("group"):
    tp = ((s.pred == 1) & (s.sold_fast == 1)).sum(); fp = ((s.pred == 1) & (s.sold_fast == 0)).sum()
    pos, neg = (s.sold_fast == 1).sum(), (s.sold_fast == 0).sum()
    print(f"{g:12s} n={len(s):2d}  base rate {s.sold_fast.mean():.3f}  flagged {s.pred.mean():.3f}  "
          f"TPR {tp / pos:.2f}  FPR {fp / neg if neg else float('nan'):.2f}")
