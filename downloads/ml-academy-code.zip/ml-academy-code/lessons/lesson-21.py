"""Lesson 21: Ethics & Fairness in Machine Learning — all the code from the lesson, as one script.

Part of the ML Academy course. Run it with:  python lesson-21.py
(works from any folder; the data is read from ../data/)
"""
from pathlib import Path
DATA = Path(__file__).resolve().parent.parent / "data"   # the course's data folder

##############################################################################
# 10. In Python: a fairness report from scratch
##############################################################################
import numpy as np
import pandas as pd

# A synthetic loan dataset: two groups with different base rates of repayment
rng = np.random.default_rng(0)
n = 2000
group = rng.choice(["A", "B"], size=n, p=[0.6, 0.4])
base = np.where(group == "A", 0.5, 0.2)              # share who would repay
repay = (rng.random(n) < base).astype(int)
score = np.clip(0.5 + 0.25 * (repay - 0.5) * 2 + rng.normal(0, 0.18, n), 0, 1)  # model's score
df = pd.DataFrame({"group": group, "repay": repay, "score": score})

def group_report(df, threshold):
    d = df.assign(approve=(df["score"] >= threshold).astype(int))
    rows = {}
    for g, s in d.groupby("group"):
        tp = ((s.approve == 1) & (s.repay == 1)).sum(); fp = ((s.approve == 1) & (s.repay == 0)).sum()
        fn = ((s.approve == 0) & (s.repay == 1)).sum(); tn = ((s.approve == 0) & (s.repay == 0)).sum()
        rows[g] = {"selection rate": (tp + fp) / len(s), "TPR": tp / (tp + fn), "FPR": fp / (fp + tn), "PPV": tp / (tp + fp)}
    return pd.DataFrame(rows).T.round(3)

r = group_report(df, threshold=0.6)
print(r)
print("demographic-parity ratio:", round(r.loc["B", "selection rate"] / r.loc["A", "selection rate"], 3))

##############################################################################
# Running example: Chennai Homes
#
# The same 12-house dataset used in every lesson (data/houses.csv in the course folder).
##############################################################################
import pandas as pd
import numpy as np
df = pd.read_csv(DATA / "houses.csv")
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
from sklearn.model_selection import cross_val_predict
cols = ["dist_km", "age_yrs"]                 # the model never sees "area"
clf = make_pipeline(StandardScaler(), LogisticRegression())
df["pred"] = cross_val_predict(clf, df[cols], df["sold_fast"], cv=4)   # honest out-of-fold predictions
df["group"] = np.where(df["area"] == "Central", "Central", "Not central")
for g, s in df.groupby("group"):
    tp = ((s.pred == 1) & (s.sold_fast == 1)).sum(); fp = ((s.pred == 1) & (s.sold_fast == 0)).sum()
    pos, neg = (s.sold_fast == 1).sum(), (s.sold_fast == 0).sum()
    print(f"{g:12s} n={len(s):2d}  base rate {s.sold_fast.mean():.3f}  flagged {s.pred.mean():.3f}  "
          f"TPR {tp / pos:.2f}  FPR {fp / neg if neg else float('nan'):.2f}")
