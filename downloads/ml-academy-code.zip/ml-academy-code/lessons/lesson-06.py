"""Lesson 6: Linear Regression — all the code from the lesson, as one script.

Part of the ML Academy course. Run it with:  python lesson-06.py
(works from any folder; the data is read from ../data/)
"""
from pathlib import Path
DATA = Path(__file__).resolve().parent.parent / "data"   # the course's data folder

##############################################################################
# 11. In Python: from scratch, then with scikit-learn
##############################################################################
import numpy as np

x = np.array([1, 2, 3, 4, 5], dtype=float)
y = np.array([2, 4, 5, 4, 5], dtype=float)

# Simple formulas
w = np.sum((x - x.mean()) * (y - y.mean())) / np.sum((x - x.mean()) ** 2)
b = y.mean() - w * x.mean()
print(w, b)                         # 0.6 2.2

# Normal equation with a column of ones for the bias
X = np.column_stack([np.ones_like(x), x])
w_vec = np.linalg.solve(X.T @ X, X.T @ y)   # solves (XᵀX) w = Xᵀy
print(w_vec)                        # [2.2 0.6]

y_hat = X @ w_vec
r2 = 1 - np.sum((y - y_hat) ** 2) / np.sum((y - y.mean()) ** 2)
print(round(r2, 3))                 # 0.6
from sklearn.datasets import load_diabetes
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import r2_score

X, y = load_diabetes(return_X_y=True)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

model = LinearRegression().fit(X_train, y_train)
print(model.coef_.round(1))          # one weight per feature
print(round(model.intercept_, 1))
print(round(r2_score(y_test, model.predict(X_test)), 3))   # R² on unseen data

##############################################################################
# Running example: Chennai Homes
#
# The same 12-house dataset used in every lesson (data/houses.csv in the course folder).
##############################################################################
import pandas as pd
import numpy as np
df = pd.read_csv(DATA / "houses.csv")
from sklearn.linear_model import LinearRegression
m1 = LinearRegression().fit(df[["size_m2"]], df["price_lakh"])
print("price = %.3f * size + %.2f" % (m1.coef_[0], m1.intercept_), " R2 =", round(m1.score(df[["size_m2"]], df["price_lakh"]), 3))
cols = ["size_m2", "dist_km", "age_yrs"]
m3 = LinearRegression().fit(df[cols], df["price_lakh"])
print({c: round(float(v), 3) for c, v in zip(cols, m3.coef_)}, round(m3.intercept_, 2), " R2 =", round(m3.score(df[cols], df["price_lakh"]), 3))
