"""Lesson 6: Linear Regression — all the code from the lesson, as one script.

Part of the ML Academy course. Run it with:  python lesson-06.py
(works from any folder; the data is read from ../data/)
"""
from pathlib import Path
DATA = Path(__file__).resolve().parent.parent / "data"   # the course's data folder

##############################################################################
# 11. In Python: from scratch, then with scikit-learn
##############################################################################
import numpy as np

x = np.array([1, 2, 3, 4, 5], dtype=float)
y = np.array([2, 4, 5, 4, 5], dtype=float)

# Simple formulas
w = np.sum((x - x.mean()) * (y - y.mean())) / np.sum((x - x.mean()) ** 2)
b = y.mean() - w * x.mean()
print(w, b)                         # 0.6 2.2

# Normal equation with a column of ones for the bias
X = np.column_stack([np.ones_like(x), x])
w_vec = np.linalg.solve(X.T @ X, X.T @ y)   # solves (XᵀX) w = Xᵀy
print(w_vec)                        # [2.2 0.6]

y_hat = X @ w_vec
r2 = 1 - np.sum((y - y_hat) ** 2) / np.sum((y - y.mean()) ** 2)
print(round(r2, 3))                 # 0.6
from sklearn.datasets import load_diabetes
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import r2_score

X, y = load_diabetes(return_X_y=True)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

model = LinearRegression().fit(X_train, y_train)
print(model.coef_.round(1))          # one weight per feature
print(round(model.intercept_, 1))
print(round(r2_score(y_test, model.predict(X_test)), 3))   # R² on unseen data

##############################################################################
# 14. Going deeper: the statistics behind linear regression
##############################################################################
import numpy as np
from scipy import stats
from sklearn.datasets import load_diabetes

def ols(X, y):
    """Least squares plus standard errors, t, p-values and 95% intervals."""
    n, d = X.shape
    A = np.column_stack([np.ones(n), X])            # add the bias column
    w = np.linalg.solve(A.T @ A, A.T @ y)           # the usual weights
    resid = y - A @ w
    dof = n - d - 1                                 # data points minus parameters
    sigma2 = resid @ resid / dof                    # estimated noise variance
    se = np.sqrt(np.diag(sigma2 * np.linalg.inv(A.T @ A)))
    t = w / se                                      # how many SEs away from zero
    p = 2 * stats.t.sf(np.abs(t), dof)              # two-sided p-values
    tc = stats.t.ppf(0.975, dof)                    # 95% critical value
    return w, se, t, p, w - tc * se, w + tc * se

data = load_diabetes()
X, y, names = data.data, data.target, data.feature_names
w, se, t, p, lo, hi = ols(X, y)
print(f"{'':6}{'weight':>8}{'SE':>7}{'t':>7}{'p':>7}   95% interval")
for row in zip(["bias"] + names, w, se, t, p, lo, hi):
    print("{:6}{:8.1f}{:7.1f}{:7.2f}{:7.3f}   [{:7.1f}, {:7.1f}]".format(*row))
from sklearn.linear_model import LinearRegression

# VIF of feature j = 1 / (1 - R²) when feature j is predicted from all the other features
for j, name in enumerate(names):
    others = np.delete(X, j, axis=1)
    r2_j = LinearRegression().fit(others, X[:, j]).score(others, X[:, j])
    print(f"{name:4} VIF {1 / (1 - r2_j):5.1f}")

# Drop s2 and refit: s1's standard error shrinks, the fit barely changes
keep = [j for j, name in enumerate(names) if name != "s2"]
w2, se2, *_ = ols(X[:, keep], y)
print("s1 with s2:    weight", round(w[5], 1), " SE", round(se[5], 1))
print("s1 without s2: weight", round(w2[5], 1), " SE", round(se2[5], 1))
print("R² with s2:   ", round(LinearRegression().fit(X, y).score(X, y), 4))
print("R² without s2:", round(LinearRegression().fit(X[:, keep], y).score(X[:, keep], y), 4))
from sklearn.model_selection import cross_val_score

n = len(y)
rng = np.random.default_rng(0)
print("noise cols  train R²  adjusted R²  5-fold CV R²")
for extra in [0, 10, 50, 100]:
    Xe = np.column_stack([X, rng.normal(size=(n, extra))])     # add columns of pure noise
    d = Xe.shape[1]
    r2 = LinearRegression().fit(Xe, y).score(Xe, y)
    adj = 1 - (1 - r2) * (n - 1) / (n - d - 1)
    cv = cross_val_score(LinearRegression(), Xe, y, cv=5, scoring="r2").mean()
    print(f"{extra:10d}  {r2:8.3f}  {adj:11.3f}  {cv:12.3f}")
# Salaries whose spread grows with experience (simulated, in lakh per year)
rng = np.random.default_rng(2)
years = rng.uniform(0, 30, size=300)
salary = 4 * np.exp(0.06 * years) * rng.lognormal(0, 0.25, size=300)

def spread(x, target):
    """Fit a line, then compare residual spread for the lowest and highest third of x."""
    m = LinearRegression().fit(x[:, None], target)
    r = target - m.predict(x[:, None])
    low, high = x < np.quantile(x, 1/3), x > np.quantile(x, 2/3)
    return m, r[low].std(), r[high].std()

_, a, b = spread(years, salary)
print(f"raw salary: spread {a:.2f} (junior) vs {b:.2f} (senior)")
m_log, a, b = spread(years, np.log(salary))
print(f"log salary: spread {a:.3f} (junior) vs {b:.3f} (senior)")
k = m_log.coef_[0]
print(f"weight {k:.4f} -> each extra year multiplies salary by {np.exp(k):.3f}")
from sklearn.linear_model import HuberRegressor

rng = np.random.default_rng(1)
x = np.arange(1, 21, dtype=float)
y_ = 2 * x + 5 + rng.normal(0, 2, size=20)         # true line: y = 2x + 5
x = np.append(x, 40.0); y_ = np.append(y_, 20.0)   # one unusual point far to the right

A = np.column_stack([np.ones_like(x), x])
lev = np.diag(A @ np.linalg.inv(A.T @ A) @ A.T)    # leverage = diagonal of the hat matrix
w_ = np.linalg.solve(A.T @ A, A.T @ y_)
e = y_ - A @ w_
p_ = A.shape[1]
s2 = e @ e / (len(y_) - p_)
cooks = e**2 / (p_ * s2) * lev / (1 - lev) ** 2     # Cook's distance

print("slope, least squares with the point:   ", round(w_[1], 2))
print("slope, least squares without the point:", round(LinearRegression().fit(x[:-1, None], y_[:-1]).coef_[0], 2))
print("slope, Huber with the point:           ", round(HuberRegressor().fit(x[:, None], y_).coef_[0], 2))
print("leverage: median", round(np.median(lev), 3), "| unusual point", round(lev[-1], 3))
print("Cook's D: largest other", round(cooks[:-1].max(), 3), "| unusual point", round(cooks[-1], 2))
import pandas as pd

df = pd.read_csv(DATA / "houses.csv")
all3 = pd.get_dummies(df["area"], dtype=float)           # Central, Outskirts, Suburb
A = np.column_stack([np.ones(len(df)), df["size_m2"], all3])
print("columns:", A.shape[1], " independent columns (rank):", np.linalg.matrix_rank(A))

Xd = pd.get_dummies(df[["size_m2", "area"]], columns=["area"], drop_first=True, dtype=float)
m = LinearRegression().fit(Xd, df["price_lakh"])
for name, wt in zip(Xd.columns, m.coef_):
    print(f"{name:15}{wt:7.2f}")
print(f"{'bias':15}{m.intercept_:7.2f}")

##############################################################################
# Running example: Chennai Homes
#
# The same 12-house dataset used in every lesson (data/houses.csv in the course folder).
##############################################################################
import pandas as pd
import numpy as np
df = pd.read_csv(DATA / "houses.csv")
from sklearn.linear_model import LinearRegression
m1 = LinearRegression().fit(df[["size_m2"]], df["price_lakh"])
print("price = %.3f * size + %.2f" % (m1.coef_[0], m1.intercept_), " R2 =", round(m1.score(df[["size_m2"]], df["price_lakh"]), 3))
cols = ["size_m2", "dist_km", "age_yrs"]
m3 = LinearRegression().fit(df[cols], df["price_lakh"])
print({c: round(float(v), 3) for c, v in zip(cols, m3.coef_)}, round(m3.intercept_, 2), " R2 =", round(m3.score(df[cols], df["price_lakh"]), 3))
