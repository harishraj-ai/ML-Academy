"""Lesson 15: Support Vector Machines — all the code from the lesson, as one script.

Part of the ML Academy course. Run it with:  python lesson-15.py
(works from any folder; the data is read from ../data/)
"""
from pathlib import Path
DATA = Path(__file__).resolve().parent.parent / "data"   # the course's data folder

##############################################################################
# 9. In Python
##############################################################################
from sklearn.datasets import make_circles
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.svm import SVC
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline

X, y = make_circles(n_samples=400, noise=0.2, factor=0.5, random_state=0)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, random_state=0)

for kernel in ["linear", "poly", "rbf"]:
    m = make_pipeline(StandardScaler(), SVC(kernel=kernel, degree=2)).fit(X_train, y_train)
    print(f"{kernel:6s} test accuracy {m.score(X_test, y_test):.3f}   support vectors {m[-1].n_support_.sum()}")

grid = {"svc__C": [0.1, 1, 10, 100], "svc__gamma": [0.01, 0.1, 1, 10]}
search = GridSearchCV(make_pipeline(StandardScaler(), SVC(kernel="rbf")), grid, cv=5).fit(X_train, y_train)
print("best:", search.best_params_, "CV", round(search.best_score_, 3), "test", round(search.score(X_test, y_test), 3))

m = make_pipeline(StandardScaler(), SVC(kernel="rbf", C=100, gamma=10)).fit(X_train, y_train)
print("C=100, gamma=10: train", round(m.score(X_train, y_train), 3), "test", round(m.score(X_test, y_test), 3))

##############################################################################
# 12. Going deeper: the dual problem, kernels and hinge loss
##############################################################################
import numpy as np

# The kernel trick: (x·z + 1)² equals the dot product of explicit degree-2 features
def phi(v):
    a, b = v
    return np.array([1, np.sqrt(2) * a, np.sqrt(2) * b, a * a, b * b, np.sqrt(2) * a * b])

x, z = np.array([1.0, 2.0]), np.array([3.0, -1.0])
print("kernel (x·z + 1)²:     ", (x @ z + 1) ** 2)
print("explicit φ(x)·φ(z):    ", round(phi(x) @ phi(z), 10))
from sklearn.datasets import make_moons
from sklearn.model_selection import train_test_split
from sklearn.svm import SVC

X, y = make_moons(n_samples=400, noise=0.3, random_state=0)
Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=0.5, random_state=0)
print("    C   gamma   support vectors   train   test")
for C in [0.1, 1, 100]:
    for gamma in [0.1, 1, 30]:
        m = SVC(C=C, gamma=gamma).fit(Xtr, ytr)
        print(f"{C:5} {gamma:7}   {m.n_support_.sum():15d}   {m.score(Xtr, ytr):5.3f}   {m.score(Xte, yte):5.3f}")
from sklearn.svm import LinearSVC
from sklearn.linear_model import LogisticRegression

# Hinge loss and log loss give very similar linear boundaries
Xl, yl = make_moons(n_samples=400, noise=0.3, random_state=1)
svm = LinearSVC(C=1.0).fit(Xl, yl)
lr = LogisticRegression(C=1.0).fit(Xl, yl)
unit = lambda w: w / np.linalg.norm(w)
print("boundary direction, linear SVM:     ", unit(svm.coef_[0]).round(3))
print("boundary direction, logistic regr.: ", unit(lr.coef_[0]).round(3))
print("agreement on predictions:", np.mean(svm.predict(Xl) == lr.predict(Xl)))

##############################################################################
# Running example: Chennai Homes
#
# The same 12-house dataset used in every lesson (data/houses.csv in the course folder).
##############################################################################
import pandas as pd
import numpy as np
df = pd.read_csv(DATA / "houses.csv")
from sklearn.svm import SVC
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
cols = ["dist_km", "age_yrs"]
svm = make_pipeline(StandardScaler(), SVC(kernel="linear", C=1.0)).fit(df[cols], df["sold_fast"])
w = svm[-1].coef_[0]
print("margin width (standardised units):", round(2 / np.linalg.norm(w), 2))
print("support vectors: houses", (df["id"].iloc[svm[-1].support_]).tolist())
