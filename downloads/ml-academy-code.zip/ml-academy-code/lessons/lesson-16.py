"""Lesson 16: Clustering — all the code from the lesson, as one script.

Part of the ML Academy course. Run it with:  python lesson-16.py
(works from any folder; the data is read from ../data/)
"""
from pathlib import Path
DATA = Path(__file__).resolve().parent.parent / "data"   # the course's data folder

##############################################################################
# 10. In Python
##############################################################################
from sklearn.datasets import make_blobs, make_moons
from sklearn.cluster import KMeans, DBSCAN, AgglomerativeClustering
from sklearn.metrics import silhouette_score, adjusted_rand_score
from sklearn.preprocessing import StandardScaler

X, y_true = make_blobs(n_samples=500, centers=4, cluster_std=1.0, random_state=42)
for k in range(2, 8):
    km = KMeans(n_clusters=k, n_init=10, random_state=0).fit(X)
    print(f"k={k}  inertia={km.inertia_:8.1f}  silhouette={silhouette_score(X, km.labels_):.3f}")
Xm, ym = make_moons(n_samples=300, noise=0.06, random_state=0)
Xm = StandardScaler().fit_transform(Xm)

km = KMeans(n_clusters=2, n_init=10, random_state=0).fit(Xm)
db = DBSCAN(eps=0.3, min_samples=5).fit(Xm)
ag = AgglomerativeClustering(n_clusters=2, linkage="single").fit(Xm)

print("k-means ARI:", round(adjusted_rand_score(ym, km.labels_), 3))
print("DBSCAN  ARI:", round(adjusted_rand_score(ym, db.labels_), 3),
      " clusters:", len(set(db.labels_) - {-1}), " noise points:", list(db.labels_).count(-1))
print("single-linkage ARI:", round(adjusted_rand_score(ym, ag.labels_), 3))

##############################################################################
# Running example: Chennai Homes
#
# The same 12-house dataset used in every lesson (data/houses.csv in the course folder).
##############################################################################
import pandas as pd
import numpy as np
df = pd.read_csv(DATA / "houses.csv")
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
cols = ["size_m2", "dist_km", "price_lakh"]
Z = StandardScaler().fit_transform(df[cols])
km = KMeans(n_clusters=3, n_init=10, random_state=0).fit(Z)
df["cluster"] = km.labels_
print(df.groupby("cluster")[cols].mean().round(1))
print(pd.crosstab(df["cluster"], df["area"]))
