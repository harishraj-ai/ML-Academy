"""Lesson 16: Clustering — all the code from the lesson, as one script.

Part of the ML Academy course. Run it with:  python lesson-16.py
(works from any folder; the data is read from ../data/)
"""
from pathlib import Path
DATA = Path(__file__).resolve().parent.parent / "data"   # the course's data folder

##############################################################################
# 10. In Python
##############################################################################
from sklearn.datasets import make_blobs, make_moons
from sklearn.cluster import KMeans, DBSCAN, AgglomerativeClustering
from sklearn.metrics import silhouette_score, adjusted_rand_score
from sklearn.preprocessing import StandardScaler

X, y_true = make_blobs(n_samples=500, centers=4, cluster_std=1.0, random_state=42)
for k in range(2, 8):
    km = KMeans(n_clusters=k, n_init=10, random_state=0).fit(X)
    print(f"k={k}  inertia={km.inertia_:8.1f}  silhouette={silhouette_score(X, km.labels_):.3f}")
Xm, ym = make_moons(n_samples=300, noise=0.06, random_state=0)
Xm = StandardScaler().fit_transform(Xm)

km = KMeans(n_clusters=2, n_init=10, random_state=0).fit(Xm)
db = DBSCAN(eps=0.3, min_samples=5).fit(Xm)
ag = AgglomerativeClustering(n_clusters=2, linkage="single").fit(Xm)

print("k-means ARI:", round(adjusted_rand_score(ym, km.labels_), 3))
print("DBSCAN  ARI:", round(adjusted_rand_score(ym, db.labels_), 3),
      " clusters:", len(set(db.labels_) - {-1}), " noise points:", list(db.labels_).count(-1))
print("single-linkage ARI:", round(adjusted_rand_score(ym, ag.labels_), 3))

##############################################################################
# 13. Going deeper: mixture models, density and hierarchy
##############################################################################
import numpy as np
from sklearn.datasets import make_blobs, make_moons
from sklearn.cluster import KMeans, DBSCAN, AgglomerativeClustering
from sklearn.mixture import GaussianMixture
from sklearn.metrics import adjusted_rand_score, silhouette_score

# Stretched clusters: k-means assumes round blobs, a Gaussian mixture doesn't
Xb, yb = make_blobs(n_samples=600, centers=3, random_state=170)
Xs = Xb @ np.array([[0.6, -0.6], [-0.4, 0.8]])          # stretch and shear the blobs
km = KMeans(3, n_init=10, random_state=0).fit_predict(Xs)
gmm = GaussianMixture(3, covariance_type="full", random_state=0).fit(Xs)
print("stretched blobs: ARI k-means", round(adjusted_rand_score(yb, km), 3), "  ARI Gaussian mixture", round(adjusted_rand_score(yb, gmm.predict(Xs)), 3))
p = gmm.predict_proba(Xs)
print("share of points the mixture is unsure about (max probability < 0.9):", round(np.mean(p.max(axis=1) < 0.9), 3))
Xm, ym = make_moons(n_samples=500, noise=0.06, random_state=0)
results = {
    "k-means":            KMeans(2, n_init=10, random_state=0).fit_predict(Xm),
    "Gaussian mixture":   GaussianMixture(2, random_state=0).fit(Xm).predict(Xm),
    "DBSCAN":             DBSCAN(eps=0.2, min_samples=5).fit_predict(Xm),
    "agglomerative, single linkage": AgglomerativeClustering(2, linkage="single").fit_predict(Xm),
    "agglomerative, Ward linkage":   AgglomerativeClustering(2, linkage="ward").fit_predict(Xm),
}
for name, lab in results.items():
    print(f"{name:30}: ARI {adjusted_rand_score(ym, lab):.3f}")
# Choosing k without labels: silhouette score and the mixture's BIC
Xk, _ = make_blobs(n_samples=600, centers=4, cluster_std=1.0, random_state=7)
print(" k   silhouette   BIC")
for k in range(2, 8):
    lab = KMeans(k, n_init=10, random_state=0).fit_predict(Xk)
    bic = GaussianMixture(k, random_state=0).fit(Xk).bic(Xk)
    print(f"{k:2d}   {silhouette_score(Xk, lab):10.3f}   {bic:7.0f}")

##############################################################################
# Running example: Chennai Homes
#
# The same 12-house dataset used in every lesson (data/houses.csv in the course folder).
##############################################################################
import pandas as pd
import numpy as np
df = pd.read_csv(DATA / "houses.csv")
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
cols = ["size_m2", "dist_km", "price_lakh"]
Z = StandardScaler().fit_transform(df[cols])
km = KMeans(n_clusters=3, n_init=10, random_state=0).fit(Z)
df["cluster"] = km.labels_
print(df.groupby("cluster")[cols].mean().round(1))
print(pd.crosstab(df["cluster"], df["area"]))
