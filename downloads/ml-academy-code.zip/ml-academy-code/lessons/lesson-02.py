"""Lesson 2: Vectors & Matrices — all the code from the lesson, as one script.

Part of the ML Academy course. Run it with:  python lesson-02.py
(works from any folder; the data is read from ../data/)
"""
from pathlib import Path
DATA = Path(__file__).resolve().parent.parent / "data"   # the course's data folder

##############################################################################
# 11. Doing it in Python with NumPy
##############################################################################
import numpy as np

a = np.array([2, 3, 1])
b = np.array([4, -1, 5])
print(a + b)             # [6 2 6]      addition
print(3 * a)             # [6 9 3]      scalar multiplication
print(a @ b)             # 10           dot product
print(np.linalg.norm(np.array([3, 4])))   # 5.0   length

X = np.array([[50, 1, 2],
              [80, 2, 5],
              [120, 3, 12],
              [150, 4, 3]])
w = np.array([3, 20, -5])
print(X.shape)           # (4, 3)  4 examples, 3 features
print(X @ w)             # [160 255 360 515]   all predictions at once
print(X.T.shape)         # (3, 4)  transpose

##############################################################################
# Running example: Chennai Homes
#
# The same 12-house dataset used in every lesson (data/houses.csv in the course folder).
##############################################################################
import pandas as pd
import numpy as np
df = pd.read_csv(DATA / "houses.csv")
X = df[["size_m2", "bedrooms", "dist_km", "age_yrs"]].to_numpy()
print(X.shape)                                   # 12 houses x 4 features
a, b = X[0], X[1]                                # house 1 and house 2 as vectors
print(a, b, round(np.linalg.norm(a - b), 2))     # their Euclidean distance
w = np.array([0.6, 2.0, -1.2, -0.5])             # some made-up weights
print((X @ w)[:3].round(1))                      # predictions for the first 3 houses
