"""Lesson 2: Vectors & Matrices — all the code from the lesson, as one script.

Part of the ML Academy course. Run it with:  python lesson-02.py
(works from any folder; the data is read from ../data/)
"""
from pathlib import Path
DATA = Path(__file__).resolve().parent.parent / "data"   # the course's data folder

##############################################################################
# 11. Doing it in Python with NumPy
##############################################################################
import numpy as np

a = np.array([2, 3, 1])
b = np.array([4, -1, 5])
print(a + b)             # [6 2 6]      addition
print(3 * a)             # [6 9 3]      scalar multiplication
print(a @ b)             # 10           dot product
print(np.linalg.norm(np.array([3, 4])))   # 5.0   length

X = np.array([[50, 1, 2],
              [80, 2, 5],
              [120, 3, 12],
              [150, 4, 3]])
w = np.array([3, 20, -5])
print(X.shape)           # (4, 3)  4 examples, 3 features
print(X @ w)             # [160 255 360 515]   all predictions at once
print(X.T.shape)         # (3, 4)  transpose

##############################################################################
# 14. Going deeper: the linear algebra behind ML algorithms
##############################################################################
import numpy as np

v = np.array([3.0, -4.0, 1.0])
print("L1 norm (sum of sizes):    ", np.linalg.norm(v, 1))
print("L2 norm (straight line):   ", round(np.linalg.norm(v), 3))
print("L-infinity (biggest entry):", np.linalg.norm(v, np.inf))

M = np.array([[1.0, 2.0], [3.0, 4.0]])
print("Frobenius norm of M:       ", round(np.linalg.norm(M), 3))
# Three features, but the third is the sum of the first two
X = np.array([[1, 2, 3],
              [2, 0, 2],
              [0, 1, 1],
              [3, 1, 4]], dtype=float)
print("columns:", X.shape[1], " rank:", np.linalg.matrix_rank(X))
print("det(XᵀX):", round(np.linalg.det(X.T @ X), 6))

A = np.array([[2.0, 1.0], [1.0, 3.0]])
print("det(A):", round(np.linalg.det(A), 3), "-> A scales areas by this factor")
vals, vecs = np.linalg.eigh(A)            # eigh: for symmetric matrices
print("eigenvalues:", vals.round(3))
print("eigenvectors (columns):")
print(vecs.round(3))
v1 = vecs[:, 1]
print("A @ v:     ", (A @ v1).round(3))
print("lambda * v:", (vals[1] * v1).round(3))
print("dot product of the two eigenvectors:", abs(round(vecs[:, 0] @ vecs[:, 1], 10)))
# A ratings table: 50 users × 40 films, built from 3 hidden "tastes" plus noise
rng = np.random.default_rng(0)
R = rng.normal(size=(50, 3)) @ rng.normal(size=(3, 40)) + rng.normal(0, 0.3, size=(50, 40))
U, s, Vt = np.linalg.svd(R, full_matrices=False)
print("largest singular values:", s[:6].round(1))
for k in [1, 2, 3, 5, 10]:
    approx = U[:, :k] @ np.diag(s[:k]) @ Vt[:k]          # keep only the k largest
    err = np.linalg.norm(R - approx) / np.linalg.norm(R)
    print(f"rank {k:2d}: stores {k * (50 + 40 + 1):4d} of 2000 numbers, relative error {err:.3f}")
rng = np.random.default_rng(2)
n = 100
size = rng.uniform(50, 150, n)
size2 = size + rng.normal(0, 0.5, n)                 # a second, almost identical measurement
Xc = np.column_stack([size, size2]); Xc = Xc - Xc.mean(axis=0)
y = 0.6 * Xc[:, 0] + rng.normal(0, 5, n)
y_nudged = y + rng.normal(0, 1, n)                   # a small change in the targets

G = Xc.T @ Xc
print("condition number of XᵀX:", round(np.linalg.cond(G)))
print("weights:            ", np.linalg.solve(G, Xc.T @ y).round(2))
print("after a tiny change:", np.linalg.solve(G, Xc.T @ y_nudged).round(2))
Gr = G + 100 * np.eye(2)                             # ridge: add λI with λ = 100
print("condition number with ridge:", round(np.linalg.cond(Gr)))
print("ridge weights:      ", np.linalg.solve(Gr, Xc.T @ y).round(2))
print("after a tiny change:", np.linalg.solve(Gr, Xc.T @ y_nudged).round(2))
# Check the matrix-calculus rule  ∇_w ||Xw − y||² = 2 Xᵀ(Xw − y)  with finite differences
rng = np.random.default_rng(3)
Xg = rng.normal(size=(5, 3)); yg = rng.normal(size=5); w = rng.normal(size=3)
f = lambda w: np.sum((Xg @ w - yg) ** 2)
formula = 2 * Xg.T @ (Xg @ w - yg)
h = 1e-6
numeric = np.array([(f(w + h * e) - f(w - h * e)) / (2 * h) for e in np.eye(3)])
print("formula:", formula.round(4))
print("numeric:", numeric.round(4))

##############################################################################
# Running example: Chennai Homes
#
# The same 12-house dataset used in every lesson (data/houses.csv in the course folder).
##############################################################################
import pandas as pd
import numpy as np
df = pd.read_csv(DATA / "houses.csv")
X = df[["size_m2", "bedrooms", "dist_km", "age_yrs"]].to_numpy()
print(X.shape)                                   # 12 houses x 4 features
a, b = X[0], X[1]                                # house 1 and house 2 as vectors
print(a, b, round(np.linalg.norm(a - b), 2))     # their Euclidean distance
w = np.array([0.6, 2.0, -1.2, -0.5])             # some made-up weights
print((X @ w)[:3].round(1))                      # predictions for the first 3 houses
