"""Lesson 8: Logistic Regression — all the code from the lesson, as one script.

Part of the ML Academy course. Run it with:  python lesson-08.py
(works from any folder; the data is read from ../data/)
"""
from pathlib import Path
DATA = Path(__file__).resolve().parent.parent / "data"   # the course's data folder

##############################################################################
# 11. In Python
##############################################################################
import numpy as np

x = np.array([0.5, 1, 1.5, 2, 2.5, 3, 3.5, 4, 4.5, 5])
y = np.array([0, 0, 0, 1, 0, 1, 0, 1, 1, 1])

def sigmoid(z):
    return 1 / (1 + np.exp(-z))

w, b, lr = 0.0, 0.0, 0.1
for step in range(5000):
    p = sigmoid(w * x + b)
    w -= lr * np.mean((p - y) * x)      # dL/dw = mean((p - y) x)
    b -= lr * np.mean(p - y)            # dL/db = mean(p - y)

p = sigmoid(w * x + b)
loss = -np.mean(y * np.log(p) + (1 - y) * np.log(1 - p))
print(round(w, 3), round(b, 3), round(loss, 3))   # 1.353 -3.721 0.434
print(round(-b / w, 2))                           # decision boundary: 2.75 hours
from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import make_pipeline

X, y = load_breast_cancer(return_X_y=True)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, stratify=y, random_state=0)

model = make_pipeline(StandardScaler(), LogisticRegression(max_iter=1000))
model.fit(X_train, y_train)

print(round(model.score(X_test, y_test), 3))      # accuracy on unseen tumours
print(model.predict_proba(X_test[:3]).round(3))   # [P(class 0), P(class 1)] for 3 tumours

##############################################################################
# Running example: Chennai Homes
#
# The same 12-house dataset used in every lesson (data/houses.csv in the course folder).
##############################################################################
import pandas as pd
import numpy as np
df = pd.read_csv(DATA / "houses.csv")
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
cols = ["dist_km", "age_yrs"]
clf = make_pipeline(StandardScaler(), LogisticRegression()).fit(df[cols], df["sold_fast"])
print({c: round(float(v), 2) for c, v in zip(cols, clf[-1].coef_[0])})
new = pd.DataFrame({"dist_km": [3, 20], "age_yrs": [5, 25]})
print(clf.predict_proba(new)[:, 1].round(2))      # P(sells fast) for two new houses
