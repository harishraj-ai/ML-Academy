"""Lesson 8: Logistic Regression — all the code from the lesson, as one script.

Part of the ML Academy course. Run it with:  python lesson-08.py
(works from any folder; the data is read from ../data/)
"""
from pathlib import Path
DATA = Path(__file__).resolve().parent.parent / "data"   # the course's data folder

##############################################################################
# 11. In Python
##############################################################################
import numpy as np

x = np.array([0.5, 1, 1.5, 2, 2.5, 3, 3.5, 4, 4.5, 5])
y = np.array([0, 0, 0, 1, 0, 1, 0, 1, 1, 1])

def sigmoid(z):
    return 1 / (1 + np.exp(-z))

w, b, lr = 0.0, 0.0, 0.1
for step in range(5000):
    p = sigmoid(w * x + b)
    w -= lr * np.mean((p - y) * x)      # dL/dw = mean((p - y) x)
    b -= lr * np.mean(p - y)            # dL/db = mean(p - y)

p = sigmoid(w * x + b)
loss = -np.mean(y * np.log(p) + (1 - y) * np.log(1 - p))
print(round(w, 3), round(b, 3), round(loss, 3))   # 1.353 -3.721 0.434
print(round(-b / w, 2))                           # decision boundary: 2.75 hours
from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import make_pipeline

X, y = load_breast_cancer(return_X_y=True)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, stratify=y, random_state=0)

model = make_pipeline(StandardScaler(), LogisticRegression(max_iter=1000))
model.fit(X_train, y_train)

print(round(model.score(X_test, y_test), 3))      # accuracy on unseen tumours
print(model.predict_proba(X_test[:3]).round(3))   # [P(class 0), P(class 1)] for 3 tumours

##############################################################################
# 14. Going deeper: logistic regression as a probability model
##############################################################################
import numpy as np
from sklearn.datasets import load_breast_cancer
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression

X, y = load_breast_cancer(return_X_y=True)
X = StandardScaler().fit_transform(X[:, :5])          # 5 features keep the example small
A = np.column_stack([np.ones(len(y)), X])
lam = 1.0                                             # L2 penalty, same as sklearn's C = 1

w = np.zeros(A.shape[1])
for it in range(1, 11):                               # Newton's method (IRLS)
    p = 1 / (1 + np.exp(-A @ w))
    grad = A.T @ (p - y) + lam * np.r_[0, w[1:]]      # don't penalise the bias
    S = p * (1 - p)                                   # each point's weight
    H = A.T @ (A * S[:, None]) + lam * np.diag(np.r_[0, np.ones(5)])
    step = np.linalg.solve(H, grad)
    w -= step
    print(f"iteration {it}: step size {np.linalg.norm(step):.2e}")
    if np.linalg.norm(step) < 1e-8: break

sk = LogisticRegression(C=1.0, tol=1e-10, max_iter=1000).fit(X, y)   # tight tolerance
print("ours:   ", w.round(4))
print("sklearn:", np.r_[sk.intercept_, sk.coef_[0]].round(4))
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import GaussianNB
from sklearn.metrics import brier_score_loss

Xa, ya = load_breast_cancer(return_X_y=True)
Xtr, Xte, ytr, yte = train_test_split(Xa, ya, test_size=0.5, random_state=0, stratify=ya)
sc = StandardScaler().fit(Xtr)
models = {"logistic regression": LogisticRegression(max_iter=1000).fit(sc.transform(Xtr), ytr),
          "naive Bayes": GaussianNB().fit(sc.transform(Xtr), ytr)}
bins = [0, 0.2, 0.4, 0.6, 0.8, 1.0]
for name, m in models.items():
    p = m.predict_proba(sc.transform(Xte))[:, 1]
    print(f"{name}: Brier score {brier_score_loss(yte, p):.3f}")
    idx = np.digitize(p, bins[1:-1])
    for b in range(5):
        sel = idx == b
        if sel.sum(): print(f"   predicted {bins[b]:.1f}–{bins[b+1]:.1f}: {sel.sum():3d} cases, average prediction {p[sel].mean():.2f}, actually positive {yte[sel].mean():.2f}")
from sklearn.metrics import recall_score, precision_score

# Imbalanced problem: 5% positives
from sklearn.datasets import make_classification
Xi, yi = make_classification(n_samples=4000, n_features=8, weights=[0.95], class_sep=0.8, random_state=0)
Xtr, Xte, ytr, yte = train_test_split(Xi, yi, test_size=0.5, random_state=0, stratify=yi)
for cw in [None, "balanced"]:
    m = LogisticRegression(class_weight=cw).fit(Xtr, ytr)
    pr = m.predict(Xte)
    print(f"class_weight {str(cw):9}: recall {recall_score(yte, pr):.3f}  precision {precision_score(yte, pr):.3f}  average predicted probability {m.predict_proba(Xte)[:, 1].mean():.3f}")
print("true share of positives in the test set:", round(yte.mean(), 3))

##############################################################################
# Running example: Chennai Homes
#
# The same 12-house dataset used in every lesson (data/houses.csv in the course folder).
##############################################################################
import pandas as pd
import numpy as np
df = pd.read_csv(DATA / "houses.csv")
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
cols = ["dist_km", "age_yrs"]
clf = make_pipeline(StandardScaler(), LogisticRegression()).fit(df[cols], df["sold_fast"])
print({c: round(float(v), 2) for c, v in zip(cols, clf[-1].coef_[0])})
new = pd.DataFrame({"dist_km": [3, 20], "age_yrs": [5, 25]})
print(clf.predict_proba(new)[:, 1].round(2))      # P(sells fast) for two new houses
