"""Lesson 28: Bayesian & Probabilistic ML — all the code from the lesson, as one script.

Part of the ML Academy course. Run it with:  python lesson-28.py
(works from any folder; the data is read from ../data/)
"""
from pathlib import Path
DATA = Path(__file__).resolve().parent.parent / "data"   # the course's data folder

##############################################################################
# 3. A Bayesian A/B test
##############################################################################
import numpy as np
from scipy import stats

# A/B test the Bayesian way: Beta(1, 1) priors, then the observed conversions
a_conv, a_n, b_conv, b_n = 120, 2400, 156, 2400
post_a = stats.beta(1 + a_conv, 1 + a_n - a_conv)
post_b = stats.beta(1 + b_conv, 1 + b_n - b_conv)
rng = np.random.default_rng(0)
da, db = post_a.rvs(200000, random_state=rng), post_b.rvs(200000, random_state=rng)
print("95% credible interval, A:", np.round(post_a.ppf([0.025, 0.975]), 4))
print("95% credible interval, B:", np.round(post_b.ppf([0.025, 0.975]), 4))
print("probability that B converts better than A:", round(np.mean(db > da), 4))
print("expected lift if we switch to B:", round(np.mean(db - da), 4), "  risk (expected loss if B is actually worse):", round(np.mean(np.maximum(da - db, 0)), 5))

##############################################################################
# 5. Bayesian linear regression
##############################################################################
# Bayesian linear regression: a normal prior on the weights gives a full posterior, not just one line
x = np.array([0.5, 1.0, 1.5, 3.0, 3.5])
y = np.array([1.1, 1.9, 3.2, 5.8, 7.1])
X = np.column_stack([np.ones_like(x), x])
sigma2, tau2 = 0.25, 10.0                                   # noise variance and prior variance of each weight
S_post = np.linalg.inv(X.T @ X / sigma2 + np.eye(2) / tau2)  # posterior covariance
m_post = S_post @ X.T @ y / sigma2                          # posterior mean (= ridge with lambda = sigma2/tau2)
print("posterior mean (intercept, slope):", m_post.round(3))
print("posterior std  (intercept, slope):", np.sqrt(np.diag(S_post)).round(3))
for x_new in [2.0, 6.0]:
    phi = np.array([1, x_new])
    mean, var = phi @ m_post, phi @ S_post @ phi + sigma2
    print(f"x {x_new}: predicted y {mean:.2f}, 95% prediction interval [{mean - 1.96 * np.sqrt(var):.2f}, {mean + 1.96 * np.sqrt(var):.2f}]")

##############################################################################
# 6. Gaussian processes
##############################################################################
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import RBF, WhiteKernel

# A Gaussian process: uncertainty grows away from the data
xs = np.array([1, 2, 3, 6, 7, 8.0])[:, None]
ys = np.sin(xs[:, 0]) + np.random.default_rng(2).normal(0, 0.1, 6)
gp = GaussianProcessRegressor(RBF(1.0) + WhiteKernel(0.01), random_state=0).fit(xs, ys)
for q in [2.0, 4.5, 11.0]:
    m, s = gp.predict([[q]], return_std=True)
    print(f"x {q:4}: mean {m[0]:+.2f}, std {s[0]:.2f}")

##############################################################################
# 7. When there's no formula: MCMC
##############################################################################
# MCMC from scratch: sample a posterior that has no neat formula with the Metropolis algorithm
data = np.array([2.1, 2.9, 3.4, 2.2, 8.5, 3.0, 2.7])        # one suspicious value (8.5)
def log_post(mu):                                          # Cauchy likelihood (robust to outliers) and normal prior
    return np.sum(stats.cauchy.logpdf(data, loc=mu, scale=0.5)) + stats.norm.logpdf(mu, 0, 10)
rng = np.random.default_rng(3)
mu, chain, accepted = 0.0, [], 0
for step in range(20000):
    prop = mu + rng.normal(0, 0.5)                         # propose a small random move
    if np.log(rng.random()) < log_post(prop) - log_post(mu):
        mu, accepted = prop, accepted + 1                  # accept with probability min(1, ratio)
    chain.append(mu)
chain = np.array(chain[2000:])                             # drop the warm-up
print("acceptance rate:", round(accepted / 20000, 2))
print("posterior mean of the centre:", round(chain.mean(), 2), "  95% interval:", np.round(np.percentile(chain, [2.5, 97.5]), 2))
print("ordinary mean of the data, for comparison:", round(data.mean(), 2))

##############################################################################
# 8. Deciding under uncertainty: Thompson sampling
##############################################################################
# Thompson sampling: a bandit that learns which of 3 page designs converts best while it runs
true_rates = np.array([0.04, 0.05, 0.065])
wins, losses = np.ones(3), np.ones(3)                      # Beta(1, 1) prior for each design
rng = np.random.default_rng(4)
shown = np.zeros(3, int)
for visitor in range(10000):
    choice = np.argmax(rng.beta(wins, losses))             # sample a plausible rate for each, show the best
    shown[choice] += 1
    if rng.random() < true_rates[choice]: wins[choice] += 1
    else: losses[choice] += 1
print("visitors shown each design:", shown.tolist())
print("conversions:", int(wins.sum() - 3), "  versus a fixed even split (expected):", round(10000 * true_rates.mean()))

##############################################################################
# 9. In Python: Bayesian ridge with uncertainty
##############################################################################
import numpy as np
import pandas as pd
from sklearn.linear_model import BayesianRidge

df = pd.read_csv(DATA / "houses.csv")   # download it from Lesson 1
X, y = df[["size_m2", "dist_km", "age_yrs"]], df["price_lakh"]
model = BayesianRidge().fit(X, y)
new = pd.DataFrame({"size_m2": [100, 200], "dist_km": [8, 30], "age_yrs": [5, 1]})
mean, std = model.predict(new, return_std=True)
for (_, h), m, s in zip(new.iterrows(), mean, std):
    print(f"{h.size_m2:.0f} m², {h.dist_km:.0f} km, {h.age_yrs:.0f} yrs: {m:.0f} lakh ± {1.96 * s:.0f} (95%)")

##############################################################################
# 12. Going deeper: prior sensitivity and checking MCMC
##############################################################################
from scipy import stats
for visitors, conv in [(50, 3), (500, 30), (5000, 300)]:
    row = []
    for name, a, b in [("flat", 1, 1), ("sceptical", 10, 190), ("optimistic", 30, 170)]:
        post = stats.beta(a + conv, b + visitors - conv)
        row.append(f"{name} {post.mean():.3f}")
    print(f"{visitors:5d} visitors (6% converted):", "   ".join(row))
import numpy as np
data = np.array([2.9, 3.1, 2.4, 3.3, 2.7, 8.5, 2.8])
def log_post(m):
    return -np.sum(np.log1p((data - m) ** 2)) - m ** 2 / 200       # Cauchy likelihood, wide normal prior
def chain(start, step, n=4000, seed=0):
    rng, m, out = np.random.default_rng(seed), start, []
    for _ in range(n):
        prop = m + rng.normal(0, step)
        if np.log(rng.random()) < log_post(prop) - log_post(m):
            m = prop
        out.append(m)
    return np.array(out[n // 2:])                                    # drop the first half as warm-up
def r_hat(chains):
    c = np.array(chains); n = c.shape[1]
    W, B = c.var(axis=1, ddof=1).mean(), n * c.mean(axis=1).var(ddof=1)
    return np.sqrt(((n - 1) / n * W + B / n) / W)
for step in [0.5, 0.005]:
    chains = [chain(s, step, seed=i) for i, s in enumerate([-10, 0, 10, 20])]
    print("step", step, " chain means", [round(float(c.mean()), 2) for c in chains], " R-hat", round(float(r_hat(chains)), 2))

##############################################################################
# Running example: Chennai Homes
#
# The same 12-house dataset used in every lesson (data/houses.csv in the course folder).
##############################################################################
import pandas as pd
import numpy as np
df = pd.read_csv(DATA / "houses.csv")
from scipy import stats
for area, g in df.groupby("area"):
    a, b = 1 + g.sold_fast.sum(), 1 + (1 - g.sold_fast).sum()     # Beta(1, 1) prior
    lo, hi = stats.beta(a, b).ppf([0.05, 0.95])
    print(f"{area:9s} sold fast {g.sold_fast.sum()} of {len(g)}  posterior mean {a / (a + b):.2f}  90% interval [{lo:.2f}, {hi:.2f}]")
