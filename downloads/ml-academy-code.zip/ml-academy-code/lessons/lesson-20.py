"""Lesson 20: Feature Engineering, Pipelines & Final Project — all the code from the lesson, as one script.

Part of the ML Academy course. Run it with:  python lesson-20.py
(works from any folder; the data is read from ../data/)
"""
from pathlib import Path
DATA = Path(__file__).resolve().parent.parent / "data"   # the course's data folder

##############################################################################
# 9. Final project: predicting customer churn
##############################################################################
import numpy as np
import pandas as pd

rng = np.random.default_rng(42)
n = 2000
df = pd.DataFrame({
    "tenure_months": rng.integers(1, 73, n),
    "monthly_charge": rng.normal(65, 20, n).clip(15, 130).round(2),
    "support_calls": rng.poisson(1.5, n),
    "contract": rng.choice(["month-to-month", "one-year", "two-year"], n, p=[0.55, 0.25, 0.20]),
    "payment": rng.choice(["card", "bank", "check"], n, p=[0.4, 0.35, 0.25]),
    "city": rng.choice(["Chennai", "Mumbai", "Delhi", "Pune"], n),
})
df["total_spent"] = (df["tenure_months"] * df["monthly_charge"] * rng.normal(1, 0.05, n)).round(2)
score = (-2.0 + 1.6 * (df["contract"] == "month-to-month") - 0.035 * df["tenure_months"]
         + 0.018 * df["monthly_charge"] + 0.45 * df["support_calls"] + 0.5 * (df["payment"] == "check"))
df["churned"] = (rng.random(n) < 1 / (1 + np.exp(-score))).astype(int)
for col, frac in [("monthly_charge", 0.05), ("payment", 0.04)]:     # real data has gaps
    df.loc[rng.random(n) < frac, col] = np.nan

print(df.shape)
print(df.head(3).to_string())
print("churn rate:", round(df["churned"].mean(), 3))
print(df.isna().sum()[df.isna().sum() > 0].to_dict())
from sklearn.model_selection import train_test_split

X = df.drop(columns="churned")
y = df["churned"]
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, stratify=y, random_state=0)
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler, OneHotEncoder, FunctionTransformer

def add_features(X):
    X = X.copy()
    X["charge_per_call"] = X["monthly_charge"] / (X["support_calls"] + 1)   # a ratio feature
    X["log_total_spent"] = np.log1p(X["total_spent"])                       # tame the skew
    return X

numeric = ["tenure_months", "monthly_charge", "support_calls", "total_spent",
           "charge_per_call", "log_total_spent"]
categorical = ["contract", "payment", "city"]

preprocess = ColumnTransformer([
    ("num", Pipeline([("impute", SimpleImputer(strategy="median")),
                      ("scale", StandardScaler())]), numeric),
    ("cat", Pipeline([("impute", SimpleImputer(strategy="most_frequent")),
                      ("onehot", OneHotEncoder(handle_unknown="ignore"))]), categorical),
])
from sklearn.dummy import DummyClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier, HistGradientBoostingClassifier
from sklearn.model_selection import cross_val_score

candidates = {
    "baseline (majority)": DummyClassifier(strategy="most_frequent"),
    "logistic regression": LogisticRegression(max_iter=1000),
    "random forest": RandomForestClassifier(n_estimators=300, random_state=0),
    "gradient boosting": HistGradientBoostingClassifier(random_state=0),
}
for name, clf in candidates.items():
    pipe = Pipeline([("features", FunctionTransformer(add_features)),
                     ("prep", preprocess), ("model", clf)])
    s = cross_val_score(pipe, X_train, y_train, cv=5, scoring="roc_auc")
    print(f"{name:22s} ROC-AUC {s.mean():.3f} ± {s.std():.3f}")
from sklearn.model_selection import GridSearchCV

pipe = Pipeline([("features", FunctionTransformer(add_features)), ("prep", preprocess),
                 ("model", LogisticRegression(max_iter=1000))])
search = GridSearchCV(pipe, {"model__C": [0.01, 0.1, 1, 10]}, cv=5, scoring="roc_auc")
search.fit(X_train, y_train)
print("best C:", search.best_params_["model__C"], " CV ROC-AUC:", round(search.best_score_, 3))
from sklearn.metrics import roc_auc_score, classification_report

best = search.best_estimator_
proba = best.predict_proba(X_test)[:, 1]
print("test ROC-AUC:", round(roc_auc_score(y_test, proba), 3))
print(classification_report(y_test, (proba >= 0.5).astype(int), target_names=["stayed", "churned"]))
names = best.named_steps["prep"].get_feature_names_out()
coefs = best.named_steps["model"].coef_[0]
for name, c in sorted(zip(names, coefs), key=lambda t: -abs(t[1]))[:5]:
    print(f"{name:32s} {c:+.2f}")
import joblib

joblib.dump(best, "churn_model.joblib")
reloaded = joblib.load("churn_model.joblib")       # only ever load files you trust!

new_customer = pd.DataFrame([{"tenure_months": 3, "monthly_charge": 95.0, "support_calls": 4,
                              "contract": "month-to-month", "payment": "check", "city": "Pune",
                              "total_spent": 285.0}])
print("churn probability:", round(reloaded.predict_proba(new_customer)[0, 1], 3))

##############################################################################
# Running example: Chennai Homes
#
# The same 12-house dataset used in every lesson (data/houses.csv in the course folder).
##############################################################################
import pandas as pd
import numpy as np
df = pd.read_csv(DATA / "houses.csv")
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.linear_model import Ridge
from sklearn.model_selection import cross_val_score
df.loc[3, "age_yrs"] = np.nan                     # pretend one value is missing
num = ["size_m2", "bedrooms", "dist_km", "age_yrs"]
numeric = Pipeline([("impute", SimpleImputer(strategy="median")), ("scale", StandardScaler())])
with_area = ColumnTransformer([("num", numeric, num), ("cat", OneHotEncoder(handle_unknown="ignore"), ["area"])])
numbers_only = ColumnTransformer([("num", numeric, num)])
for name, prep in [("numbers only", numbers_only), ("numbers + area", with_area)]:
    model = Pipeline([("prep", prep), ("ridge", Ridge(alpha=1.0))])
    mae = -cross_val_score(model, df, df["price_lakh"], cv=4, scoring="neg_mean_absolute_error").mean()
    print(f"{name:15s} cross-validated MAE: {mae:.1f} lakh")
