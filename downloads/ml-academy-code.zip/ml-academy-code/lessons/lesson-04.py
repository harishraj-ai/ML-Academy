"""Lesson 4: Probability & Statistics — all the code from the lesson, as one script.

Part of the ML Academy course. Run it with:  python lesson-04.py
(works from any folder; the data is read from ../data/)
"""
from pathlib import Path
DATA = Path(__file__).resolve().parent.parent / "data"   # the course's data folder

##############################################################################
# 12. In Python
##############################################################################
import numpy as np

scores = np.array([4, 6, 8, 10, 12])
print(scores.mean())           # 8.0
print(scores.var())            # 8.0   (divides by n)
print(scores.std())            # 2.828...
print(np.median([30, 35, 40, 45, 1000]))   # 40.0

z = (scores - scores.mean()) / scores.std()
print(z.round(2))              # [-1.41 -0.71  0.    0.71  1.41]

# Bayes: the medical test
p_d, sens, fpr = 0.01, 0.90, 0.05
p_pos = sens * p_d + fpr * (1 - p_d)
print(round(sens * p_d / p_pos, 3))        # 0.154

# Sample 100,000 heights and check the 68-95-99.7 rule
rng = np.random.default_rng(0)
h = rng.normal(170, 10, size=100_000)
print(np.mean(np.abs(h - 170) < 20))       # ≈ 0.95

##############################################################################
# Running example: Chennai Homes
#
# The same 12-house dataset used in every lesson (data/houses.csv in the course folder).
##############################################################################
import pandas as pd
import numpy as np
df = pd.read_csv(DATA / "houses.csv")
p = df["price_lakh"]
print("mean", round(p.mean(), 2), "std", round(p.std(ddof=0), 2))
print("z-score of house 12:", round((96 - p.mean()) / p.std(ddof=0), 2))
print("P(sold fast) =", df["sold_fast"].mean())
central = df[df["area"] == "Central"]
print("P(sold fast | Central) =", central["sold_fast"].mean())
print("P(Central | sold fast) =", round((df[df["sold_fast"] == 1]["area"] == "Central").mean(), 3))
