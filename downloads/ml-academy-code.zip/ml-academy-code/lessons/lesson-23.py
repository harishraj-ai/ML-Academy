"""Lesson 23: Hyperparameter Tuning & Model Selection — all the code from the lesson, as one script.

Part of the ML Academy course. Run it with:  python lesson-23.py
(works from any folder; the data is read from ../data/)
"""

##############################################################################
# 2. Seeing one hyperparameter at a time: validation curves
##############################################################################
import numpy as np
from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import validation_curve
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC

X, y = load_breast_cancer(return_X_y=True)
model = make_pipeline(StandardScaler(), SVC())
gammas = [0.0001, 0.001, 0.01, 0.1, 1]
train, val = validation_curve(model, X, y, param_name="svc__gamma", param_range=gammas, cv=5)
for g, a, b in zip(gammas, train.mean(axis=1), val.mean(axis=1)):
    print(f"gamma {g:<6}: train accuracy {a:.3f}   cross-validated accuracy {b:.3f}")

##############################################################################
# 3. Grid search
##############################################################################
from sklearn.model_selection import GridSearchCV, train_test_split

X_tr, X_te, y_tr, y_te = train_test_split(X, y, test_size=0.25, random_state=0, stratify=y)
grid = {"svc__C": [0.1, 1, 10, 100], "svc__gamma": [0.0001, 0.001, 0.01, 0.1]}
search = GridSearchCV(model, grid, cv=5).fit(X_tr, y_tr)
print("settings tried:", len(search.cv_results_["params"]))
print("best settings:", search.best_params_)
print("best cross-validated accuracy:", round(search.best_score_, 3))
print("test accuracy of the refitted best model:", round(search.score(X_te, y_te), 3))

##############################################################################
# 4. Random search
##############################################################################
from sklearn.model_selection import RandomizedSearchCV
from scipy.stats import loguniform

dists = {"svc__C": loguniform(0.01, 1000), "svc__gamma": loguniform(1e-5, 1)}
rs = RandomizedSearchCV(model, dists, n_iter=16, cv=5, random_state=0).fit(X_tr, y_tr)
print("best settings:", {k: round(float(v), 4) for k, v in rs.best_params_.items()})
print("best cross-validated accuracy:", round(rs.best_score_, 3), "  test accuracy:", round(rs.score(X_te, y_te), 3))

##############################################################################
# 6. Smarter searches: Bayesian optimisation and successive halving
##############################################################################
from sklearn.experimental import enable_halving_search_cv  # noqa: F401  (switches the feature on)
from sklearn.model_selection import HalvingRandomSearchCV

hs = HalvingRandomSearchCV(model, dists, n_candidates=48, factor=3, cv=5, random_state=0).fit(X_tr, y_tr)
for it, (n_cand, n_res) in enumerate(zip(hs.n_candidates_, hs.n_resources_)):
    print(f"round {it + 1}: {n_cand:2d} candidates, each trained on {n_res} rows")
print("best cross-validated accuracy:", round(hs.best_score_, 3))

##############################################################################
# 7. Reporting honestly: nested cross-validation
##############################################################################
from sklearn.model_selection import cross_val_score, KFold

inner, outer = KFold(5, shuffle=True, random_state=1), KFold(5, shuffle=True, random_state=2)
tuned = GridSearchCV(model, grid, cv=inner)
nested = cross_val_score(tuned, X, y, cv=outer)
print("nested CV accuracy:", round(nested.mean(), 3), "+/-", round(nested.std(), 3))

##############################################################################
# 8. Choosing between models: the simplest good one
##############################################################################
from sklearn.tree import DecisionTreeClassifier

# The one-standard-error rule: prefer the simplest model within 1 SE of the best
depths = list(range(1, 11))
res = GridSearchCV(DecisionTreeClassifier(random_state=0), {"max_depth": depths}, cv=10).fit(X_tr, y_tr).cv_results_
mean, se = res["mean_test_score"], res["std_test_score"] / np.sqrt(10)
best = int(np.argmax(mean))
simplest = next(i for i in range(len(depths)) if mean[i] >= mean[best] - se[best])
print("best depth by score:", depths[best], " CV accuracy", round(mean[best], 3), " SE", round(se[best], 3))
print("simplest depth within 1 SE:", depths[simplest], " CV accuracy", round(mean[simplest], 3))

##############################################################################
# 9. In Python: a tuning recipe
##############################################################################
from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import RandomizedSearchCV, StratifiedKFold, train_test_split
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from scipy.stats import loguniform

X, y = load_breast_cancer(return_X_y=True)
X_tr, X_te, y_tr, y_te = train_test_split(X, y, test_size=0.25, random_state=0, stratify=y)
pipe = make_pipeline(StandardScaler(), LogisticRegression(max_iter=5000))
search = RandomizedSearchCV(pipe, {"logisticregression__C": loguniform(1e-3, 1e3)},
                            n_iter=30, cv=StratifiedKFold(5, shuffle=True, random_state=0),
                            scoring="roc_auc", random_state=0).fit(X_tr, y_tr)
print("best C:", round(float(search.best_params_["logisticregression__C"]), 4))
print("CV ROC-AUC:", round(search.best_score_, 4), "  test ROC-AUC:", round(search.score(X_te, y_te), 4))

##############################################################################
# 12. Going deeper: Bayesian optimisation from scratch
##############################################################################
import numpy as np
import warnings
warnings.filterwarnings("ignore")          # the GP optimiser warns about its bounds on tiny data
from scipy.stats import norm
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import Matern, ConstantKernel

# A made-up "validation score vs log10(learning rate)" curve with its peak near x = -2.3
f = lambda x: np.exp(-(x + 2.3) ** 2 / 0.3) * 0.3 + 0.65 + 0.02 * np.sin(5 * x)
grid = np.linspace(-5, 0, 501)[:, None]

def bayes_opt(n_iter, seed):
    rng = np.random.default_rng(seed)
    X = rng.uniform(-5, 0, size=(3, 1)); y = f(X[:, 0])               # 3 random starting points
    kernel = ConstantKernel(1.0, (1e-3, 1e3)) * Matern(length_scale=0.5, length_scale_bounds=(0.05, 5), nu=2.5)
    gp = GaussianProcessRegressor(kernel, alpha=1e-6, normalize_y=True, n_restarts_optimizer=3, random_state=0)
    for _ in range(n_iter - 3):
        gp.fit(X, y)
        mu, sd = gp.predict(grid, return_std=True)
        z = (mu - y.max()) / np.maximum(sd, 1e-9)
        ei = (mu - y.max()) * norm.cdf(z) + sd * norm.pdf(z)             # expected improvement
        x_next = grid[np.argmax(ei)]
        X = np.vstack([X, x_next]); y = np.append(y, f(x_next[0]))
    return y.max()

def random_search(n_iter, seed):
    return f(np.random.default_rng(seed).uniform(-5, 0, n_iter)).max()

best = f(grid[:, 0]).max()
for n in [5, 10, 15]:
    bo = np.mean([best - bayes_opt(n, s) for s in range(20)])
    rs = np.mean([best - random_search(n, s) for s in range(20)])
    print(f"{n:2d} trials: average gap to the best score, Bayesian {bo:.4f}   random {rs:.4f}")
