"""Lesson 9: Evaluating Models — all the code from the lesson, as one script.

Part of the ML Academy course. Run it with:  python lesson-09.py
(works from any folder; the data is read from ../data/)
"""
from pathlib import Path
DATA = Path(__file__).resolve().parent.parent / "data"   # the course's data folder

##############################################################################
# 12. In Python
##############################################################################
from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import make_pipeline
from sklearn.metrics import confusion_matrix, classification_report, roc_auc_score

X, y = load_breast_cancer(return_X_y=True)
y = 1 - y        # make "malignant" the positive class (1)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, stratify=y, random_state=0)

model = make_pipeline(StandardScaler(), LogisticRegression(max_iter=1000)).fit(X_train, y_train)
proba = model.predict_proba(X_test)[:, 1]          # P(malignant)

for threshold in [0.5, 0.2]:
    pred = (proba >= threshold).astype(int)
    tn, fp, fn, tp = confusion_matrix(y_test, pred).ravel()
    print(f"threshold {threshold}: TP={tp} FN={fn} FP={fp} TN={tn}  "
          f"precision={tp/(tp+fp):.3f} recall={tp/(tp+fn):.3f}")

print("ROC-AUC:", round(roc_auc_score(y_test, proba), 3))
print(classification_report(y_test, (proba >= 0.5).astype(int), target_names=["benign", "malignant"]))

##############################################################################
# Running example: Chennai Homes
#
# The same 12-house dataset used in every lesson (data/houses.csv in the course folder).
##############################################################################
import pandas as pd
import numpy as np
df = pd.read_csv(DATA / "houses.csv")
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import cross_val_predict
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
from sklearn.metrics import confusion_matrix, precision_score, recall_score
clf = make_pipeline(StandardScaler(), LogisticRegression())
pred = cross_val_predict(clf, df[["dist_km", "age_yrs"]], df["sold_fast"], cv=4)   # honest predictions
tn, fp, fn, tp = confusion_matrix(df["sold_fast"], pred).ravel()
print("TP", tp, "FP", fp, "FN", fn, "TN", tn)
print("precision", round(precision_score(df["sold_fast"], pred), 2), "recall", round(recall_score(df["sold_fast"], pred), 2))
