"""Lesson 9: Evaluating Models — all the code from the lesson, as one script.

Part of the ML Academy course. Run it with:  python lesson-09.py
(works from any folder; the data is read from ../data/)
"""
from pathlib import Path
DATA = Path(__file__).resolve().parent.parent / "data"   # the course's data folder

##############################################################################
# 12. In Python
##############################################################################
from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import make_pipeline
from sklearn.metrics import confusion_matrix, classification_report, roc_auc_score

X, y = load_breast_cancer(return_X_y=True)
y = 1 - y        # make "malignant" the positive class (1)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, stratify=y, random_state=0)

model = make_pipeline(StandardScaler(), LogisticRegression(max_iter=1000)).fit(X_train, y_train)
proba = model.predict_proba(X_test)[:, 1]          # P(malignant)

for threshold in [0.5, 0.2]:
    pred = (proba >= threshold).astype(int)
    tn, fp, fn, tp = confusion_matrix(y_test, pred).ravel()
    print(f"threshold {threshold}: TP={tp} FN={fn} FP={fp} TN={tn}  "
          f"precision={tp/(tp+fp):.3f} recall={tp/(tp+fn):.3f}")

print("ROC-AUC:", round(roc_auc_score(y_test, proba), 3))
print(classification_report(y_test, (proba >= 0.5).astype(int), target_names=["benign", "malignant"]))

##############################################################################
# 15. Going deeper: comparing models honestly
##############################################################################
import numpy as np
from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import roc_auc_score

X, y = load_breast_cancer(return_X_y=True)
Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=0.3, random_state=0, stratify=y)
logreg = make_pipeline(StandardScaler(), LogisticRegression(max_iter=1000)).fit(Xtr, ytr)
tree = DecisionTreeClassifier(max_depth=3, random_state=0).fit(Xtr, ytr)
p_lr, p_tr = logreg.predict_proba(Xte)[:, 1], tree.predict_proba(Xte)[:, 1]

rng = np.random.default_rng(0)
boot = []
for _ in range(2000):
    i = rng.integers(0, len(yte), len(yte))            # resample test cases with replacement
    if len(np.unique(yte[i])) == 2:
        boot.append(roc_auc_score(yte[i], p_lr[i]) - roc_auc_score(yte[i], p_tr[i]))
print("AUC: logistic", round(roc_auc_score(yte, p_lr), 3), " tree", round(roc_auc_score(yte, p_tr), 3))
print("95% bootstrap interval for the difference:", np.round(np.percentile(boot, [2.5, 97.5]), 3))
from scipy import stats

# McNemar's test: do the two models make different numbers of mistakes on the SAME cases?
right_lr, right_tr = logreg.predict(Xte) == yte, tree.predict(Xte) == yte
b = np.sum(right_lr & ~right_tr)          # logistic right, tree wrong
c = np.sum(~right_lr & right_tr)          # tree right, logistic wrong
print("accuracy: logistic", round(right_lr.mean(), 3), " tree", round(right_tr.mean(), 3))
print("cases only logistic got right:", b, "  only the tree got right:", c)
print("McNemar exact p-value:", round(stats.binomtest(b, b + c, 0.5).pvalue, 4))
# Choosing the threshold from costs: a missed cancer (false negative) costs 20, a false alarm costs 1
y_bad = 1 - yte                            # in this dataset 0 = malignant, so flip: 1 = malignant
p_bad = 1 - p_lr
for t in [0.5, 0.2, 0.1, 0.05]:
    flag = p_bad >= t
    fn, fp = np.sum(~flag & (y_bad == 1)), np.sum(flag & (y_bad == 0))
    print(f"threshold {t:4.2f}: missed {fn:2d}, false alarms {fp:2d}, total cost {20 * fn + fp}")
print("theory: flag when p is above cost_FP / (cost_FP + cost_FN), which is", round(1 / 21, 3))
from sklearn.metrics import average_precision_score

# Same model quality, rarer positives: scores of positives ~ N(1.5, 1), negatives ~ N(0, 1)
rng = np.random.default_rng(1)
for n_pos in [10000, 1000, 100]:
    s = np.r_[rng.normal(1.5, 1, n_pos), rng.normal(0, 1, 10000)]
    t = np.r_[np.ones(n_pos), np.zeros(10000)]
    print(f"positives {t.mean():6.1%}: ROC-AUC {roc_auc_score(t, s):.3f}   average precision {average_precision_score(t, s):.3f}   (random model's AP {t.mean():.3f})")

##############################################################################
# Running example: Chennai Homes
#
# The same 12-house dataset used in every lesson (data/houses.csv in the course folder).
##############################################################################
import pandas as pd
import numpy as np
df = pd.read_csv(DATA / "houses.csv")
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import cross_val_predict
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
from sklearn.metrics import confusion_matrix, precision_score, recall_score
clf = make_pipeline(StandardScaler(), LogisticRegression())
pred = cross_val_predict(clf, df[["dist_km", "age_yrs"]], df["sold_fast"], cv=4)   # honest predictions
tn, fp, fn, tp = confusion_matrix(df["sold_fast"], pred).ravel()
print("TP", tp, "FP", fp, "FN", fn, "TN", tn)
print("precision", round(precision_score(df["sold_fast"], pred), 2), "recall", round(recall_score(df["sold_fast"], pred), 2))
