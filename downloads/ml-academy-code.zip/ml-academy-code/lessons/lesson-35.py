"""Lesson 35: Graphical Models & Hidden Markov Models — all the code from the lesson, as one script.

Part of the ML Academy course. Run it with:  python lesson-35.py
(works from any folder; the data is read from ../data/)
"""
from pathlib import Path
DATA = Path(__file__).resolve().parent.parent / "data"   # the course's data folder

##############################################################################
# 2. Bayesian networks
##############################################################################
import itertools
import numpy as np
# A small Bayesian network: Rain → Sprinkler, and both → WetGrass.
P_rain = {1: 0.2, 0: 0.8}
P_sprinkler = {1: {1: 0.01, 0: 0.99}, 0: {1: 0.4, 0: 0.6}}          # P(sprinkler | rain)
P_wet = {(1, 1): 0.99, (1, 0): 0.9, (0, 1): 0.8, (0, 0): 0.0}         # P(wet = 1 | sprinkler, rain)
def joint(r, s, w):
    pw = P_wet[(s, r)]
    return P_rain[r] * P_sprinkler[r][s] * (pw if w else 1 - pw)
def query(target, evidence):
    num = den = 0.0
    for r, s, w in itertools.product([0, 1], repeat=3):
        vals = {"rain": r, "sprinkler": s, "wet": w}
        if all(vals[k] == v for k, v in evidence.items()):
            p = joint(r, s, w); den += p
            if vals[target] == 1: num += p
    return num / den
print("P(rain)                         ", round(P_rain[1], 3))
print("P(rain | grass is wet)          ", round(query("rain", {"wet": 1}), 3))
print("P(rain | wet, sprinkler was on) ", round(query("rain", {"wet": 1, "sprinkler": 1}), 3))

##############################################################################
# 3. Hidden Markov models
##############################################################################
# Two-state weather HMM: hidden Sunny/Rainy, observed activity Walk/Shop/Clean.
states, obs_names = ["Sunny", "Rainy"], ["Walk", "Shop", "Clean"]
pi = np.array([0.6, 0.4])
T = np.array([[0.8, 0.2], [0.3, 0.7]])                               # T[i, j] = P(next j | now i)
E = np.array([[0.6, 0.3, 0.1], [0.1, 0.4, 0.5]])                     # E[i, k] = P(observe k | state i)
def forward(obs):
    alpha = pi * E[:, obs[0]]
    for o in obs[1:]:
        alpha = (alpha @ T) * E[:, o]
    return alpha.sum()
week = [0, 0, 1, 2, 2, 1, 0]                                         # Walk Walk Shop Clean Clean Shop Walk
print("P(this week's activities) under the model:", f"{forward(week):.6f}")
print("same activities, shuffled order:", f"{forward([2, 0, 2, 0, 1, 0, 1]):.6f}")

##############################################################################
# 4. Decoding: the Viterbi algorithm
##############################################################################
def viterbi(obs):
    logd = np.log(pi) + np.log(E[:, obs[0]]); back = []
    for o in obs[1:]:
        cand = logd[:, None] + np.log(T)                             # cand[i, j]: best path ending i, then j
        back.append(cand.argmax(axis=0)); logd = cand.max(axis=0) + np.log(E[:, o])
    path = [int(logd.argmax())]
    for b in reversed(back):
        path.append(int(b[path[-1]]))
    return path[::-1]
print("activities:", [obs_names[o] for o in week])
print("most likely weather:", [states[s] for s in viterbi(week)])

##############################################################################
# 6. Learning an HMM's parameters
##############################################################################
rng = np.random.default_rng(0)
def sample(n):
    z = [rng.choice(2, p=pi)]
    for _ in range(n - 1): z.append(rng.choice(2, p=T[z[-1]]))
    return np.array(z), np.array([rng.choice(3, p=E[s]) for s in z])
z_train, o_train = sample(5000)
# Learn the parameters by counting, from labelled sequences
T_hat = np.array([[np.mean(z_train[1:][z_train[:-1] == i] == j) for j in range(2)] for i in range(2)])
E_hat = np.array([[np.mean(o_train[z_train == i] == k) for k in range(3)] for i in range(2)])
print("learned transitions:", T_hat.round(2).tolist(), "  true:", T.tolist())
print("learned emissions:  ", E_hat.round(2).tolist())

##############################################################################
# 7. Why the sequence matters
##############################################################################
z_test, o_test = sample(2000)
best_guess = np.argmax(E, axis=0)[o_test]                           # most likely state for each day alone
acc_alone = (best_guess == z_test).mean()
acc_vit = (np.array(viterbi(list(o_test))) == z_test).mean()
print("each day on its own:", round(acc_alone, 3), "  Viterbi using the sequence:", round(acc_vit, 3))
stationary = np.linalg.matrix_power(T, 100)[0]
print("long-run share of sunny days:", round(stationary[0], 3), "  observed in the sample:", round((z_test == 0).mean(), 3))

##############################################################################
# 9. In Python: tracking a machine's hidden health
##############################################################################
import numpy as np

pi = np.array([0.95, 0.05])                    # healthy, worn
T = np.array([[0.97, 0.03], [0.0, 1.0]])       # wear never repairs itself
E = np.array([[0.9, 0.1], [0.3, 0.7]])         # P(normal, alarm | state)
readings = [0, 0, 1, 0, 0, 1, 1, 0, 1, 1]      # 0 normal, 1 alarm
belief = pi * E[:, readings[0]]; belief /= belief.sum()
history = [belief[1]]
for r in readings[1:]:
    belief = (belief @ T) * E[:, r]; belief /= belief.sum()
    history.append(belief[1])
print("readings:        ", readings)
print("P(worn) after each:", [round(float(p), 2) for p in history])
print("first reading where P(worn) > 0.5:", int(np.argmax(np.array(history) > 0.5)) + 1)

##############################################################################
# 12. Going deeper: forward–backward and Baum–Welch
##############################################################################
import numpy as np
pi = np.array([0.6, 0.4]); T = np.array([[0.8, 0.2], [0.3, 0.7]]); E = np.array([[0.6, 0.3, 0.1], [0.1, 0.4, 0.5]])
obs = [0, 1, 1, 2, 1, 0]                                   # Walk Shop Shop Clean Shop Walk
def forward_backward(o):
    n = len(o); a = np.zeros((n, 2)); b = np.ones((n, 2))
    a[0] = pi * E[:, o[0]]
    for t in range(1, n): a[t] = (a[t - 1] @ T) * E[:, o[t]]
    for t in range(n - 2, -1, -1): b[t] = T @ (E[:, o[t + 1]] * b[t + 1])
    post = a * b
    return post / post.sum(axis=1, keepdims=True)
print("P(rainy) each day:", np.round(forward_backward(obs)[:, 1], 3).tolist())
rng = np.random.default_rng(0)
z = [0]
for _ in range(2999): z.append(rng.choice(2, p=T[z[-1]]))
o = np.array([rng.choice(3, p=E[s]) for s in z])
# Baum–Welch from the observations only, starting from a rough guess
Th, Eh, ph = np.array([[0.6, 0.4], [0.4, 0.6]]), np.array([[0.4, 0.3, 0.3], [0.2, 0.3, 0.5]]), np.array([0.5, 0.5])
for it in range(50):
    n = len(o); a = np.zeros((n, 2)); b = np.ones((n, 2)); c = np.zeros(n)
    a[0] = ph * Eh[:, o[0]]; c[0] = a[0].sum(); a[0] /= c[0]
    for t in range(1, n): a[t] = (a[t - 1] @ Th) * Eh[:, o[t]]; c[t] = a[t].sum(); a[t] /= c[t]
    for t in range(n - 2, -1, -1): b[t] = Th @ (Eh[:, o[t + 1]] * b[t + 1]) / c[t + 1]
    gam = a * b
    xi = np.einsum("ti,ij,tj->ij", a[:-1], Th, Eh[:, o[1:]].T * b[1:] / c[1:, None])
    Th = xi / xi.sum(axis=1, keepdims=True)
    Eh = np.array([[gam[o == k, i].sum() for k in range(3)] for i in range(2)]) / gam.sum(axis=0)[:, None]
    ph = gam[0]
print("log-likelihood after 50 iterations:", round(float(np.log(c).sum()), 1))
print("learned transitions:", np.round(Th, 2).tolist())
print("learned emissions:  ", np.round(Eh, 2).tolist())

##############################################################################
# Running example: Chennai Homes
#
# The same 12-house dataset used in every lesson (data/houses.csv in the course folder).
##############################################################################
import pandas as pd
import numpy as np
df = pd.read_csv(DATA / "houses.csv")
df["metro"] = df.description.str.contains("metro").astype(int)
# A tiny Bayesian network learned by counting: Area → Metro, Area → SoldFast
p_area = df.area.value_counts(normalize=True)
p_metro = df.groupby("area").metro.mean(); p_fast = df.groupby("area").sold_fast.mean()
num = sum(p_area[a] * p_metro[a] * p_fast[a] for a in p_area.index)
den = sum(p_area[a] * p_metro[a] for a in p_area.index)
print("P(sold fast):", round(df.sold_fast.mean(), 3), "  P(sold fast | near metro), via area:", round(num / den, 3))
print("P(area | near metro):", {a: round(float(p_area[a] * p_metro[a] / den), 2) for a in p_area.index})
