"""Lesson 14: Random Forests & Boosting — all the code from the lesson, as one script.

Part of the ML Academy course. Run it with:  python lesson-14.py
(works from any folder; the data is read from ../data/)
"""
from pathlib import Path
DATA = Path(__file__).resolve().parent.parent / "data"   # the course's data folder

##############################################################################
# 11. In Python
##############################################################################
from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import cross_val_score
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import (RandomForestClassifier, AdaBoostClassifier,
                              GradientBoostingClassifier, HistGradientBoostingClassifier)

X, y = load_breast_cancer(return_X_y=True)
models = {
    "single tree": DecisionTreeClassifier(random_state=0),
    "random forest": RandomForestClassifier(n_estimators=300, random_state=0),
    "AdaBoost": AdaBoostClassifier(n_estimators=200, random_state=0),
    "gradient boosting": GradientBoostingClassifier(random_state=0),
    "hist. gradient boosting": HistGradientBoostingClassifier(random_state=0),
}
for name, model in models.items():
    s = cross_val_score(model, X, y, cv=5)
    print(f"{name:24s} {s.mean():.3f} ± {s.std():.3f}")

rf = RandomForestClassifier(n_estimators=300, oob_score=True, random_state=0).fit(X, y)
print("out-of-bag accuracy:", round(rf.oob_score_, 3))

##############################################################################
# 14. Going deeper: tuning ensembles and how XGBoost works
##############################################################################
import numpy as np
from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier

X, y = load_breast_cancer(return_X_y=True)
Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=0.3, random_state=0, stratify=y)
# max_features controls how different the trees are
for mf in [1.0, 0.5, "sqrt", 1]:
    rf = RandomForestClassifier(n_estimators=300, max_features=mf, oob_score=True, random_state=0, n_jobs=-1).fit(Xtr, ytr)
    preds = np.array([t.predict(Xte) for t in rf.estimators_])
    corr = np.corrcoef(preds)[np.triu_indices(len(preds), 1)].mean()
    print(f"max_features {str(mf):5}: tree-to-tree correlation {corr:.2f}   out-of-bag accuracy {rf.oob_score_:.3f}   test {rf.score(Xte, yte):.3f}")
from sklearn.ensemble import HistGradientBoostingClassifier

for lr in [1.0, 0.3, 0.1, 0.03]:
    gb = HistGradientBoostingClassifier(learning_rate=lr, max_iter=2000, early_stopping=True,
                                        validation_fraction=0.2, n_iter_no_change=30, random_state=0).fit(Xtr, ytr)
    print(f"learning rate {lr:4}: trees used {gb.n_iter_:4d}   test accuracy {gb.score(Xte, yte):.3f}")
from sklearn.ensemble import StackingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.neighbors import KNeighborsClassifier

base = [("forest", RandomForestClassifier(n_estimators=300, random_state=0)),
        ("boost", HistGradientBoostingClassifier(random_state=0)),
        ("knn", make_pipeline(StandardScaler(), KNeighborsClassifier(15)))]
for name, m in base:
    print(f"{name:7}: test accuracy {m.fit(Xtr, ytr).score(Xte, yte):.3f}")
stack = StackingClassifier(base, final_estimator=LogisticRegression(max_iter=1000), cv=5).fit(Xtr, ytr)
print(f"stacked: test accuracy {stack.score(Xte, yte):.3f}   blender weights {stack.final_estimator_.coef_.round(2)}")

##############################################################################
# Running example: Chennai Homes
#
# The same 12-house dataset used in every lesson (data/houses.csv in the course folder).
##############################################################################
import pandas as pd
import numpy as np
df = pd.read_csv(DATA / "houses.csv")
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import cross_val_score, LeaveOneOut
cols = ["size_m2", "bedrooms", "dist_km", "age_yrs"]
for name, m in [("single tree", DecisionTreeClassifier(random_state=0)),
                ("random forest", RandomForestClassifier(n_estimators=300, random_state=0))]:
    acc = cross_val_score(m, df[cols], df["sold_fast"], cv=LeaveOneOut()).mean()
    print(f"{name:14s} leave-one-out accuracy {acc:.2f}")
rf = RandomForestClassifier(n_estimators=300, random_state=0).fit(df[cols], df["sold_fast"])
print({c: round(float(v), 2) for c, v in zip(cols, rf.feature_importances_)})
