"""Lesson 14: Random Forests & Boosting — all the code from the lesson, as one script.

Part of the ML Academy course. Run it with:  python lesson-14.py
(works from any folder; the data is read from ../data/)
"""
from pathlib import Path
DATA = Path(__file__).resolve().parent.parent / "data"   # the course's data folder

##############################################################################
# 11. In Python
##############################################################################
from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import cross_val_score
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import (RandomForestClassifier, AdaBoostClassifier,
                              GradientBoostingClassifier, HistGradientBoostingClassifier)

X, y = load_breast_cancer(return_X_y=True)
models = {
    "single tree": DecisionTreeClassifier(random_state=0),
    "random forest": RandomForestClassifier(n_estimators=300, random_state=0),
    "AdaBoost": AdaBoostClassifier(n_estimators=200, random_state=0),
    "gradient boosting": GradientBoostingClassifier(random_state=0),
    "hist. gradient boosting": HistGradientBoostingClassifier(random_state=0),
}
for name, model in models.items():
    s = cross_val_score(model, X, y, cv=5)
    print(f"{name:24s} {s.mean():.3f} ± {s.std():.3f}")

rf = RandomForestClassifier(n_estimators=300, oob_score=True, random_state=0).fit(X, y)
print("out-of-bag accuracy:", round(rf.oob_score_, 3))

##############################################################################
# Running example: Chennai Homes
#
# The same 12-house dataset used in every lesson (data/houses.csv in the course folder).
##############################################################################
import pandas as pd
import numpy as np
df = pd.read_csv(DATA / "houses.csv")
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import cross_val_score, LeaveOneOut
cols = ["size_m2", "bedrooms", "dist_km", "age_yrs"]
for name, m in [("single tree", DecisionTreeClassifier(random_state=0)),
                ("random forest", RandomForestClassifier(n_estimators=300, random_state=0))]:
    acc = cross_val_score(m, df[cols], df["sold_fast"], cv=LeaveOneOut()).mean()
    print(f"{name:14s} leave-one-out accuracy {acc:.2f}")
rf = RandomForestClassifier(n_estimators=300, random_state=0).fit(df[cols], df["sold_fast"])
print({c: round(float(v), 2) for c, v in zip(cols, rf.feature_importances_)})
