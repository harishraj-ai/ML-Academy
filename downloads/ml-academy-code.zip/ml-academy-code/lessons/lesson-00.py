"""Lesson 0: Python, NumPy & pandas for Beginners — all the code from the lesson, as one script.

Part of the ML Academy course. Run it with:  python lesson-00.py
(works from any folder; the data is read from ../data/)
"""
from pathlib import Path
DATA = Path(__file__).resolve().parent.parent / "data"   # the course's data folder

##############################################################################
# 2. Running Python code
##############################################################################
print("Hello, machine learning!")

##############################################################################
# 3. Values, variables and arithmetic
##############################################################################
price = 72.5        # a decimal number (a float)
bedrooms = 3        # a whole number (an int)
city = "Chennai"     # text (a string)
print(price, bedrooms, city)
print(7 + 2, 7 - 2, 7 * 2, 7 / 2)
print(7 // 2, 7 % 2, 2 ** 10)
area = 12.5 * 8     # a variable can hold the result of a calculation
print(area)
count = 1
count = count + 1   # take the old value, add 1, store it back
count += 1          # a shorter way to write the same thing
print(count)

##############################################################################
# 4. Text and printing
##############################################################################
name = "house 7"
price = 84.1234
print(f"{name} costs {price:.2f} lakh")
print(name.upper(), len(name))   # a method, and the length of the string

##############################################################################
# 5. Lists and indexing
##############################################################################
prices = [58, 82, 55, 88, 96]
print(prices[0], prices[1], prices[-1])   # first, second, last
print(len(prices))                          # how many items
print(prices[1:3])     # items at positions 1 and 2
print(prices[:2])      # the first two
print(prices[2:])      # from position 2 to the end
prices.append(61)      # add an item at the end
print(prices)

##############################################################################
# 6. Dictionaries
##############################################################################
house = {"area": "Central", "size_m2": 120, "price_lakh": 88}
print(house["size_m2"])
house["sold_fast"] = True     # add a new key
print(house)

##############################################################################
# 7. Making decisions and repeating: if and for
##############################################################################
price = 96
if price > 90:
    print("expensive")
elif price > 60:
    print("mid-range")
else:
    print("affordable")
prices = [58, 82, 55, 88]
total = 0
for p in prices:
    total = total + p
print("total:", total, " average:", total / len(prices))
for step in range(3):
    print("step", step)
squares = [x ** 2 for x in [1, 2, 3, 4]]
print(squares)

##############################################################################
# 8. Functions
##############################################################################
def mse(y_true, y_pred):
    total = 0
    for t, p in zip(y_true, y_pred):   # zip walks through both lists together
        total += (p - t) ** 2
    return total / len(y_true)

print(mse([3, 5, 7], [2.5, 5, 8]))

##############################################################################
# 9. Libraries and import
##############################################################################
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
print("NumPy", np.__version__, "and pandas", pd.__version__, "loaded")

##############################################################################
# 10. NumPy: numbers in bulk
##############################################################################
x = np.array([1.0, 2.0, 3.0, 4.0])
print(x * 2)          # every element doubled
print(x + 10)
print(x ** 2)
print(x.mean(), x.sum(), x.max())
X = np.array([[120, 3, 4.0],
              [ 95, 2, 6.5],
              [150, 4, 12.0]])   # 3 houses × 3 features
print(X.shape)
print(X[0])           # the first row (house 1)
print(X[:, 0])        # the first column (sizes)
print(X.mean(axis=0)) # the average of each column
sizes = X[:, 0]
print(sizes > 100)
print(sizes[sizes > 100])
w = np.array([0.5, 2.0, -1.0])
print(X @ w)          # one prediction per house

##############################################################################
# 11. pandas: tables of data
##############################################################################
df = pd.read_csv(DATA / "houses.csv")
print(df.shape)                # (rows, columns)
print(df.columns.tolist())
print(df[["area", "size_m2", "price_lakh"]].head(4))   # the first 4 rows of three columns
print(df["price_lakh"].mean())
big = df[df["size_m2"] > 120]
print(len(big), "houses over 120 m²")
print(big[["id", "size_m2", "price_lakh"]])
print(df.groupby("area")["price_lakh"].mean().round(1))
df["price_per_m2"] = df["price_lakh"] / df["size_m2"]
print(df.sort_values("price_per_m2", ascending=False)[["id", "area", "price_per_m2"]].head(3).round(3))
