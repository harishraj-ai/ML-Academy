"""Lesson 5: Data, Features & Generalization — all the code from the lesson, as one script.

Part of the ML Academy course. Run it with:  python lesson-05.py
(works from any folder; the data is read from ../data/)
"""
from pathlib import Path
DATA = Path(__file__).resolve().parent.parent / "data"   # the course's data folder

##############################################################################
# 9. In Python
##############################################################################
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import PolynomialFeatures
from sklearn.linear_model import LinearRegression
from sklearn.pipeline import make_pipeline
from sklearn.metrics import mean_squared_error

rng = np.random.default_rng(0)
x = rng.uniform(-3, 3, 30)
y = np.sin(x) + rng.normal(0, 0.3, 30)          # hidden curve + noise
X = x.reshape(-1, 1)                             # sklearn wants a 2D matrix

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.5, random_state=1)

for degree in [1, 3, 9, 12]:
    model = make_pipeline(PolynomialFeatures(degree), LinearRegression())
    model.fit(X_train, y_train)
    train_mse = mean_squared_error(y_train, model.predict(X_train))
    test_mse = mean_squared_error(y_test, model.predict(X_test))
    print(f"degree {degree:2d}: train MSE {train_mse:.3f}   test MSE {test_mse:.3f}")
from sklearn.model_selection import cross_val_score

model = make_pipeline(PolynomialFeatures(3), LinearRegression())
scores = cross_val_score(model, X_train, y_train, cv=5, scoring="neg_mean_squared_error")
print(-scores.mean(), scores.std())     # mean MSE across the 5 folds, and its spread

##############################################################################
# 12. Going deeper: validation that you can trust
##############################################################################
import numpy as np
from sklearn.datasets import make_classification
from sklearn.model_selection import GridSearchCV, cross_val_score, KFold
from sklearn.svm import SVC

# A small, noisy problem where tuning can easily "overfit the validation folds"
X, y = make_classification(n_samples=120, n_features=40, n_informative=4, flip_y=0.2, random_state=0)
grid = {"C": [0.01, 0.1, 1, 10, 100], "gamma": [0.0001, 0.001, 0.01, 0.1, 1]}
inner, outer = KFold(5, shuffle=True, random_state=1), KFold(5, shuffle=True, random_state=2)

search = GridSearchCV(SVC(), grid, cv=inner).fit(X, y)
print("best score inside the search (optimistic):", round(search.best_score_, 3))
nested = cross_val_score(GridSearchCV(SVC(), grid, cv=inner), X, y, cv=outer)
print("nested cross-validation (honest):        ", round(nested.mean(), 3))
from sklearn.model_selection import TimeSeriesSplit
from sklearn.ensemble import RandomForestRegressor

# Daily sales that drift slowly over time: neighbouring days look alike
rng = np.random.default_rng(0)
t = np.arange(600)
trend = np.cumsum(rng.normal(0, 1, 600))                  # a slow random walk
Xt = np.column_stack([t, np.sin(2 * np.pi * t / 7)])      # day number and weekday pattern
yt = trend + 3 * Xt[:, 1] + rng.normal(0, 1, 600)

model = RandomForestRegressor(n_estimators=100, random_state=0)
shuffled = cross_val_score(model, Xt, yt, cv=KFold(5, shuffle=True, random_state=0), scoring="r2")
forward = cross_val_score(model, Xt, yt, cv=TimeSeriesSplit(5), scoring="r2")
print("shuffled k-fold R²:   ", round(shuffled.mean(), 3))
print("time-ordered split R²:", round(forward.mean(), 3))
from sklearn.model_selection import learning_curve
from sklearn.datasets import load_breast_cancer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

Xb, yb = load_breast_cancer(return_X_y=True)
sizes, tr, va = learning_curve(make_pipeline(StandardScaler(), LogisticRegression(max_iter=1000)), Xb, yb,
                               train_sizes=[0.05, 0.1, 0.25, 0.5, 1.0], cv=5, shuffle=True, random_state=0)
for s, a, b in zip(sizes, tr.mean(axis=1), va.mean(axis=1)):
    print(f"{s:4d} training examples: train accuracy {a:.3f}   validation accuracy {b:.3f}")
from sklearn.metrics import roc_auc_score
from sklearn.model_selection import cross_val_predict, StratifiedKFold
from sklearn.ensemble import RandomForestClassifier

# Adversarial validation: can a model tell training rows from "production" rows?
rng = np.random.default_rng(1)
train_rows = rng.normal(0, 1, size=(500, 3))
prod_same = rng.normal(0, 1, size=(500, 3))
prod_shift = rng.normal(0, 1, size=(500, 3)); prod_shift[:, 0] += 0.8   # one feature has drifted

cv = StratifiedKFold(5, shuffle=True, random_state=0)
for name, prod in [("no shift", prod_same), ("feature 0 drifted", prod_shift)]:
    Xa = np.vstack([train_rows, prod]); ya = np.r_[np.zeros(500), np.ones(500)]
    clf = RandomForestClassifier(n_estimators=200, min_samples_leaf=10, random_state=0)
    p = cross_val_predict(clf, Xa, ya, cv=cv, method="predict_proba")[:, 1]
    imp = clf.fit(Xa, ya).feature_importances_
    print(f"{name:18}: AUC {roc_auc_score(ya, p):.3f}   feature importances {imp.round(2)}")

##############################################################################
# Running example: Chennai Homes
#
# The same 12-house dataset used in every lesson (data/houses.csv in the course folder).
##############################################################################
import pandas as pd
import numpy as np
df = pd.read_csv(DATA / "houses.csv")
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.linear_model import LinearRegression
X, y = df[["size_m2"]], df["price_lakh"]
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, random_state=0)
print(len(X_train), "train /", len(X_test), "test houses")
scores = cross_val_score(LinearRegression(), X, y, cv=4, scoring="neg_mean_absolute_error")
print("MAE per fold:", (-scores).round(1), " mean:", round(-scores.mean(), 1))
