"""Lesson 5: Data, Features & Generalization — all the code from the lesson, as one script.

Part of the ML Academy course. Run it with:  python lesson-05.py
(works from any folder; the data is read from ../data/)
"""
from pathlib import Path
DATA = Path(__file__).resolve().parent.parent / "data"   # the course's data folder

##############################################################################
# 9. In Python
##############################################################################
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import PolynomialFeatures
from sklearn.linear_model import LinearRegression
from sklearn.pipeline import make_pipeline
from sklearn.metrics import mean_squared_error

rng = np.random.default_rng(0)
x = rng.uniform(-3, 3, 30)
y = np.sin(x) + rng.normal(0, 0.3, 30)          # hidden curve + noise
X = x.reshape(-1, 1)                             # sklearn wants a 2D matrix

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.5, random_state=1)

for degree in [1, 3, 9, 12]:
    model = make_pipeline(PolynomialFeatures(degree), LinearRegression())
    model.fit(X_train, y_train)
    train_mse = mean_squared_error(y_train, model.predict(X_train))
    test_mse = mean_squared_error(y_test, model.predict(X_test))
    print(f"degree {degree:2d}: train MSE {train_mse:.3f}   test MSE {test_mse:.3f}")
from sklearn.model_selection import cross_val_score

model = make_pipeline(PolynomialFeatures(3), LinearRegression())
scores = cross_val_score(model, X_train, y_train, cv=5, scoring="neg_mean_squared_error")
print(-scores.mean(), scores.std())     # mean MSE across the 5 folds, and its spread

##############################################################################
# Running example: Chennai Homes
#
# The same 12-house dataset used in every lesson (data/houses.csv in the course folder).
##############################################################################
import pandas as pd
import numpy as np
df = pd.read_csv(DATA / "houses.csv")
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.linear_model import LinearRegression
X, y = df[["size_m2"]], df["price_lakh"]
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, random_state=0)
print(len(X_train), "train /", len(X_test), "test houses")
scores = cross_val_score(LinearRegression(), X, y, cv=4, scoring="neg_mean_absolute_error")
print("MAE per fold:", (-scores).round(1), " mean:", round(-scores.mean(), 1))
