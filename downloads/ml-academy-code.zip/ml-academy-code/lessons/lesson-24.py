"""Lesson 24: Interpretability & Explainable ML — all the code from the lesson, as one script.

Part of the ML Academy course. Run it with:  python lesson-24.py
(works from any folder; the data is read from ../data/)
"""
from pathlib import Path
DATA = Path(__file__).resolve().parent.parent / "data"   # the course's data folder

##############################################################################
# 2. Reading linear models properly
##############################################################################
import numpy as np
import pandas as pd
from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import train_test_split
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression

data = load_breast_cancer()
X, y, names = data.data, data.target, data.feature_names      # target 1 = benign
X_tr, X_te, y_tr, y_te = train_test_split(X, y, test_size=0.3, random_state=0, stratify=y)
lin = make_pipeline(StandardScaler(), LogisticRegression(C=0.1, max_iter=5000)).fit(X_tr, y_tr)
coef = pd.Series(lin[-1].coef_[0], index=names)
print("largest standardised weights (positive pushes towards benign):")
print(coef.reindex(coef.abs().sort_values(ascending=False).index).head(5).round(3))

##############################################################################
# 3. Permutation importance
##############################################################################
from sklearn.ensemble import RandomForestClassifier
from sklearn.inspection import permutation_importance

rf = RandomForestClassifier(n_estimators=300, random_state=0).fit(X_tr, y_tr)
print("test accuracy:", round(rf.score(X_te, y_te), 3))
perm = permutation_importance(rf, X_te, y_te, n_repeats=30, random_state=0)
imp = pd.Series(perm.importances_mean, index=names).sort_values(ascending=False)
print("permutation importance on test data (drop in accuracy):")
print(imp.head(5).round(4))

##############################################################################
# 4. Partial dependence and ICE plots
##############################################################################
from sklearn.datasets import load_diabetes
from sklearn.ensemble import GradientBoostingRegressor
from sklearn.inspection import partial_dependence

d = load_diabetes()
Xd, yd = d.data, d.target
gbr = GradientBoostingRegressor(random_state=0).fit(Xd, yd)
bmi = list(d.feature_names).index("bmi")
pd_res = partial_dependence(gbr, Xd, [bmi], grid_resolution=6, kind="both")
print("bmi (scaled):        ", np.round(pd_res["grid_values"][0], 3))
print("average prediction:  ", np.round(pd_res["average"][0], 1))
ice = pd_res["individual"][0]
print("ICE spread at each bmi value (std across patients):", np.round(ice.std(axis=0), 1))

##############################################################################
# 5. SHAP values: fair credit for each feature
##############################################################################
from itertools import combinations
from math import factorial

# Exact Shapley values for a model on 4 features, for one patient
feats = ["bmi", "bp", "s5", "age"]
idx = [list(d.feature_names).index(f) for f in feats]
X4 = Xd[:, idx]
model4 = GradientBoostingRegressor(random_state=0).fit(X4, yd)
background = X4[:100]                    # "absent" features are filled in from these patients
x = X4[200]

def value(subset):
    """Average prediction when the features in `subset` take x's values and the others vary as in the background."""
    Z = background.copy()
    Z[:, list(subset)] = x[list(subset)]
    return model4.predict(Z).mean()

p = len(feats); shap = np.zeros(p)
for j in range(p):
    others = [k for k in range(p) if k != j]
    for size in range(p):
        for S in combinations(others, size):
            weight = factorial(size) * factorial(p - size - 1) / factorial(p)
            shap[j] += weight * (value(S + (j,)) - value(S))

base, pred = value(()), model4.predict(x[None, :])[0]
for f, v in zip(feats, shap):
    print(f"{f:4}: {v:+7.2f}")
print(f"baseline {base:.2f}, plus the contributions ({shap.sum():.2f}), gives {base + shap.sum():.2f}")
print(f"the model's actual prediction: {pred:.2f}")

##############################################################################
# 7. Local surrogates (LIME)
##############################################################################
from sklearn.linear_model import Ridge

# A LIME-style local explanation: fit a weighted linear model to the black box near one patient
rng = np.random.default_rng(0)
scale = X4.std(axis=0)
Z = x + rng.normal(0, 0.5, size=(2000, 4)) * scale          # perturbed copies of the patient
w = np.exp(-np.sum(((Z - x) / scale) ** 2, axis=1) / 2)        # nearer copies count more
local = Ridge(alpha=1e-3).fit((Z - x) / scale, model4.predict(Z), sample_weight=w)
print("local slopes (prediction change per +1 standard deviation):")
for f, c in zip(feats, local.coef_):
    print(f"{f:4}: {c:+7.2f}")

##############################################################################
# 9. In Python: an explanation workflow
##############################################################################
import numpy as np
from sklearn.datasets import load_diabetes
from sklearn.model_selection import train_test_split
from sklearn.ensemble import GradientBoostingRegressor
from sklearn.inspection import permutation_importance, partial_dependence

d = load_diabetes()
X_tr, X_te, y_tr, y_te = train_test_split(d.data, d.target, test_size=0.3, random_state=0)
model = GradientBoostingRegressor(random_state=0).fit(X_tr, y_tr)

# 1. Global: which features does the model rely on? (on test data)
perm = permutation_importance(model, X_te, y_te, n_repeats=20, random_state=0, scoring="r2")
top = np.argsort(perm.importances_mean)[::-1][:3]
print("top features:", [d.feature_names[i] for i in top], np.round(perm.importances_mean[top], 3))

# 2. Shape: how does the prediction change with the most important feature?
pdr = partial_dependence(model, X_tr, [top[0]], grid_resolution=5, method="brute")
print("partial dependence:", np.round(pdr["average"][0], 1))

##############################################################################
# 12. Going deeper: when features are correlated
##############################################################################
import numpy as np
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from sklearn.inspection import permutation_importance

# Two copies of the same signal: how do importance methods share the credit?
rng = np.random.default_rng(0)
n = 2000
a = rng.normal(size=n); b = a + rng.normal(0, 0.05, n)        # b is almost a copy of a
c = rng.normal(size=n)
X = np.column_stack([a, b, c]); y = 3 * a + 1 * c + rng.normal(0, 0.5, n)
X_tr, X_te, y_tr, y_te = train_test_split(X, y, random_state=0)
rf = RandomForestRegressor(n_estimators=200, random_state=0).fit(X_tr, y_tr)
perm = permutation_importance(rf, X_te, y_te, n_repeats=10, random_state=0, scoring="r2").importances_mean
print("permutation importance (a, b, c):", perm.round(3))

# Drop-column importance: retrain without each feature and measure the loss
full = rf.score(X_te, y_te)
drop = [full - RandomForestRegressor(n_estimators=200, random_state=0).fit(np.delete(X_tr, j, 1), y_tr).score(np.delete(X_te, j, 1), y_te) for j in range(3)]
print("drop-column importance (a, b, c):", np.round(drop, 3))
# For a linear model the exact SHAP value of feature j is w_j * (x_j - mean_j); averaging |SHAP| gives a global ranking
lin = LinearRegression().fit(X_tr, y_tr)
shap_vals = lin.coef_ * (X_te - X_tr.mean(axis=0))
print("weights (a, b, c):            ", lin.coef_.round(2))
print("mean |SHAP| per feature:      ", np.abs(shap_vals).mean(axis=0).round(3))
print("check, first row: baseline + contributions", round(lin.predict(X_tr).mean() + shap_vals[0].sum(), 4), "vs prediction", round(lin.predict(X_te[:1])[0], 4))

##############################################################################
# Running example: Chennai Homes
#
# The same 12-house dataset used in every lesson (data/houses.csv in the course folder).
##############################################################################
import pandas as pd
import numpy as np
df = pd.read_csv(DATA / "houses.csv")
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import StandardScaler
cols = ["size_m2", "dist_km", "age_yrs"]
Xs = StandardScaler().fit_transform(df[cols])
lr = LinearRegression().fit(Xs, df["price_lakh"])
base = lr.intercept_                                  # average price (features are centred)
contrib = Xs * lr.coef_                               # for a linear model, SHAP = weight × centred value
h = 4                                                 # house id 5
print("baseline", round(base, 1), "| contributions:", {c: float(v) for c, v in zip(cols, contrib[h].round(1))})
print("prediction", round(base + contrib[h].sum(), 1), "| actual", df.price_lakh[h])
