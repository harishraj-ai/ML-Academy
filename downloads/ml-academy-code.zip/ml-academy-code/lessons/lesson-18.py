"""Lesson 18: Neural Networks from Scratch — all the code from the lesson, as one script.

Part of the ML Academy course. Run it with:  python lesson-18.py
(works from any folder; the data is read from ../data/)
"""
from pathlib import Path
DATA = Path(__file__).resolve().parent.parent / "data"   # the course's data folder

##############################################################################
# 11. In Python: a network from scratch
##############################################################################
import numpy as np

X = np.array([[0, 0], [0, 1], [1, 0], [1, 1]], dtype=float)
Y = np.array([[0], [1], [1], [0]], dtype=float)

def sigmoid(z):
    return 1 / (1 + np.exp(-z))

rng = np.random.default_rng(1)
W1 = rng.normal(0, 1, (2, 4)); b1 = np.zeros(4)     # input -> 4 hidden neurons
W2 = rng.normal(0, 1, (4, 1)); b2 = np.zeros(1)     # hidden -> output
lr = 0.5

for step in range(5001):
    # forward pass
    H = np.tanh(X @ W1 + b1)
    P = sigmoid(H @ W2 + b2)
    loss = -np.mean(Y * np.log(P) + (1 - Y) * np.log(1 - P))
    # backward pass (backpropagation)
    dZ2 = (P - Y) / len(X)
    dW2 = H.T @ dZ2;  db2 = dZ2.sum(axis=0)
    dZ1 = (dZ2 @ W2.T) * (1 - H ** 2)          # tanh'(z) = 1 - tanh(z)^2
    dW1 = X.T @ dZ1;  db1 = dZ1.sum(axis=0)
    # gradient descent update
    W1 -= lr * dW1;  b1 -= lr * db1
    W2 -= lr * dW2;  b2 -= lr * db2
    if step in (0, 1000, 5000):
        print(step, round(loss, 4))

print(P.round(3).ravel())
from sklearn.datasets import load_digits
from sklearn.model_selection import train_test_split
from sklearn.neural_network import MLPClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline

X, y = load_digits(return_X_y=True)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, stratify=y, random_state=0)

mlp = make_pipeline(StandardScaler(),
                    MLPClassifier(hidden_layer_sizes=(64,), max_iter=500, random_state=0))
mlp.fit(X_train, y_train)
print(round(mlp.score(X_train, y_train), 3), round(mlp.score(X_test, y_test), 3))

##############################################################################
# Running example: Chennai Homes
#
# The same 12-house dataset used in every lesson (data/houses.csv in the course folder).
##############################################################################
import pandas as pd
import numpy as np
df = pd.read_csv(DATA / "houses.csv")
from sklearn.neural_network import MLPClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
from sklearn.model_selection import cross_val_score, LeaveOneOut
cols = ["size_m2", "dist_km", "age_yrs"]
mlp = make_pipeline(StandardScaler(), MLPClassifier(hidden_layer_sizes=(4,), max_iter=5000, random_state=0))
print("training accuracy:", mlp.fit(df[cols], df["sold_fast"]).score(df[cols], df["sold_fast"]))
print("leave-one-out accuracy:", round(cross_val_score(mlp, df[cols], df["sold_fast"], cv=LeaveOneOut()).mean(), 2))
