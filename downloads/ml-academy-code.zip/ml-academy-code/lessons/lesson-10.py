"""Lesson 10: Overfitting, Regularization & Bias–Variance — all the code from the lesson, as one script.

Part of the ML Academy course. Run it with:  python lesson-10.py
(works from any folder; the data is read from ../data/)
"""
from pathlib import Path
DATA = Path(__file__).resolve().parent.parent / "data"   # the course's data folder

##############################################################################
# 11. In Python
##############################################################################
import numpy as np
from sklearn.datasets import load_diabetes
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, PolynomialFeatures
from sklearn.linear_model import LinearRegression, Ridge, Lasso, RidgeCV
from sklearn.pipeline import make_pipeline

X, y = load_diabetes(return_X_y=True)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

def build(reg):
    return make_pipeline(PolynomialFeatures(2, include_bias=False), StandardScaler(), reg)

models = [("no regularization", LinearRegression())] + \
         [(f"Ridge alpha={a}", Ridge(alpha=a)) for a in [1, 10, 100]]
for name, reg in models:
    m = build(reg).fit(X_train, y_train)
    print(f"{name:20s} train R2 {m.score(X_train, y_train):.3f}  test R2 {m.score(X_test, y_test):.3f}")

for a in [0.1, 1, 5]:
    m = build(Lasso(alpha=a, max_iter=50000)).fit(X_train, y_train)
    coef = m[-1].coef_
    print(f"Lasso alpha={a}: test R2 {m.score(X_test, y_test):.3f}, non-zero weights {np.sum(coef != 0)} of {coef.size}")

m = build(RidgeCV(alphas=np.logspace(-2, 3, 30))).fit(X_train, y_train)
print("best alpha", round(m[-1].alpha_, 2), "test R2", round(m.score(X_test, y_test), 3))

##############################################################################
# 14. Going deeper: regularization in practice
##############################################################################
import numpy as np
from sklearn.preprocessing import PolynomialFeatures
from sklearn.linear_model import Ridge
from sklearn.pipeline import make_pipeline

# Measure bias² and variance directly: refit on 300 fresh training sets
rng = np.random.default_rng(0)
f = lambda x: np.sin(2 * np.pi * x)                   # the true curve
x_test = np.linspace(0, 1, 50)
for lam in [1e-6, 1e-3, 1e-1, 10]:
    preds = []
    for _ in range(300):
        x = rng.uniform(0, 1, 20); y = f(x) + rng.normal(0, 0.3, 20)
        m = make_pipeline(PolynomialFeatures(9), Ridge(alpha=lam)).fit(x[:, None], y)
        preds.append(m.predict(x_test[:, None]))
    preds = np.array(preds)
    bias2 = np.mean((preds.mean(axis=0) - f(x_test)) ** 2)
    var = np.mean(preds.var(axis=0))
    print(f"lambda {lam:7.0e}: bias² {bias2:.3f}   variance {var:.3f}   expected error {bias2 + var + 0.09:.3f}")
# Lasso's key step: soft-thresholding, used by coordinate descent
soft = lambda z, t: np.sign(z) * np.maximum(np.abs(z) - t, 0)
for z in [3.0, 0.8, -0.3, -2.5]:
    print(f"least-squares value {z:5.1f} -> lasso value {soft(z, 1.0) + 0.0:5.1f}    ridge value {z / (1 + 1.0):5.2f}")
from sklearn.linear_model import LassoCV, ElasticNetCV
from sklearn.datasets import load_diabetes
from sklearn.preprocessing import StandardScaler

X, y = load_diabetes(return_X_y=True)
X = StandardScaler().fit_transform(X)
lasso = LassoCV(cv=5, random_state=0).fit(X, y)
enet = ElasticNetCV(l1_ratio=[0.1, 0.5, 0.9], cv=5, random_state=0).fit(X, y)
print("lasso: best alpha", round(lasso.alpha_, 3), " non-zero weights", np.sum(lasso.coef_ != 0), "of 10")
print("elastic net: best alpha", round(enet.alpha_, 3), " l1_ratio", enet.l1_ratio_, " non-zero", np.sum(enet.coef_ != 0))
# Lasso with two almost identical features, on bootstrap samples: which one does it keep?
rng = np.random.default_rng(1)
from sklearn.linear_model import Lasso
n = 200
z = rng.normal(size=n)                                    # one underlying quantity…
a = z + rng.normal(0, 0.05, n); b = z + rng.normal(0, 0.05, n)   # …measured twice
yy = 3 * z + rng.normal(0, 1, n)
picks = {"only a": 0, "only b": 0, "both": 0}
for _ in range(200):
    i = rng.integers(0, n, n)
    w = Lasso(alpha=1.0).fit(np.column_stack([a, b])[i], yy[i]).coef_
    key = "both" if (w != 0).all() else ("only a" if w[0] != 0 else "only b")
    picks[key] += 1
print("lasso, 200 bootstrap samples:", picks)
from sklearn.linear_model import ElasticNet
w = ElasticNet(alpha=1.0, l1_ratio=0.5).fit(np.column_stack([a, b]), yy).coef_
print("elastic net weights on the full data:", w.round(2))

##############################################################################
# Running example: Chennai Homes
#
# The same 12-house dataset used in every lesson (data/houses.csv in the course folder).
##############################################################################
import pandas as pd
import numpy as np
df = pd.read_csv(DATA / "houses.csv")
from sklearn.linear_model import LinearRegression, Ridge
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
cols = ["size_m2", "bedrooms", "dist_km", "age_yrs"]
for name, reg in [("OLS", LinearRegression()), ("Ridge a=1", Ridge(alpha=1)), ("Ridge a=10", Ridge(alpha=10))]:
    m = make_pipeline(StandardScaler(), reg).fit(df[cols], df["price_lakh"])
    print(f"{name:11s}", m[-1].coef_.round(2))
