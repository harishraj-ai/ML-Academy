"""Lesson 10: Overfitting, Regularization & Bias–Variance — all the code from the lesson, as one script.

Part of the ML Academy course. Run it with:  python lesson-10.py
(works from any folder; the data is read from ../data/)
"""
from pathlib import Path
DATA = Path(__file__).resolve().parent.parent / "data"   # the course's data folder

##############################################################################
# 11. In Python
##############################################################################
import numpy as np
from sklearn.datasets import load_diabetes
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, PolynomialFeatures
from sklearn.linear_model import LinearRegression, Ridge, Lasso, RidgeCV
from sklearn.pipeline import make_pipeline

X, y = load_diabetes(return_X_y=True)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

def build(reg):
    return make_pipeline(PolynomialFeatures(2, include_bias=False), StandardScaler(), reg)

models = [("no regularization", LinearRegression())] + \
         [(f"Ridge alpha={a}", Ridge(alpha=a)) for a in [1, 10, 100]]
for name, reg in models:
    m = build(reg).fit(X_train, y_train)
    print(f"{name:20s} train R2 {m.score(X_train, y_train):.3f}  test R2 {m.score(X_test, y_test):.3f}")

for a in [0.1, 1, 5]:
    m = build(Lasso(alpha=a, max_iter=50000)).fit(X_train, y_train)
    coef = m[-1].coef_
    print(f"Lasso alpha={a}: test R2 {m.score(X_test, y_test):.3f}, non-zero weights {np.sum(coef != 0)} of {coef.size}")

m = build(RidgeCV(alphas=np.logspace(-2, 3, 30))).fit(X_train, y_train)
print("best alpha", round(m[-1].alpha_, 2), "test R2", round(m.score(X_test, y_test), 3))

##############################################################################
# Running example: Chennai Homes
#
# The same 12-house dataset used in every lesson (data/houses.csv in the course folder).
##############################################################################
import pandas as pd
import numpy as np
df = pd.read_csv(DATA / "houses.csv")
from sklearn.linear_model import LinearRegression, Ridge
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
cols = ["size_m2", "bedrooms", "dist_km", "age_yrs"]
for name, reg in [("OLS", LinearRegression()), ("Ridge a=1", Ridge(alpha=1)), ("Ridge a=10", Ridge(alpha=10))]:
    m = make_pipeline(StandardScaler(), reg).fit(df[cols], df["price_lakh"])
    print(f"{name:11s}", m[-1].coef_.round(2))
