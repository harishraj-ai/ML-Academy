"""Lesson 31: Reinforcement Learning Basics — all the code from the lesson, as one script.

Part of the ML Academy course. Run it with:  python lesson-31.py
(works from any folder; the data is read from ../data/)
"""
from pathlib import Path
DATA = Path(__file__).resolve().parent.parent / "data"   # the course's data folder

##############################################################################
# 2. Markov decision processes
##############################################################################
import numpy as np
ROWS, COLS = 4, 5
GOAL, PIT, WALL, START = (0, 4), (1, 4), (1, 1), (3, 0)
ACTIONS = {"↑": (-1, 0), "↓": (1, 0), "←": (0, -1), "→": (0, 1)}
STEP_COST, SLIP = -0.04, 0.1
states = [(i, j) for i in range(ROWS) for j in range(COLS) if (i, j) != WALL]
def move(s, a):
    i, j = s[0] + ACTIONS[a][0], s[1] + ACTIONS[a][1]
    return s if not (0 <= i < ROWS and 0 <= j < COLS) or (i, j) == WALL else (i, j)
def outcomes(s, a):                     # (probability, next state) — slips go sideways
    side = ["←", "→"] if a in "↑↓" else ["↑", "↓"]
    return [(1 - SLIP, move(s, a)), (SLIP / 2, move(s, side[0])), (SLIP / 2, move(s, side[1]))]
def reward(s):
    return 1.0 if s == GOAL else -1.0 if s == PIT else STEP_COST
terminal = {GOAL, PIT}
for i in range(ROWS):
    print(" ".join("G" if (i, j) == GOAL else "X" if (i, j) == PIT else "#" if (i, j) == WALL else "S" if (i, j) == START else "." for j in range(COLS)))

##############################################################################
# 3. Values and the Bellman equation
##############################################################################
def value_iteration(gamma=0.9, tol=1e-6):
    V = {s: 0.0 for s in states}
    for sweep in range(1, 1000):
        delta = 0
        for s in states:
            if s in terminal: continue
            best = max(sum(p * (reward(n) + (0 if n in terminal else gamma * V[n])) for p, n in outcomes(s, a)) for a in ACTIONS)
            delta, V[s] = max(delta, abs(best - V[s])), best
        if delta < tol:
            return V, sweep
V, sweeps = value_iteration()
print("converged after", sweeps, "sweeps")
for i in range(ROWS):
    print(" ".join(f"{V[(i, j)]:6.3f}" if (i, j) in V and (i, j) not in terminal else "   +1 " if (i, j) == GOAL else "   -1 " if (i, j) == PIT else "   ## " for j in range(COLS)))

##############################################################################
# 4. From values to a policy
##############################################################################
def greedy(V, gamma=0.9):
    return {s: max(ACTIONS, key=lambda a: sum(p * (reward(n) + (0 if n in terminal else gamma * V[n])) for p, n in outcomes(s, a)))
            for s in states if s not in terminal}
policy = greedy(V)
for i in range(ROWS):
    print(" ".join(policy.get((i, j), "G" if (i, j) == GOAL else "X" if (i, j) == PIT else "#") for j in range(COLS)))

##############################################################################
# 6. Learning without a model: Q-learning
##############################################################################
rng = np.random.default_rng(0)
def step(s, a):
    r, acc = rng.random(), 0
    for p, n in outcomes(s, a):
        acc += p
        if r < acc: return n, reward(n)
    return n, reward(n)
def q_learning(episodes=3000, alpha=0.1, gamma=0.9, eps=0.1):
    Q = {s: {a: 0.0 for a in ACTIONS} for s in states}
    for _ in range(episodes):
        s = START
        for t in range(100):
            a = rng.choice(list(ACTIONS)) if rng.random() < eps else max(Q[s], key=Q[s].get)
            n, r = step(s, a)
            target = r if n in terminal else r + gamma * max(Q[n].values())
            Q[s][a] += alpha * (target - Q[s][a])       # move the estimate towards the target
            s = n
            if s in terminal: break
    return Q
Q = q_learning()
learned = {s: max(Q[s], key=Q[s].get) for s in policy}
agree = np.mean([learned[s] == policy[s] for s in policy])
print("Q-learning's greedy policy matches value iteration in", f"{agree:.0%}", "of states")
print("estimated value of the start: Q-learning", round(max(Q[START].values()), 3), " value iteration", round(V[START], 3))

##############################################################################
# 7. Rewards shape behaviour
##############################################################################
for cost in [-0.01, -0.4, -2.0]:
    STEP_COST = cost                                        # reward() reads this global
    pol = greedy(value_iteration()[0])
    rows = [" ".join(pol.get((i, j), "G" if (i, j) == GOAL else "X" if (i, j) == PIT else "#") for j in range(COLS)) for i in range(ROWS)]
    print(f"step cost {cost}:   " + "   |   ".join(rows))
STEP_COST = -0.04

##############################################################################
# 9. In Python: Q-learning on a corridor
##############################################################################
import numpy as np

rng = np.random.default_rng(1)
N, START, gamma, alpha, eps = 6, 2, 0.9, 0.2, 0.2
Q = np.zeros((N, 2))                      # actions: 0 left, 1 right
for episode in range(500):
    s = START
    while 0 < s < N - 1:
        a = rng.integers(2) if rng.random() < eps else int(Q[s].argmax())
        s2 = s + (1 if a == 1 else -1)
        r = 1.0 if s2 == N - 1 else -1.0 if s2 == 0 else 0.0
        target = r if s2 in (0, N - 1) else r + gamma * Q[s2].max()
        Q[s, a] += alpha * (target - Q[s, a])
        s = s2
print("Q values for 'right' in squares 1 to 4:", np.round(Q[1:N - 1, 1], 3).tolist())
print("best action in squares 1 to 4:", ["right" if q[1] > q[0] else "left" for q in Q[1:N - 1]])

##############################################################################
# 12. Going deeper: SARSA versus Q-learning on a cliff
##############################################################################
import numpy as np
# Cliff walking: a 4×8 grid; the bottom row between start and goal is a cliff (−100, back to start).
R, C = 4, 8
start, goal = (3, 0), (3, 7)
moves = [(-1, 0), (1, 0), (0, -1), (0, 1)]
def env(s, a):
    i, j = min(max(s[0] + moves[a][0], 0), R - 1), min(max(s[1] + moves[a][1], 0), C - 1)
    if i == 3 and 0 < j < 7: return start, -100
    return (i, j), -1
rng = np.random.default_rng(0)
def train(method, episodes=500, alpha=0.5, eps=0.1):
    Q = np.zeros((R, C, 4))
    pick = lambda s: rng.integers(4) if rng.random() < eps else int(Q[s].argmax())
    for _ in range(episodes):
        s = start; a = pick(s)
        for t in range(200):
            s2, r = env(s, a); a2 = pick(s2)
            nxt = 0 if s2 == goal else (Q[s2].max() if method == "Q" else Q[s2][a2])
            Q[s][a] += alpha * (r + nxt - Q[s][a]); s, a = s2, a2
            if s == goal: break
    return Q
def route(Q):
    s, path = start, [start]
    for _ in range(40):
        s, _ = env(s, int(Q[s].argmax())); path.append(s)
        if s == goal: break
    return path
for method in ["Q", "SARSA"]:
    p = route(train(method))
    edge = sum(1 for c in p if c[0] == 2)                  # steps right next to the cliff
    print(f"{method:5s}: greedy route length {len(p) - 1}, steps along the cliff edge {edge}")
def run_returns(method, episodes=500, eps=0.1):
    Q, total = np.zeros((R, C, 4)), []
    for _ in range(episodes):
        s, G = start, 0
        a = rng.integers(4) if rng.random() < eps else int(Q[s].argmax())
        for t in range(200):
            s2, r = env(s, a); G += r
            a2 = rng.integers(4) if rng.random() < eps else int(Q[s2].argmax())
            nxt = 0 if s2 == goal else (Q[s2].max() if method == "Q" else Q[s2][a2])
            Q[s][a] += 0.5 * (r + nxt - Q[s][a]); s, a = s2, a2
            if s == goal: break
        total.append(G)
    return np.mean(total[-200:])
q_ret = np.mean([run_returns("Q") for _ in range(5)]); s_ret = np.mean([run_returns("SARSA") for _ in range(5)])
print("average return while still exploring: Q-learning", round(q_ret, 1), "  SARSA", round(s_ret, 1))

##############################################################################
# Running example: Chennai Homes
#
# The same 12-house dataset used in every lesson (data/houses.csv in the course folder).
##############################################################################
import pandas as pd
import numpy as np
df = pd.read_csv(DATA / "houses.csv")
# Each week a listed home sells with probability p; cutting the price 5% raises p but lowers the sale value.
p_hold = df.sold_fast.mean() / 4                     # about half the homes sell within ~4 weeks
p_cut, price, gamma, weekly_cost = min(1, 2 * p_hold), df.price_lakh.median(), 0.98, 0.5
V = {k: 0.0 for k in range(4)}                       # state: number of price cuts so far (max 3)
for _ in range(500):
    V = {k: max(p_hold * price * 0.95 ** k + (1 - p_hold) * gamma * V[k] - weekly_cost,
                p_cut * price * 0.95 ** (k + 1) + (1 - p_cut) * gamma * V[min(k + 1, 3)] - weekly_cost if k < 3 else -1e9)
         for k in V}
for k in V:
    hold = p_hold * price * 0.95 ** k + (1 - p_hold) * gamma * V[k] - weekly_cost
    print(f"after {k} cuts: value {V[k]:.1f} lakh, best action:", "hold" if abs(V[k] - hold) < 1e-9 else "cut")
