"""Lesson 22: SQL & Data Wrangling for ML — all the code from the lesson, as one script.

Part of the ML Academy course. Run it with:  python lesson-22.py
(works from any folder; the data is read from ../data/)
"""
from pathlib import Path
DATA = Path(__file__).resolve().parent.parent / "data"   # the course's data folder

##############################################################################
# 3. SELECT, WHERE and ORDER BY
##############################################################################
import sqlite3
import pandas as pd

con = sqlite3.connect(":memory:")                 # a database that lives in memory
pd.read_csv(DATA / "houses.csv").to_sql("houses", con, index=False)
viewings = pd.DataFrame({"house_id": [1, 1, 2, 4, 4, 4, 5, 8, 11, 11, 12],
                         "day":      [3, 9, 2, 1, 4, 8, 6, 5, 2, 7, 1]})
viewings.to_sql("viewings", con, index=False)

q = """SELECT id, area, size_m2, price_lakh
       FROM houses
       WHERE price_lakh > 80
       ORDER BY price_lakh DESC"""
print(pd.read_sql(q, con))

##############################################################################
# 4. GROUP BY: from rows to summaries
##############################################################################
q = """SELECT area, COUNT(*) AS homes, ROUND(AVG(price_lakh), 1) AS avg_price,
              ROUND(AVG(price_lakh * 1.0 / size_m2), 3) AS lakh_per_m2
       FROM houses
       GROUP BY area
       HAVING COUNT(*) >= 3
       ORDER BY avg_price DESC"""
print(pd.read_sql(q, con))

##############################################################################
# 5. Joins: combining tables
##############################################################################
inner = """SELECT h.id, COUNT(v.day) AS n_viewings
           FROM houses h JOIN viewings v ON v.house_id = h.id
           GROUP BY h.id"""
left = """SELECT h.id, COUNT(v.day) AS n_viewings
          FROM houses h LEFT JOIN viewings v ON v.house_id = h.id
          GROUP BY h.id"""
print("inner join rows:", len(pd.read_sql(inner, con)), "  left join rows:", len(pd.read_sql(left, con)))
print(pd.read_sql(left, con).T)

##############################################################################
# 7. Window functions: features from context
##############################################################################
q = """SELECT id, area, price_lakh,
              RANK() OVER (PARTITION BY area ORDER BY price_lakh DESC) AS rank_in_area,
              ROUND(price_lakh - AVG(price_lakh) OVER (PARTITION BY area), 1) AS vs_area_avg
       FROM houses
       ORDER BY area, rank_in_area"""
print(pd.read_sql(q, con))

##############################################################################
# 8. The same operations in pandas
##############################################################################
houses = pd.read_sql("SELECT * FROM houses", con)
n_view = viewings.groupby("house_id").size().rename("n_viewings")
merged = houses.merge(n_view, left_on="id", right_index=True, how="left").fillna({"n_viewings": 0})
summary = merged.groupby("area").agg(homes=("id", "size"), avg_price=("price_lakh", "mean"),
                                     avg_viewings=("n_viewings", "mean")).round(2)
print(summary)

##############################################################################
# 10. Point-in-time correctness: the rule that prevents leakage
##############################################################################
# Point-in-time features: count only viewings that happened BEFORE the prediction day
predict_day = 5
q = """SELECT h.id, COUNT(v.day) AS viewings_so_far
       FROM houses h LEFT JOIN viewings v
            ON v.house_id = h.id AND v.day < ?
       GROUP BY h.id"""
past = pd.read_sql(q, con, params=(predict_day,))
allv = pd.read_sql(left, con)
print("viewings counted, all time:   ", int(allv.n_viewings.sum()))
print("viewings counted, before day 5:", int(past.viewings_so_far.sum()))

##############################################################################
# 11. In Python: from database to training table
##############################################################################
import sqlite3
import pandas as pd

con = sqlite3.connect(":memory:")
pd.read_csv(DATA / "houses.csv").to_sql("houses", con, index=False)
pd.DataFrame({"house_id": [1, 1, 2, 4, 4, 4, 5, 8, 11, 11, 12],
              "day": [3, 9, 2, 1, 4, 8, 6, 5, 2, 7, 1]}).to_sql("viewings", con, index=False)

query = """
WITH v AS (                                  -- step 1: summarise events before the cut-off
    SELECT house_id, COUNT(*) AS n_viewings, MIN(day) AS first_view
    FROM viewings WHERE day < 5 GROUP BY house_id
)
SELECT h.*,                                  -- step 2: one row per house, every house kept
       COALESCE(v.n_viewings, 0) AS n_viewings,
       AVG(h.price_lakh) OVER (PARTITION BY h.area) AS area_avg_price
FROM houses h LEFT JOIN v ON v.house_id = h.id
"""
train = pd.read_sql(query, con)
print(train.shape)
print(train[["id", "area", "n_viewings", "area_avg_price", "sold_fast"]].head())

##############################################################################
# 14. Going deeper: indexes, NULL logic and rolling features
##############################################################################
import sqlite3
import numpy as np
import pandas as pd

# A bigger events table: 200,000 viewings of 5,000 houses
rng = np.random.default_rng(0)
con = sqlite3.connect(":memory:")
pd.DataFrame({"house_id": rng.integers(1, 5001, 200000), "day": rng.integers(1, 366, 200000)}).to_sql("viewings", con, index=False)
q = "SELECT COUNT(*) FROM viewings WHERE house_id = 42"
print("plan without an index:", con.execute("EXPLAIN QUERY PLAN " + q).fetchall()[0][-1])
con.execute("CREATE INDEX idx_house ON viewings(house_id)")
print("plan with an index:   ", con.execute("EXPLAIN QUERY PLAN " + q).fetchall()[0][-1])
print("viewings of house 42:", con.execute(q).fetchone()[0])
# NULL is "unknown": comparisons with it are neither true nor false
t = pd.DataFrame({"id": [1, 2, 3, 4], "discount": [10, None, 0, None]})
t.to_sql("t", con, index=False)
conds = {"discount > 5": "discount > 5", "NOT (discount > 5)": "NOT (discount > 5)",
         "discount equals NULL": "discount = NULL", "discount IS NULL": "discount IS NULL"}
for label, cond in conds.items():
    print(f"{label:21} -> rows {[r[0] for r in con.execute(f'SELECT id FROM t WHERE {cond}')]}")
print("COUNT(*), COUNT(discount), AVG(discount):", con.execute("SELECT COUNT(*), COUNT(discount), AVG(discount) FROM t").fetchone())
# Rolling, point-in-time features with a window frame: viewings in the 7 days up to and including each day
daily = pd.DataFrame({"house_id": [1] * 10, "day": range(1, 11), "views": [0, 2, 1, 0, 3, 1, 0, 0, 4, 1]})
daily.to_sql("daily", con, index=False)
q = """SELECT day, views,
              SUM(views) OVER (PARTITION BY house_id ORDER BY day ROWS BETWEEN 6 PRECEDING AND CURRENT ROW) AS views_7d,
              LAG(views) OVER (PARTITION BY house_id ORDER BY day) AS views_yesterday
       FROM daily"""
print(pd.read_sql(q, con).to_string(index=False))

##############################################################################
# Running example: Chennai Homes
#
# The same 12-house dataset used in every lesson (data/houses.csv in the course folder).
##############################################################################
import sqlite3
import pandas as pd
df = pd.read_csv(DATA / "houses.csv")
con = sqlite3.connect(":memory:")
df.to_sql("houses", con, index=False)
q = """SELECT area, COUNT(*) AS homes, SUM(sold_fast) AS sold_fast,
              ROUND(AVG(sold_fast), 2) AS fast_rate, ROUND(AVG(price_lakh), 1) AS avg_price
       FROM houses GROUP BY area ORDER BY fast_rate DESC"""
print(pd.read_sql(q, con))
