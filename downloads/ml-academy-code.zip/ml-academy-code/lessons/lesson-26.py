"""Lesson 26: Time Series Forecasting — all the code from the lesson, as one script.

Part of the ML Academy course. Run it with:  python lesson-26.py
(works from any folder; the data is read from ../data/)
"""
from pathlib import Path
DATA = Path(__file__).resolve().parent.parent / "data"   # the course's data folder

##############################################################################
# 2. Trend, seasonality and noise
##############################################################################
import numpy as np
import pandas as pd

# Three years of simulated daily sales for a shop: trend + weekly pattern + yearly season + noise
rng = np.random.default_rng(0)
days = pd.date_range("2023-01-01", periods=3 * 365, freq="D")
t = np.arange(len(days))
weekly = np.array([0.9, 0.95, 1.0, 1.0, 1.1, 1.35, 1.25])[days.dayofweek]       # Mon … Sun
yearly = 1 + 0.2 * np.sin(2 * np.pi * (days.dayofyear - 80) / 365)
sales = (200 + 0.15 * t) * weekly * yearly * rng.lognormal(0, 0.08, len(t))
s = pd.Series(sales.round(1), index=days, name="sales")
print(s.head(7).to_string())
print("average sales by weekday (Mon … Sun):", s.groupby(s.index.dayofweek).mean().round(0).tolist())
print("average sales by year:", s.groupby(s.index.year).mean().round(0).tolist())

##############################################################################
# 3. Baselines first
##############################################################################
# Forecast the last 8 weeks with simple baselines, one day ahead each day
test = s[-56:]
naive = s.shift(1)[-56:]                         # tomorrow = today
seasonal = s.shift(7)[-56:]                      # tomorrow = same weekday last week
moving = s.shift(1).rolling(28).mean()[-56:]     # tomorrow = average of the last 4 weeks
mae = lambda f: np.mean(np.abs(test - f))
for name, f in [("naive (yesterday)", naive), ("seasonal naive (last week)", seasonal), ("28-day average", moving)]:
    print(f"{name:27}: MAE {mae(f):6.1f}")

##############################################################################
# 5. Turning a series into features
##############################################################################
from sklearn.linear_model import Ridge
from sklearn.ensemble import HistGradientBoostingRegressor

# Features that only use the past: lags, rolling means and calendar fields
df = pd.DataFrame({"y": s})
for lag in [1, 7, 14, 28]:
    df[f"lag_{lag}"] = s.shift(lag)
df["roll_7"] = s.shift(1).rolling(7).mean()
df["roll_28"] = s.shift(1).rolling(28).mean()
df["dow"] = df.index.dayofweek
df["doy_sin"], df["doy_cos"] = np.sin(2 * np.pi * df.index.dayofyear / 365), np.cos(2 * np.pi * df.index.dayofyear / 365)
df = df.dropna()
Xf = pd.get_dummies(df.drop(columns="y"), columns=["dow"], dtype=float)
start = s.index[-56]                                                    # the last 56 days are the test period
train, test_idx = Xf.index < start, Xf.index >= start
yt = df.y[train].to_numpy()
scale = np.mean(np.abs(yt[7:] - yt[:-7]))                               # seasonal-naive MAE on training data, for MASE
for name, m in [("ridge on lag features", Ridge(1.0)), ("gradient boosting", HistGradientBoostingRegressor(random_state=0))]:
    pred = m.fit(Xf[train], df.y[train]).predict(Xf[test_idx])
    err = np.mean(np.abs(df.y[test_idx] - pred))
    print(f"{name:22}: MAE {err:6.1f}   MASE {err / scale:.2f}")

##############################################################################
# 6. Validating forecasts: backtesting
##############################################################################
from sklearn.model_selection import TimeSeriesSplit

# Backtesting: repeat "train on the past, test on the next 8 weeks" several times
maes = []
for tr, te in TimeSeriesSplit(n_splits=5, test_size=56).split(Xf):
    pred = Ridge(1.0).fit(Xf.iloc[tr], df.y.iloc[tr]).predict(Xf.iloc[te])
    maes.append(np.mean(np.abs(df.y.iloc[te] - pred)))
print("MAE in each backtest window:", np.round(maes, 1))
print("average:", round(np.mean(maes), 1))

##############################################################################
# 7. Forecasting several steps ahead
##############################################################################
# Forecasting 14 days ahead recursively: each prediction becomes the next day's lag
history = s[s.index < start].copy()
model = Ridge(1.0).fit(Xf[train], df.y[train])
cols = Xf.columns
for step in range(14):
    day = history.index[-1] + pd.Timedelta(days=1)
    row = {f"lag_{l}": history.iloc[-l] for l in [1, 7, 14, 28]}
    row.update(roll_7=history.iloc[-7:].mean(), roll_28=history.iloc[-28:].mean(),
               doy_sin=np.sin(2 * np.pi * day.dayofyear / 365), doy_cos=np.cos(2 * np.pi * day.dayofyear / 365))
    row.update({f"dow_{d}": float(day.dayofweek == d) for d in range(7)})
    history.loc[day] = model.predict(pd.DataFrame([row])[cols])[0]
err = np.abs(history[-14:] - s[history.index[-14:]])
print("absolute error, days 1–7 ahead: ", round(err[:7].mean(), 1))
print("absolute error, days 8–14 ahead:", round(err[7:].mean(), 1))

##############################################################################
# 9. In Python: a compact forecasting pipeline
##############################################################################
import numpy as np
import pandas as pd
from sklearn.linear_model import Ridge

rng = np.random.default_rng(1)
idx = pd.date_range("2024-01-01", periods=730, freq="D")
y = pd.Series((100 + 0.05 * np.arange(730)) * np.array([0.9, 1, 1, 1, 1.1, 1.3, 1.2])[idx.dayofweek]
              * rng.lognormal(0, 0.1, 730), index=idx)

def make_features(y):
    X = pd.DataFrame({f"lag_{l}": y.shift(l) for l in [1, 7, 14]}, index=y.index)
    X["roll_7"] = y.shift(1).rolling(7).mean()
    return X.join(pd.get_dummies(pd.Series(y.index.dayofweek, index=y.index), prefix="dow", dtype=float))

X = make_features(y).dropna(); target = y[X.index]
cut = X.index[-60]                                        # the last 60 days are the test period
model = Ridge(1.0).fit(X[X.index < cut], target[target.index < cut])
pred = model.predict(X[X.index >= cut])
actual, base = target[target.index >= cut], y.shift(7)[target.index[target.index >= cut]]
print("model MAE:", round(np.mean(np.abs(actual - pred)), 2), "  seasonal naive MAE:", round(np.mean(np.abs(actual - base)), 2))

##############################################################################
# 12. Going deeper: choosing lags and honest prediction intervals
##############################################################################
import numpy as np
import pandas as pd
rng = np.random.default_rng(3)
t = np.arange(730)
y = pd.Series((200 + 0.15 * t) * np.array([0.85, 0.9, 0.95, 1.0, 1.05, 1.25, 1.1])[t % 7] * rng.lognormal(0, 0.08, 730))
change = y.diff(1)                                   # remove the trend first
acf = {lag: round(float(change.autocorr(lag)), 2) for lag in [1, 2, 3, 6, 7, 14, 21]}
print("autocorrelation of daily changes by lag:", acf)
from sklearn.linear_model import Ridge
X = pd.DataFrame({f"lag_{l}": y.shift(l) for l in [7, 14, 21]}).dropna(); target = y[X.index]
cal, test = X.index[(X.index >= 550) & (X.index < 640)], X.index[X.index >= 640]
model = Ridge(1.0).fit(X[X.index < 550], target[target.index < 550])
resid = target[cal] - model.predict(X.loc[cal])
lo, hi = np.quantile(resid, [0.05, 0.95])            # 90% interval from held-out errors
pred = model.predict(X.loc[test])
inside = ((target[test] >= pred + lo) & (target[test] <= pred + hi)).mean()
print("interval offsets:", round(lo, 1), "to", round(hi, 1), "  coverage on the test period:", round(inside, 3))

##############################################################################
# Running example: Chennai Homes
#
# The same 12-house dataset used in every lesson (data/houses.csv in the course folder).
##############################################################################
import pandas as pd
import numpy as np
df = pd.read_csv(DATA / "houses.csv")
rng = np.random.default_rng(0)
months = pd.date_range("2023-01-01", periods=36, freq="MS")
level = df.price_lakh.mean() * (1 + 0.006 * np.arange(36)) * (1 + 0.03 * np.sin(2 * np.pi * months.month / 12))
index = pd.Series(level * rng.normal(1, 0.01, 36), index=months).round(1)   # a simulated monthly price index
test = index.index >= "2025-07-01"
naive, seasonal = index.shift(1)[test], index.shift(12)[test]
print("last 6 months:", index[test].tolist())
print("MAE, last month:", round((index[test] - naive).abs().mean(), 2), "  MAE, same month last year:", round((index[test] - seasonal).abs().mean(), 2))
