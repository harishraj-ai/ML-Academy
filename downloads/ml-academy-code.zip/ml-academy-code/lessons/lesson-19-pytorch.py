"""Lesson 19: the PyTorch example. Needs PyTorch:  pip install torch  (see pytorch.org)
Not run by the tests.
"""
import torch.nn as nn

model = nn.Sequential(
    nn.Conv2d(1, 16, kernel_size=3, padding=1),   # 28x28x1  -> 28x28x16
    nn.ReLU(),
    nn.MaxPool2d(2),                              # -> 14x14x16
    nn.Conv2d(16, 32, kernel_size=3, padding=1),  # -> 14x14x32
    nn.ReLU(),
    nn.MaxPool2d(2),                              # -> 7x7x32
    nn.Flatten(),                                 # -> 1568 numbers
    nn.Dropout(0.25),
    nn.Linear(32 * 7 * 7, 10),                    # one score per digit
)
