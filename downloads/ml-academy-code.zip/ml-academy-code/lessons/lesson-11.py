"""Lesson 11: k-Nearest Neighbours — all the code from the lesson, as one script.

Part of the ML Academy course. Run it with:  python lesson-11.py
(works from any folder; the data is read from ../data/)
"""
from pathlib import Path
DATA = Path(__file__).resolve().parent.parent / "data"   # the course's data folder

##############################################################################
# 10. In Python
##############################################################################
from sklearn.datasets import load_wine
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.neighbors import KNeighborsClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline

X, y = load_wine(return_X_y=True)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, stratify=y, random_state=0)

raw = KNeighborsClassifier(n_neighbors=5).fit(X_train, y_train)
print("without scaling:", round(raw.score(X_test, y_test), 3))

scaled = make_pipeline(StandardScaler(), KNeighborsClassifier(n_neighbors=5)).fit(X_train, y_train)
print("with scaling:   ", round(scaled.score(X_test, y_test), 3))

for k in [1, 5, 15, 51, 81, 101]:
    s = cross_val_score(make_pipeline(StandardScaler(), KNeighborsClassifier(n_neighbors=k)),
                        X_train, y_train, cv=5)
    print(f"k={k:3d}  CV accuracy {s.mean():.3f} ± {s.std():.3f}")

##############################################################################
# 13. Going deeper: distances, dimensions and fast neighbour search
##############################################################################
import numpy as np

# Distance concentration: in high dimensions the nearest and farthest points are almost equally far
rng = np.random.default_rng(0)
for d in [2, 10, 100, 1000]:
    pts = rng.uniform(size=(1000, d)); q = rng.uniform(size=d)
    dist = np.linalg.norm(pts - q, axis=1)
    print(f"{d:4d} dimensions: nearest {dist.min():6.2f}   farthest {dist.max():6.2f}   ratio {dist.max() / dist.min():5.2f}")
from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import cross_val_score
from sklearn.neighbors import KNeighborsClassifier
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

X, y = load_breast_cancer(return_X_y=True)
for metric in ["euclidean", "manhattan", "cosine"]:
    for weights in ["uniform", "distance"]:
        m = make_pipeline(StandardScaler(), KNeighborsClassifier(n_neighbors=15, metric=metric, weights=weights))
        print(f"{metric:9} {weights:8}: accuracy {cross_val_score(m, X, y, cv=10).mean():.3f}")
import time
from sklearn.neighbors import NearestNeighbors

data = rng.normal(size=(200000, 3)); queries = rng.normal(size=(2000, 3))
found, times = {}, {}
for algo in ["brute", "kd_tree"]:
    nn = NearestNeighbors(n_neighbors=5, algorithm=algo).fit(data)
    t = time.perf_counter(); found[algo] = nn.kneighbors(queries)[1]; times[algo] = time.perf_counter() - t
print("same neighbours found by both:", np.array_equal(np.sort(found["brute"]), np.sort(found["kd_tree"])))
print("k-d tree faster:", times["kd_tree"] < times["brute"])   # exact timings vary from computer to computer

##############################################################################
# Running example: Chennai Homes
#
# The same 12-house dataset used in every lesson (data/houses.csv in the course folder).
##############################################################################
import pandas as pd
import numpy as np
df = pd.read_csv(DATA / "houses.csv")
from sklearn.neighbors import KNeighborsRegressor
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
cols = ["size_m2", "dist_km", "age_yrs"]
knn = make_pipeline(StandardScaler(), KNeighborsRegressor(n_neighbors=3)).fit(df[cols], df["price_lakh"])
new = pd.DataFrame({"size_m2": [100], "dist_km": [6], "age_yrs": [5]})
dist, idx = knn[-1].kneighbors(knn[0].transform(new))
print("nearest houses:", (df["id"].iloc[idx[0]]).tolist(), "prices:", df["price_lakh"].iloc[idx[0]].tolist())
print("predicted price:", round(knn.predict(new)[0], 1), "lakh")
