"""Lesson 1: What Is Machine Learning? — all the code from the lesson, as one script.

Part of the ML Academy course. Run it with:  python lesson-01.py
(works from any folder; the data is read from ../data/)
"""
from pathlib import Path
DATA = Path(__file__).resolve().parent.parent / "data"   # the course's data folder

##############################################################################
# 9. Your first ML code
##############################################################################
from sklearn.linear_model import LinearRegression

# features: house size in 100 m² (each row is one house)
X = [[1], [2], [3], [4], [5]]
# labels: price in units of 100,000 USD
y = [2.1, 3.9, 6.2, 7.8, 10.1]

model = LinearRegression()   # 1. choose a model
model.fit(X, y)              # 2. train: find the best w and b

print(model.coef_, model.intercept_)   # the learned w and b
print(model.predict([[6]]))            # 3. predict a new 600 m² house

##############################################################################
# Running example: Chennai Homes
#
# The same 12-house dataset used in every lesson (data/houses.csv in the course folder).
##############################################################################
import pandas as pd
import numpy as np
df = pd.read_csv(DATA / "houses.csv")
print(df.shape)                       # rows = houses, columns = facts about each house
print(df[["area", "size_m2", "dist_km", "price_lakh", "sold_fast"]].head(3))
print("average price:", round(df["price_lakh"].mean(), 1), "lakh")
