"""Lesson 13: Decision Trees — all the code from the lesson, as one script.

Part of the ML Academy course. Run it with:  python lesson-13.py
(works from any folder; the data is read from ../data/)
"""
from pathlib import Path
DATA = Path(__file__).resolve().parent.parent / "data"   # the course's data folder

##############################################################################
# 11. In Python
##############################################################################
from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier

data = load_breast_cancer()
X_train, X_test, y_train, y_test = train_test_split(
    data.data, data.target, test_size=0.25, stratify=data.target, random_state=0)

for depth in [1, 2, 3, 5, None]:          # None = grow until leaves are pure
    tree = DecisionTreeClassifier(max_depth=depth, random_state=0).fit(X_train, y_train)
    print(f"max_depth={str(depth):4s} depth={tree.get_depth()} leaves={tree.get_n_leaves():2d} "
          f"train={tree.score(X_train, y_train):.3f} test={tree.score(X_test, y_test):.3f}")

tree = DecisionTreeClassifier(max_depth=3, random_state=0).fit(X_train, y_train)
top = sorted(zip(tree.feature_importances_, data.feature_names), reverse=True)[:3]
print([(str(name), round(float(imp), 3)) for imp, name in top])

##############################################################################
# 14. Going deeper: pruning, honest importances and instability
##############################################################################
import numpy as np
from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier

X, y = load_breast_cancer(return_X_y=True)
Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=0.3, random_state=0, stratify=y)
path = DecisionTreeClassifier(random_state=0).cost_complexity_pruning_path(Xtr, ytr)
print(" ccp_alpha   leaves   train acc   test acc")
for a in path.ccp_alphas[::3]:
    t = DecisionTreeClassifier(random_state=0, ccp_alpha=a).fit(Xtr, ytr)
    print(f"{a:9.4f}   {t.get_n_leaves():6d}   {t.score(Xtr, ytr):9.3f}   {t.score(Xte, yte):8.3f}")
from sklearn.model_selection import GridSearchCV
search = GridSearchCV(DecisionTreeClassifier(random_state=0), {"ccp_alpha": path.ccp_alphas}, cv=5).fit(Xtr, ytr)
best = search.best_estimator_
print("alpha chosen by CV:", round(search.best_params_["ccp_alpha"], 4), " leaves:", best.get_n_leaves(), " test accuracy:", round(best.score(Xte, yte), 3))
from sklearn.inspection import permutation_importance

# Add a column of pure noise with many distinct values (like an ID number)
rng = np.random.default_rng(0)
Xn_tr = np.column_stack([Xtr, rng.permutation(len(ytr))])
Xn_te = np.column_stack([Xte, rng.permutation(len(yte))])
tree = DecisionTreeClassifier(random_state=0).fit(Xn_tr, ytr)
imp = tree.feature_importances_
perm = permutation_importance(tree, Xn_te, yte, n_repeats=30, random_state=0).importances_mean
print("noise column: impurity importance", round(imp[-1], 3), " rank", int((imp > imp[-1]).sum()) + 1, "of 31")
print("noise column: permutation importance on test data", round(perm[-1], 3))
# Instability: which feature does the root split use on bootstrap samples?
names = load_breast_cancer().feature_names
roots = {}
for _ in range(100):
    i = rng.integers(0, len(ytr), len(ytr))
    r = names[DecisionTreeClassifier(random_state=0).fit(Xtr[i], ytr[i]).tree_.feature[0]]
    roots[str(r)] = roots.get(str(r), 0) + 1
print(sorted(roots.items(), key=lambda kv: -kv[1]))

##############################################################################
# Running example: Chennai Homes
#
# The same 12-house dataset used in every lesson (data/houses.csv in the course folder).
##############################################################################
import pandas as pd
import numpy as np
df = pd.read_csv(DATA / "houses.csv")
from sklearn.tree import DecisionTreeClassifier, export_text
cols = ["size_m2", "dist_km", "age_yrs"]
tree = DecisionTreeClassifier(max_depth=2, random_state=0).fit(df[cols], df["sold_fast"])
print(export_text(tree, feature_names=cols))
print("training accuracy:", tree.score(df[cols], df["sold_fast"]))
