"""Lesson 13: Decision Trees — all the code from the lesson, as one script.

Part of the ML Academy course. Run it with:  python lesson-13.py
(works from any folder; the data is read from ../data/)
"""
from pathlib import Path
DATA = Path(__file__).resolve().parent.parent / "data"   # the course's data folder

##############################################################################
# 11. In Python
##############################################################################
from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier

data = load_breast_cancer()
X_train, X_test, y_train, y_test = train_test_split(
    data.data, data.target, test_size=0.25, stratify=data.target, random_state=0)

for depth in [1, 2, 3, 5, None]:          # None = grow until leaves are pure
    tree = DecisionTreeClassifier(max_depth=depth, random_state=0).fit(X_train, y_train)
    print(f"max_depth={str(depth):4s} depth={tree.get_depth()} leaves={tree.get_n_leaves():2d} "
          f"train={tree.score(X_train, y_train):.3f} test={tree.score(X_test, y_test):.3f}")

tree = DecisionTreeClassifier(max_depth=3, random_state=0).fit(X_train, y_train)
top = sorted(zip(tree.feature_importances_, data.feature_names), reverse=True)[:3]
print([(str(name), round(float(imp), 3)) for imp, name in top])

##############################################################################
# Running example: Chennai Homes
#
# The same 12-house dataset used in every lesson (data/houses.csv in the course folder).
##############################################################################
import pandas as pd
import numpy as np
df = pd.read_csv(DATA / "houses.csv")
from sklearn.tree import DecisionTreeClassifier, export_text
cols = ["size_m2", "dist_km", "age_yrs"]
tree = DecisionTreeClassifier(max_depth=2, random_state=0).fit(df[cols], df["sold_fast"])
print(export_text(tree, feature_names=cols))
print("training accuracy:", tree.score(df[cols], df["sold_fast"]))
