"""Lesson 32: Semi-supervised & Active Learning — all the code from the lesson, as one script.

Part of the ML Academy course. Run it with:  python lesson-32.py
(works from any folder; the data is read from ../data/)
"""
from pathlib import Path
DATA = Path(__file__).resolve().parent.parent / "data"   # the course's data folder

##############################################################################
# 2. The baseline: 50 labels
##############################################################################
import numpy as np
from sklearn.datasets import load_digits
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
X, y = load_digits(return_X_y=True)
X = StandardScaler().fit_transform(X)
X_pool, X_test, y_pool, y_test = train_test_split(X, y, test_size=0.3, random_state=0, stratify=y)
rng = np.random.default_rng(0)
labelled = rng.choice(len(X_pool), 50, replace=False)            # only 50 of 1,257 images labelled
clf = LogisticRegression(max_iter=2000).fit(X_pool[labelled], y_pool[labelled])
full = LogisticRegression(max_iter=2000).fit(X_pool, y_pool)
print("labelled examples:", len(labelled), "of", len(X_pool))
print("accuracy with 50 labels:", round(clf.score(X_test, y_test), 3), "  with all labels:", round(full.score(X_test, y_test), 3))

##############################################################################
# 4. Self-training with pseudo-labels
##############################################################################
from sklearn.semi_supervised import SelfTrainingClassifier
y_partial = np.full(len(y_pool), -1); y_partial[labelled] = y_pool[labelled]   # -1 means "unlabelled"
for thr in [0.99, 0.9, 0.6]:
    st = SelfTrainingClassifier(LogisticRegression(max_iter=2000), threshold=thr).fit(X_pool, y_partial)
    added = (st.labeled_iter_ > 0).sum()
    wrong = (st.transduction_[st.labeled_iter_ > 0] != y_pool[st.labeled_iter_ > 0]).mean()
    print(f"threshold {thr}: pseudo-labels added {added}, of which wrong {wrong:.1%}, test accuracy {st.score(X_test, y_test):.3f}")

##############################################################################
# 5. Label spreading on a graph
##############################################################################
from sklearn.semi_supervised import LabelSpreading
ls = LabelSpreading(kernel="knn", n_neighbors=7, alpha=0.2).fit(X_pool, y_partial)
spread_acc = (ls.transduction_ == y_pool).mean()
print("label spreading: share of pool labels inferred correctly", round(spread_acc, 3))
clf_ls = LogisticRegression(max_iter=2000).fit(X_pool, ls.transduction_)
print("logistic regression trained on the spread labels: test accuracy", round(clf_ls.score(X_test, y_test), 3))

##############################################################################
# 6. Active learning: choose what to label
##############################################################################
def active_learning(strategy, rounds=10, batch=15, seed=0):
    r = np.random.default_rng(seed)
    lab = list(r.choice(len(X_pool), 20, replace=False))
    for _ in range(rounds):
        m = LogisticRegression(max_iter=2000).fit(X_pool[lab], y_pool[lab])
        rest = np.setdiff1d(np.arange(len(X_pool)), lab)
        if strategy == "uncertainty":
            P = np.sort(m.predict_proba(X_pool[rest]), axis=1)
            pick = rest[np.argsort(P[:, -1] - P[:, -2])[:batch]]    # smallest margin between the top two classes
        else:
            pick = r.choice(rest, batch, replace=False)
        lab += list(pick)
    return len(lab), LogisticRegression(max_iter=2000).fit(X_pool[lab], y_pool[lab]).score(X_test, y_test)
for strategy in ["random", "uncertainty"]:
    res = [active_learning(strategy, seed=s) for s in range(5)]
    print(f"{strategy:11s}: {res[0][0]} labels, mean test accuracy {np.mean([a for _, a in res]):.3f}")
budgets = [50, 100, 200, 400]
for b in budgets:
    accs = []
    for s in range(3):
        idx = np.random.default_rng(s).choice(len(X_pool), b, replace=False)
        accs.append(LogisticRegression(max_iter=2000).fit(X_pool[idx], y_pool[idx]).score(X_test, y_test))
    print(f"{b} random labels: test accuracy {np.mean(accs):.3f}")

##############################################################################
# 9. In Python: self-training by hand
##############################################################################
import numpy as np
from sklearn.datasets import load_digits
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split

X, y = load_digits(return_X_y=True)
X_pool, X_test, y_pool, y_test = train_test_split(X / 16, y, test_size=0.3, random_state=1, stratify=y)
lab = np.random.default_rng(1).choice(len(X_pool), 60, replace=False)
Xl, yl = X_pool[lab], y_pool[lab]
Xu = np.delete(X_pool, lab, axis=0)
for rnd in range(1, 5):
    m = LogisticRegression(max_iter=3000).fit(Xl, yl)
    P = m.predict_proba(Xu)
    sure = P.max(axis=1) > 0.9
    print(f"round {rnd}: {len(yl)} training labels, test accuracy {m.score(X_test, y_test):.3f}, adding {sure.sum()} pseudo-labels")
    Xl, yl = np.vstack([Xl, Xu[sure]]), np.concatenate([yl, m.classes_[P[sure].argmax(axis=1)]])
    Xu = Xu[~sure]

##############################################################################
# 12. Going deeper: when unlabelled data misleads, and committees
##############################################################################
import numpy as np
from sklearn.semi_supervised import LabelSpreading
from sklearn.linear_model import LogisticRegression
rng = np.random.default_rng(0)
# The label depends on feature 1; feature 2 is irrelevant noise on a scale 50 times larger.
X = np.c_[rng.normal(0, 1, 600), rng.normal(0, 50, 600)]
y = (X[:, 0] > 0).astype(int)
lab = rng.choice(600, 20, replace=False)
yp = np.full(600, -1); yp[lab] = y[lab]
test = np.setdiff1d(np.arange(600), lab)
sup = LogisticRegression().fit(X[lab], y[lab]).score(X[test], y[test])
spread = (LabelSpreading(kernel="knn", n_neighbors=10).fit(X, yp).transduction_[test] == y[test]).mean()
Xs = X / X.std(axis=0)
spread_s = (LabelSpreading(kernel="knn", n_neighbors=10).fit(Xs, yp).transduction_[test] == y[test]).mean()
print("labelled only:", round(sup, 3), "  label spreading, raw features:", round(spread, 3), "  after scaling:", round(spread_s, 3))
from sklearn.datasets import load_digits
from sklearn.ensemble import BaggingClassifier
Xd, yd = load_digits(return_X_y=True); Xd = Xd / 16
pool, test2 = np.arange(1200), np.arange(1200, len(yd))
def run(strategy, seed):
    r = np.random.default_rng(seed); lab = list(r.choice(pool, 20, replace=False))
    for _ in range(10):
        rest = np.setdiff1d(pool, lab)
        if strategy == "committee":
            com = BaggingClassifier(LogisticRegression(max_iter=1000), n_estimators=5, random_state=seed).fit(Xd[lab], yd[lab])
            votes = np.array([est.predict(Xd[rest]) for est in com.estimators_])
            disagree = np.array([len(set(v)) for v in votes.T])           # number of distinct votes
            pick = rest[np.argsort(-disagree + 1e-3 * r.random(len(rest)))[:15]]
        else:
            pick = r.choice(rest, 15, replace=False)
        lab += list(pick)
    return LogisticRegression(max_iter=1000).fit(Xd[lab], yd[lab]).score(Xd[test2], yd[test2])
for s in ["random", "committee"]:
    print(f"{s:9s}: test accuracy with 170 labels {np.mean([run(s, k) for k in range(3)]):.3f}")

##############################################################################
# Running example: Chennai Homes
#
# The same 12-house dataset used in every lesson (data/houses.csv in the course folder).
##############################################################################
import pandas as pd
import numpy as np
df = pd.read_csv(DATA / "houses.csv")
from sklearn.semi_supervised import LabelSpreading
from sklearn.preprocessing import StandardScaler
X = StandardScaler().fit_transform(df[["size_m2", "dist_km", "age_yrs", "price_lakh"]])
known = np.array([True, False, False, True, False, True, False, False, True, False, True, False])
y = np.where(known, df.sold_fast, -1)
ls = LabelSpreading(kernel="knn", n_neighbors=3).fit(X, y)
hidden = ~known
print("labels known for", known.sum(), "homes; inferred for", hidden.sum())
print("inferred correctly:", int((ls.transduction_[hidden] == df.sold_fast[hidden]).sum()), "of", hidden.sum())
