"""Lesson 25: Imbalanced Data & Anomaly Detection — all the code from the lesson, as one script.

Part of the ML Academy course. Run it with:  python lesson-25.py
(works from any folder; the data is read from ../data/)
"""
from pathlib import Path
DATA = Path(__file__).resolve().parent.parent / "data"   # the course's data folder

##############################################################################
# 2. Why accuracy fails, in numbers
##############################################################################
import numpy as np
from sklearn.datasets import make_classification
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.dummy import DummyClassifier
from sklearn.metrics import accuracy_score, recall_score, precision_score, average_precision_score

# 1% positives, like fraud
X, y = make_classification(n_samples=20000, n_features=10, n_informative=5, weights=[0.99],
                           class_sep=1.0, flip_y=0, random_state=0)
X_tr, X_te, y_tr, y_te = train_test_split(X, y, test_size=0.5, random_state=0, stratify=y)
print("positives in the test set:", int(y_te.sum()), "of", len(y_te))
for name, m in [("always 'normal'", DummyClassifier(strategy="most_frequent")), ("logistic regression", LogisticRegression(max_iter=1000))]:
    m.fit(X_tr, y_tr); pr = m.predict(X_te)
    print(f"{name:20}: accuracy {accuracy_score(y_te, pr):.3f}   recall {recall_score(y_te, pr):.3f}")

##############################################################################
# 3. Thresholds, class weights and resampling
##############################################################################
def report(name, scores, threshold=0.5):
    flag = scores >= threshold
    print(f"{name:32}: recall {recall_score(y_te, flag):.3f}  precision {precision_score(y_te, flag, zero_division=0):.3f}  "
          f"average precision {average_precision_score(y_te, scores):.3f}")

plain = LogisticRegression(max_iter=1000).fit(X_tr, y_tr).predict_proba(X_te)[:, 1]
weighted = LogisticRegression(max_iter=1000, class_weight="balanced").fit(X_tr, y_tr).predict_proba(X_te)[:, 1]
rng = np.random.default_rng(0)
pos = np.flatnonzero(y_tr == 1)
extra = rng.choice(pos, size=(y_tr == 0).sum() - len(pos), replace=True)        # random oversampling
Xo, yo = np.vstack([X_tr, X_tr[extra]]), np.r_[y_tr, y_tr[extra]]
over = LogisticRegression(max_iter=1000).fit(Xo, yo).predict_proba(X_te)[:, 1]

report("plain, threshold 0.5", plain)
report("plain, threshold 0.1", plain, 0.1)
report("class_weight='balanced'", weighted)
print(report("random oversampling", over))

##############################################################################
# 4. SMOTE: synthetic minority examples
##############################################################################
# SMOTE from scratch: new minority points on the line between a point and one of its minority neighbours
from sklearn.neighbors import NearestNeighbors

def smote(Xmin, n_new, k=5, seed=0):
    rng = np.random.default_rng(seed)
    nn = NearestNeighbors(n_neighbors=k + 1).fit(Xmin)
    _, nbrs = nn.kneighbors(Xmin)
    i = rng.integers(0, len(Xmin), n_new)
    j = nbrs[i, rng.integers(1, k + 1, n_new)]          # skip column 0 (the point itself)
    gap = rng.random((n_new, 1))
    return Xmin[i] + gap * (Xmin[j] - Xmin[i])

Xmin = X_tr[y_tr == 1]
new = smote(Xmin, (y_tr == 0).sum() - len(Xmin))
Xs, ys = np.vstack([X_tr, new]), np.r_[y_tr, np.ones(len(new), int)]
report("SMOTE", LogisticRegression(max_iter=1000).fit(Xs, ys).predict_proba(X_te)[:, 1])
print("synthetic minority points created:", len(new))

##############################################################################
# 5. Anomaly detection without labels
##############################################################################
from sklearn.ensemble import IsolationForest
from sklearn.neighbors import LocalOutlierFactor
from sklearn.metrics import roc_auc_score as roc_auc

# Unsupervised anomaly detection: 980 normal points in two clusters, 20 anomalies scattered around them
rng = np.random.default_rng(1)
normal = np.vstack([rng.normal([0, 0], 0.6, (490, 2)), rng.normal([4, 4], 0.6, (490, 2))])
anomalies = rng.uniform(-3, 7, (20, 2))
Xa = np.vstack([normal, anomalies]); truth = np.r_[np.zeros(980), np.ones(20)]

def precision_at_20(score):          # higher score = more anomalous
    return truth[np.argsort(score)[::-1][:20]].mean()

z = np.abs((Xa - Xa.mean(0)) / Xa.std(0)).max(axis=1)        # largest per-feature z-score
iso = -IsolationForest(n_estimators=300, random_state=0).fit(Xa).score_samples(Xa)
lof = -LocalOutlierFactor(n_neighbors=20).fit(Xa).negative_outlier_factor_
for name, s in [("z-score", z), ("Isolation Forest", iso), ("Local Outlier Factor", lof)]:
    print(f"{name:21}: share of true anomalies among the top 20 {precision_at_20(s):.2f}   ROC-AUC {roc_auc(truth, s):.3f}")

##############################################################################
# 8. In Python: a workflow for rare events
##############################################################################
import numpy as np
from sklearn.datasets import make_classification
from sklearn.model_selection import train_test_split
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.metrics import precision_recall_curve, precision_score, recall_score, average_precision_score

X, y = make_classification(n_samples=30000, n_features=10, n_informative=5, weights=[0.99],
                           class_sep=1.0, flip_y=0, random_state=0)
X_tr, X_rest, y_tr, y_rest = train_test_split(X, y, test_size=0.4, random_state=0, stratify=y)
X_val, X_te, y_val, y_te = train_test_split(X_rest, y_rest, test_size=0.5, random_state=0, stratify=y_rest)

model = HistGradientBoostingClassifier(random_state=0).fit(X_tr, y_tr)
p_val, p_te = model.predict_proba(X_val)[:, 1], model.predict_proba(X_te)[:, 1]
print("average precision, validation:", round(average_precision_score(y_val, p_val), 3))

prec, rec, thr = precision_recall_curve(y_val, p_val)
t = thr[np.argmax(prec[:-1] >= 0.8)]                  # lowest threshold with precision of at least 0.8
flag = p_te >= t
print(f"threshold {t:.3f}: test precision {precision_score(y_te, flag):.3f}, recall {recall_score(y_te, flag):.3f}")

##############################################################################
# 11. Going deeper: correcting probabilities and how isolation works
##############################################################################
import numpy as np
from sklearn.datasets import make_classification
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import brier_score_loss

X, y = make_classification(n_samples=40000, n_features=10, n_informative=5, weights=[0.98], flip_y=0, random_state=1)
X_tr, X_te, y_tr, y_te = train_test_split(X, y, test_size=0.5, random_state=0, stratify=y)
pi = y_tr.mean()                                                    # true positive rate in training data
p_bal = LogisticRegression(max_iter=1000, class_weight="balanced").fit(X_tr, y_tr).predict_proba(X_te)[:, 1]

# Undo the reweighting: the model behaves as if positives were as common as negatives
odds = p_bal / (1 - p_bal) * (pi / (1 - pi))
p_fixed = odds / (1 + odds)
p_plain = LogisticRegression(max_iter=1000).fit(X_tr, y_tr).predict_proba(X_te)[:, 1]
for name, p in [("balanced weights", p_bal), ("balanced, corrected", p_fixed), ("plain model", p_plain)]:
    print(f"{name:20}: average predicted risk {p.mean():.3f} (true rate {y_te.mean():.3f})   Brier score {brier_score_loss(y_te, p):.4f}")

# Isolation Forest's intuition: average number of random splits needed to isolate a point
rng = np.random.default_rng(0)
pts = np.vstack([rng.normal(0, 1, (500, 2)), [[6, 6]]])            # 500 normal points and one far away
def splits_to_isolate(i, trials=200):
    total = 0
    for _ in range(trials):
        idx = np.arange(len(pts)); depth = 0
        while len(idx) > 1:
            f = rng.integers(2); lo, hi = pts[idx, f].min(), pts[idx, f].max()
            t = rng.uniform(lo, hi)
            idx = idx[pts[idx, f] < t] if pts[i, f] < t else idx[pts[idx, f] >= t]
            depth += 1
        total += depth
    return total / trials
print("average splits to isolate the far point:   ", round(splits_to_isolate(500), 1))
print("average splits to isolate a typical point: ", round(np.mean([splits_to_isolate(i, 40) for i in range(10)]), 1))

##############################################################################
# Running example: Chennai Homes
#
# The same 12-house dataset used in every lesson (data/houses.csv in the course folder).
##############################################################################
import pandas as pd
import numpy as np
df = pd.read_csv(DATA / "houses.csv")
from sklearn.ensemble import IsolationForest
cols = ["size_m2", "price_lakh", "dist_km", "age_yrs"]
iso = IsolationForest(n_estimators=500, random_state=0).fit(df[cols])
df["oddness"] = -iso.score_samples(df[cols])            # higher = more unusual
print(df.sort_values("oddness", ascending=False)[["id", "area", "description", "oddness"]].head(3).round(3).to_string(index=False))
