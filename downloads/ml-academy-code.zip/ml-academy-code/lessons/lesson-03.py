"""Lesson 3: Derivatives & Gradients — all the code from the lesson, as one script.

Part of the ML Academy course. Run it with:  python lesson-03.py
(works from any folder; the data is read from ../data/)
"""
from pathlib import Path
DATA = Path(__file__).resolve().parent.parent / "data"   # the course's data folder

##############################################################################
# 11. Checking derivatives with code
##############################################################################
def f(x):
    return (3 * x + 1) ** 2

def f_prime(x):          # our hand-derived answer
    return 6 * (3 * x + 1)

def numeric_derivative(f, x, h=1e-6):
    return (f(x + h) - f(x - h)) / (2 * h)

for x in [0, 1, -2]:
    print(x, f_prime(x), round(numeric_derivative(f, x), 4))
# 0 6 6.0
# 1 24 24.0
# -2 -30 -30.0
w = 0.0
lr = 0.05                       # learning rate (eta)
for step in range(30):
    grad = 4 * (2 * w - 6)      # dL/dw
    w = w - lr * grad           # move downhill
print(round(w, 4))              # 3.0  -> the perfect weight

##############################################################################
# Running example: Chennai Homes
#
# The same 12-house dataset used in every lesson (data/houses.csv in the course folder).
##############################################################################
import pandas as pd
import numpy as np
df = pd.read_csv(DATA / "houses.csv")
x, y = df["size_m2"].to_numpy(), df["price_lakh"].to_numpy()
def loss(w):            # MSE for the model price = w * size
    return np.mean((w * x - y) ** 2)
def grad(w):            # dL/dw = (2/n) * sum((w*x - y) * x)
    return 2 * np.mean((w * x - y) * x)
for w in [0.4, 0.65, 0.9]:
    print(w, round(loss(w), 1), round(grad(w), 1))
