"""Lesson 17: Dimensionality Reduction & PCA — all the code from the lesson, as one script.

Part of the ML Academy course. Run it with:  python lesson-17.py
(works from any folder; the data is read from ../data/)
"""
from pathlib import Path
DATA = Path(__file__).resolve().parent.parent / "data"   # the course's data folder

##############################################################################
# 11. In Python
##############################################################################
import numpy as np
from sklearn.datasets import load_digits
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import make_pipeline

X, y = load_digits(return_X_y=True)
pca = PCA().fit(X)
cum = np.cumsum(pca.explained_variance_ratio_)
for k in [2, 10, 20, 30]:
    print(f"{k:2d} components keep {cum[k-1]:.1%} of the variance")
print("components needed for 95%:", np.argmax(cum >= 0.95) + 1)

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, stratify=y, random_state=0)
for k in [5, 10, 20, 40, 64]:
    model = make_pipeline(StandardScaler(), PCA(n_components=k), LogisticRegression(max_iter=2000))
    model.fit(X_train, y_train)
    print(f"{k:2d} components: test accuracy {model.score(X_test, y_test):.3f}")

##############################################################################
# Running example: Chennai Homes
#
# The same 12-house dataset used in every lesson (data/houses.csv in the course folder).
##############################################################################
import pandas as pd
import numpy as np
df = pd.read_csv(DATA / "houses.csv")
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
cols = ["size_m2", "bedrooms", "dist_km", "age_yrs"]
pca = PCA().fit(StandardScaler().fit_transform(df[cols]))
print("explained variance ratio:", pca.explained_variance_ratio_.round(3))
print("PC1 weights:", {c: round(float(v), 2) for c, v in zip(cols, pca.components_[0])})
