"""Lesson 17: Dimensionality Reduction & PCA — all the code from the lesson, as one script.

Part of the ML Academy course. Run it with:  python lesson-17.py
(works from any folder; the data is read from ../data/)
"""
from pathlib import Path
DATA = Path(__file__).resolve().parent.parent / "data"   # the course's data folder

##############################################################################
# 11. In Python
##############################################################################
import numpy as np
from sklearn.datasets import load_digits
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import make_pipeline

X, y = load_digits(return_X_y=True)
pca = PCA().fit(X)
cum = np.cumsum(pca.explained_variance_ratio_)
for k in [2, 10, 20, 30]:
    print(f"{k:2d} components keep {cum[k-1]:.1%} of the variance")
print("components needed for 95%:", np.argmax(cum >= 0.95) + 1)

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, stratify=y, random_state=0)
for k in [5, 10, 20, 40, 64]:
    model = make_pipeline(StandardScaler(), PCA(n_components=k), LogisticRegression(max_iter=2000))
    model.fit(X_train, y_train)
    print(f"{k:2d} components: test accuracy {model.score(X_test, y_test):.3f}")

##############################################################################
# 14. Going deeper: choosing components, and non-linear maps
##############################################################################
import numpy as np
from sklearn.datasets import load_digits, make_circles
from sklearn.decomposition import PCA, KernelPCA
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import cross_val_score

# How many components? Variance kept and reconstruction error on the digits (64 pixels)
X, y = load_digits(return_X_y=True)
pca = PCA().fit(X)
cum = np.cumsum(pca.explained_variance_ratio_)
for k in [2, 10, 20, 30, 40]:
    p = PCA(k).fit(X)
    rec = p.inverse_transform(p.transform(X))
    err = np.mean((X - rec) ** 2) / np.mean((X - X.mean(0)) ** 2)
    print(f"{k:2d} components: variance kept {cum[k - 1]:.3f}   relative reconstruction error {err:.3f}")
print("components needed for 95% of the variance:", int(np.searchsorted(cum, 0.95) + 1))
# Kernel PCA: a non-linear version that can "unroll" circles
Xc, yc = make_circles(n_samples=400, factor=0.3, noise=0.05, random_state=0)
for name, emb in [("ordinary PCA", PCA(1)), ("kernel PCA (RBF)", KernelPCA(1, kernel="rbf", gamma=5))]:
    z = emb.fit_transform(Xc)
    acc = cross_val_score(LogisticRegression(), z, yc, cv=5).mean()
    print(f"{name:17}: a linear classifier on the 1 new feature scores {acc:.3f}")
from sklearn.manifold import TSNE
from sklearn.neighbors import KNeighborsClassifier

# Compare 2-D maps: how well do a point's map neighbours share its digit label?
maps = {"PCA, 2-D": PCA(2).fit_transform(X),
        "t-SNE, 2-D": TSNE(2, perplexity=30, random_state=0, init="pca").fit_transform(X)}
for name, Z in maps.items():
    acc = cross_val_score(KNeighborsClassifier(5), Z, y, cv=5).mean()
    print(f"{name:10}: 5-nearest-neighbour accuracy in the map {acc:.3f}")

##############################################################################
# Running example: Chennai Homes
#
# The same 12-house dataset used in every lesson (data/houses.csv in the course folder).
##############################################################################
import pandas as pd
import numpy as np
df = pd.read_csv(DATA / "houses.csv")
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
cols = ["size_m2", "bedrooms", "dist_km", "age_yrs"]
pca = PCA().fit(StandardScaler().fit_transform(df[cols]))
print("explained variance ratio:", pca.explained_variance_ratio_.round(3))
print("PC1 weights:", {c: round(float(v), 2) for c, v in zip(cols, pca.components_[0])})
