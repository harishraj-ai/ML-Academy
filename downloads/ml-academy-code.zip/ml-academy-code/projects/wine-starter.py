"""Mini-project (starter). Fill in each TODO from top to bottom and run the file again; it stops at the first unfinished step, and each check() prints ✅ or a hint.
Run with:  python wine-starter.py
"""
# Project: Discovering wine cultivars
#
# ML Academy — starter notebook
#
# Goal. Pretend we don't know the cultivars. Can PCA and clustering rediscover the three groups
# from the chemistry alone?
#
# The data. 178 wines from three grape cultivars grown in the same region of Italy (Forina et
# al.), shipped with scikit-learn as load_wine. Thirteen chemical measurements per wine: alcohol,
# malic acid, flavanoids, colour intensity, proline and more. The cultivar labels exist — but we
# hide them until the very end.
#
# Uses: Lesson 16, Lesson 17.
#
# Work through the steps in order. Lines marked # TODO are yours to write; each step ends with a
# check that prints ✅ when you're right (and a hint when you're not). Cells that use a step's
# result will show errors until that step is done — that's expected. The solution notebook is in
# the same folder.
#
# Requirements: pip install numpy pandas scikit-learn matplotlib — the dataset ships with scikit-
# learn, so no download is needed.
# Run this cell first: it defines check(), which tells you whether each step is right.
import numpy as np
def check(get, want, hint=''):
    try:
        got = get()
        if isinstance(want, str):
            ok = str(got) == want
        else:
            ok = np.shape(got) == np.shape(want) and np.allclose(np.asarray(got, dtype=float), np.asarray(want, dtype=float), rtol=1e-4, atol=1e-6)
    except Exception:
        ok = False
    print('✅ Correct!' if ok else '❌ Not yet. Hint: ' + hint)

# Step 1. Load the chemistry (and put the labels aside)
import numpy as np
import pandas as pd
from sklearn.datasets import load_wine
wine = load_wine(as_frame=True)
X = wine.data                # 13 chemical measurements
hidden_labels = wine.target  # we won't look at these until the end
print(X.shape)
print(X.describe().loc[["mean", "std"]].round(2))
check(lambda: X.shape, [178, 13], hint='load_wine(as_frame=True).data.')
# Step 2. Standardise
#
# The features have wildly different scales (proline is in the hundreds, hue around 1).
# Standardise them so each counts equally (Lesson 17).
from sklearn.preprocessing import StandardScaler
Z = None  # TODO: standardise X
print(Z.mean(axis=0).round(2)[:4], Z.std(axis=0).round(2)[:4])
check(lambda: float(np.round(Z.std(axis=0).mean(), 6)), 1.0, hint='StandardScaler().fit_transform(X) gives every column mean 0 and standard deviation 1.')
# Step 3. PCA: how many directions matter?
#
# Fit PCA and look at the explained variance ratio of the first components.
from sklearn.decomposition import PCA
pca = PCA().fit(Z)
ratio = None  # TODO: the explained variance ratio of every component
print("first five:", ratio[:5].round(3))
print("cumulative:", np.cumsum(ratio)[:5].round(3))
check(lambda: ratio[0], 0.36198848099926334, hint='pca.explained_variance_ratio_.')
check(lambda: np.cumsum(ratio)[1], 0.5540633835693527, hint='The first two components together.')
# Step 4. Look at the data in 2D
#
# Project onto the first two components and plot. Can you already see groups?
import matplotlib.pyplot as plt
P = PCA(n_components=2).fit_transform(Z)
plt.figure(figsize=(5, 4))
plt.scatter(P[:, 0], P[:, 1], s=15, color="grey")
plt.xlabel("PC1"); plt.ylabel("PC2"); plt.title("178 wines, unlabelled")
print(plt.show())
# Step 5. Choose k
#
# Run k-means for k = 2 to 6 and compare inertia (elbow) and the silhouette score (Lesson 16).
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score
sil = {}
for k in range(2, 7):
    km = KMeans(n_clusters=k, n_init=10, random_state=0).fit(Z)
    sil[k] = None  # TODO: the silhouette score of this clustering
    print(f"k={k}  inertia={km.inertia_:7.1f}  silhouette={sil[k]:.3f}")
best_k = max(sil, key=sil.get)
print("best k by silhouette:", best_k)
check(lambda: best_k, 3, hint='silhouette_score(Z, km.labels_) for each k.')
check(lambda: sil[3], 0.2848589191898987, hint='Use n_init=10 and random_state=0.')
# Step 6. Reveal the labels
#
# Now compare the clusters with the real cultivars. The adjusted Rand index (ARI) is 1 for a
# perfect match and about 0 for random clusters.
from sklearn.metrics import adjusted_rand_score
clusters = KMeans(n_clusters=best_k, n_init=10, random_state=0).fit_predict(Z)
ari = None  # TODO: the adjusted Rand index between hidden_labels and clusters
print("ARI:", round(ari, 3))
print(pd.crosstab(clusters, hidden_labels, rownames=["cluster"], colnames=["cultivar"]))
check(lambda: ari, 0.8974949815093207, hint='adjusted_rand_score(hidden_labels, clusters).')
# Go further
#
# - Repeat the clustering on the first two PCA components only. Is the ARI better or worse?
# - Try agglomerative clustering and draw a dendrogram with SciPy.
# - What happens to the silhouette scores if you forget to standardise?
