"""Mini-project (starter). Fill in each TODO from top to bottom and run the file again; it stops at the first unfinished step, and each check() prints ✅ or a hint.
Run with:  python tumours-starter.py
"""
# Project: Classifying breast tumours
#
# ML Academy — starter notebook
#
# Goal. Build a classifier that flags malignant tumours, choose between five algorithms fairly,
# and tune it so that it almost never misses a malignant case.
#
# The data. 569 breast-tumour biopsies from the Wisconsin Diagnostic Breast Cancer study (Street,
# Wolberg and Mangasarian, 1993), shipped with scikit-learn as load_breast_cancer. Each has 30
# measurements of the cell nuclei in a digitised image (radius, texture, smoothness, …) and a
# diagnosis: malignant or benign.
#
# Uses: Lesson 8, Lesson 9, Lesson 11, Lesson 13, Lesson 14, Lesson 15.
#
# Work through the steps in order. Lines marked # TODO are yours to write; each step ends with a
# check that prints ✅ when you're right (and a hint when you're not). Cells that use a step's
# result will show errors until that step is done — that's expected. The solution notebook is in
# the same folder.
#
# Requirements: pip install numpy pandas scikit-learn matplotlib scipy — the dataset ships with
# scikit-learn, so no download is needed.
# Run this cell first: it defines check(), which tells you whether each step is right.
import numpy as np
def check(get, want, hint=''):
    try:
        got = get()
        if isinstance(want, str):
            ok = str(got) == want
        else:
            ok = np.shape(got) == np.shape(want) and np.allclose(np.asarray(got, dtype=float), np.asarray(want, dtype=float), rtol=1e-4, atol=1e-6)
    except Exception:
        ok = False
    print('✅ Correct!' if ok else '❌ Not yet. Hint: ' + hint)

# Step 1. Load the data
#
# In scikit-learn's encoding 0 = malignant. We make malignant the positive class (1), because
# that's the case we must not miss.
import numpy as np
import pandas as pd
from sklearn.datasets import load_breast_cancer
data = load_breast_cancer(as_frame=True)
X = data.data
y = None  # TODO: 1 for malignant (target 0), 0 for benign
print(X.shape, "share malignant:", round(y.mean(), 3))
check(lambda: y.sum(), 212, hint="(data.target == 0).astype(int) turns 'malignant' into 1.")
# Step 2. Split, keeping the class balance
#
# Use stratify=y so training and test sets have the same share of malignant cases. Keep 25% for
# testing (random_state=0).
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = None, None, None, None  # TODO: stratified split, test_size=0.25, random_state=0
print(X_train.shape, X_test.shape)
check(lambda: y_test.sum(), 53, hint='Add stratify=y to train_test_split.')
# Step 3. Compare five algorithms with cross-validation
#
# Each model that relies on distances or weights gets a StandardScaler. Trees don't need one. We
# score with 5-fold cross-validated accuracy on the training set only — the test set stays
# untouched.
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.neighbors import KNeighborsClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC
from sklearn.model_selection import cross_val_score
models = {
    "logistic regression": make_pipeline(StandardScaler(), LogisticRegression(max_iter=1000)),
    "kNN (k=5)": make_pipeline(StandardScaler(), KNeighborsClassifier(n_neighbors=5)),
    "decision tree": DecisionTreeClassifier(max_depth=4, random_state=0),
    "random forest": RandomForestClassifier(n_estimators=300, random_state=0),
    "SVM (RBF)": make_pipeline(StandardScaler(), SVC()),
}
cv_acc = None  # TODO: mean 5-fold CV accuracy for every model
best_name = max(cv_acc, key=cv_acc.get)
for name, acc in sorted(cv_acc.items(), key=lambda kv: -kv[1]):
    print(f"{name:20s} {acc:.3f}")
print("best:", best_name)
check(lambda: best_name, 'logistic regression', hint='A dict comprehension: {name: cross_val_score(m, X_train, y_train, cv=5).mean() for name, m in models.items()}.')
check(lambda: cv_acc['random forest'], 0.955403556771546, hint='Use cv=5 and the default accuracy scoring.')
# Step 4. Test the winner once
#
# Fit the best model on the full training set and evaluate it on the test set — once. Look at the
# confusion matrix: which kind of mistake does it make?
from sklearn.metrics import confusion_matrix, precision_score, recall_score, accuracy_score
best = models[best_name].fit(X_train, y_train)
pred = best.predict(X_test)
cm = confusion_matrix(y_test, pred)
recall = None  # TODO: recall for the malignant class
precision = precision_score(y_test, pred)
print(cm)
print(f"accuracy {accuracy_score(y_test, pred):.3f} · precision {precision:.3f} · recall {recall:.3f}")
check(lambda: recall, 0.9622641509433962, hint='recall_score(y_test, pred): the share of malignant tumours it caught.')
check(lambda: cm.tolist(), [[90, 0], [2, 51]], hint='confusion_matrix(y_test, pred).')
# Step 5. Never miss a malignant tumour: lower the threshold
#
# A missed cancer is far worse than a false alarm that leads to another test. Use predicted
# probabilities and lower the threshold until recall reaches 1.0, then see what it costs in
# precision (Lesson 9).
proba = best.predict_proba(X_test)[:, 1]
for t in [0.5, 0.3, 0.2, 0.1]:
    p_t = None  # TODO: 1 where the probability is at least the threshold t
    print(f"threshold {t}: precision {precision_score(y_test, p_t):.3f}, recall {recall_score(y_test, p_t):.3f}, missed {int(((p_t == 0) & (y_test == 1)).sum())}")
low = (proba >= 0.1).astype(int)
recall_low = recall_score(y_test, low)
check(lambda: recall_low, 1.0, hint='Compare proba with the threshold: (proba >= t).astype(int).')
# Step 6. Which measurements matter?
#
# Random forests report how much each feature reduced impurity (Lesson 14).
forest = models["random forest"].fit(X_train, y_train)
importances = None  # TODO: a Series of forest.feature_importances_ indexed by the column names, largest first
print(importances.head(5).round(3))
check(lambda: importances.index[0], 'mean concave points', hint='pd.Series(forest.feature_importances_, index=X.columns).sort_values(ascending=False).')
# Go further
#
# - Tune C for logistic regression with GridSearchCV.
# - Draw the ROC curve with RocCurveDisplay.from_estimator and read off the AUC.
# - Which threshold would you choose, and how would you explain the trade-off to a doctor?
