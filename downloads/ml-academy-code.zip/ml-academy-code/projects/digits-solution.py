"""Mini-project (solution). The complete worked solution.
Run with:  python digits-solution.py
"""
# Project: Recognising handwritten digits
#
# ML Academy — complete solution
#
# Goal. Train a neural network to read the digits, compare it with simpler models, and study the
# mistakes it makes.
#
# The data. 1,797 handwritten digits (0–9) from the UCI optical recognition dataset (Alpaydin and
# Kaynak), shipped with scikit-learn as load_digits. Each image is 8×8 pixels with brightness
# 0–16, flattened into 64 numbers.
#
# Uses: Lesson 18, Lesson 19, Lesson 20.
#
# This notebook contains the full solution with outputs. Try the starter notebook first!
#
# Requirements: pip install numpy pandas scikit-learn matplotlib scipy — the dataset ships with
# scikit-learn, so no download is needed.
# Run this cell first: it defines check(), which tells you whether each step is right.
import numpy as np
def check(get, want, hint=''):
    try:
        got = get()
        if isinstance(want, str):
            ok = str(got) == want
        else:
            ok = np.shape(got) == np.shape(want) and np.allclose(np.asarray(got, dtype=float), np.asarray(want, dtype=float), rtol=1e-4, atol=1e-6)
    except Exception:
        ok = False
    print('✅ Correct!' if ok else '❌ Not yet. Hint: ' + hint)

# Step 1. Load and look at some digits
import numpy as np
import matplotlib.pyplot as plt
from sklearn.datasets import load_digits
digits = load_digits()
X, y = digits.data, digits.target
print(X.shape)
fig, axes = plt.subplots(1, 8, figsize=(8, 1.4))
for ax, img, lab in zip(axes, digits.images, y):
    ax.imshow(img, cmap="gray_r"); ax.set_title(lab); ax.axis("off")
print(plt.show())
check(lambda: X.shape, [1797, 64], hint='digits.data has one row of 64 pixels per image.')
# Step 2. Split
#
# Keep 25% for testing, stratified so every digit is fairly represented (random_state=0).
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, stratify=y, random_state=0)
print(X_train.shape, X_test.shape)
check(lambda: X_test.shape, [450, 64], hint='train_test_split(X, y, test_size=0.25, stratify=y, random_state=0).')
# Step 3. A baseline: logistic regression
#
# Always start simple. Logistic regression handles 10 classes automatically.
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
baseline = make_pipeline(StandardScaler(), LogisticRegression(max_iter=2000)).fit(X_train, y_train)
baseline_acc = baseline.score(X_test, y_test)
print("logistic regression:", round(baseline_acc, 4))
check(lambda: baseline_acc, 0.9688888888888889, hint='model.score(X_test, y_test) returns the accuracy.')
# Step 4. A neural network
#
# An MLP with one hidden layer of 64 ReLU neurons (Lesson 18), trained with Adam.
from sklearn.neural_network import MLPClassifier
mlp = make_pipeline(StandardScaler(), MLPClassifier(hidden_layer_sizes=(64,), max_iter=1000, random_state=0))
mlp.fit(X_train, y_train)
mlp_acc = mlp.score(X_test, y_test)
print("neural network:", round(mlp_acc, 4))
check(lambda: mlp_acc, 0.9733333333333334, hint='make_pipeline(StandardScaler(), MLPClassifier(...)), then fit.')
# Step 5. Is the neural network really best?
#
# Compare with an RBF-kernel SVM (Lesson 15). On small, clean data a classic model can win —
# that's normal.
from sklearn.svm import SVC
svm = make_pipeline(StandardScaler(), SVC()).fit(X_train, y_train)
svm_acc = svm.score(X_test, y_test)
print(f"logistic {baseline_acc:.4f} · neural net {mlp_acc:.4f} · SVM {svm_acc:.4f}")
check(lambda: svm_acc, 0.9822222222222222, hint='svm.score(X_test, y_test).')
# Step 6. Study the mistakes
#
# Which digits does the network confuse? Find the largest off-diagonal entry of the confusion
# matrix, then look at a few misread images.
from sklearn.metrics import confusion_matrix
pred = mlp.predict(X_test)
cm = confusion_matrix(y_test, pred)
n_errors = int((pred != y_test).sum())
off = cm.copy(); np.fill_diagonal(off, 0)
true_d, pred_d = np.unravel_index(off.argmax(), off.shape)
print("errors:", n_errors, "· most common confusion: a", true_d, "read as", pred_d)
wrong = np.where(pred != y_test)[0][:6]
fig, axes = plt.subplots(1, len(wrong), figsize=(1.3 * len(wrong), 1.6))
for ax, i in zip(axes, wrong):
    ax.imshow(X_test[i].reshape(8, 8), cmap="gray_r"); ax.set_title(f"{y_test[i]}→{pred[i]}"); ax.axis("off")
print(plt.show())
check(lambda: n_errors, 12, hint='Count where pred != y_test.')
check(lambda: [int(true_d), int(pred_d)], [8, 1], hint='The largest value off the diagonal of the confusion matrix.')
# Go further
#
# - Try two hidden layers, e.g. (128, 64). Does accuracy change on cross-validation?
# - Plot the learning curve: mlp[-1].loss_curve_.
# - A CNN would see the 2D structure of the images (Lesson 19). Why does a plain MLP still do well
# on 8×8 images?
