"""Mini-project (starter). Fill in each TODO from top to bottom and run the file again; it stops at the first unfinished step, and each check() prints ✅ or a hint.
Run with:  python diabetes-starter.py
"""
# Project: Predicting diabetes progression
#
# ML Academy — starter notebook
#
# Goal. Predict disease progression from the baseline measurements, and find out how much better
# than a naive guess you can do.
#
# The data. 442 diabetes patients from the study by Efron, Hastie, Johnstone and Tibshirani
# (2004), shipped with scikit-learn as load_diabetes. Ten measurements per patient — age, sex,
# body-mass index (BMI), blood pressure and six blood-serum values (s1–s6) — and a number
# measuring how far the disease progressed one year later.
#
# Uses: Lesson 5, Lesson 6, Lesson 9, Lesson 10.
#
# Work through the steps in order. Lines marked # TODO are yours to write; each step ends with a
# check that prints ✅ when you're right (and a hint when you're not). Cells that use a step's
# result will show errors until that step is done — that's expected. The solution notebook is in
# the same folder.
#
# Requirements: pip install numpy pandas scikit-learn matplotlib — the dataset ships with scikit-
# learn, so no download is needed.
# Run this cell first: it defines check(), which tells you whether each step is right.
import numpy as np
def check(get, want, hint=''):
    try:
        got = get()
        if isinstance(want, str):
            ok = str(got) == want
        else:
            ok = np.shape(got) == np.shape(want) and np.allclose(np.asarray(got, dtype=float), np.asarray(want, dtype=float), rtol=1e-4, atol=1e-6)
    except Exception:
        ok = False
    print('✅ Correct!' if ok else '❌ Not yet. Hint: ' + hint)

# Step 1. Load and look at the data
#
# Load the data as a pandas table. scaled=False gives the original units (age in years, BMI in
# kg/m², …).
import numpy as np
import pandas as pd
from sklearn.datasets import load_diabetes
df = load_diabetes(as_frame=True, scaled=False).frame
print(df.shape)
print(df.head())
check(lambda: df.shape, [442, 11], hint='Use load_diabetes(as_frame=True, scaled=False).frame.')
# Step 2. Split the data and set a baseline
#
# Hold out 20% for testing (random_state=42). Then compute the baseline: predict the training mean
# for every test patient and measure the MAE. Every real model must beat this number.
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error, r2_score
X, y = df.drop(columns="target"), df["target"]
X_train, X_test, y_train, y_test = None, None, None, None  # TODO: split with test_size=0.2 and random_state=42
baseline_pred = None  # TODO: an array holding the training mean, one value per test row
baseline_mae = mean_absolute_error(y_test, baseline_pred)
print("baseline MAE:", round(baseline_mae, 1))
check(lambda: X_train.shape, [353, 10], hint='train_test_split(X, y, test_size=0.2, random_state=42).')
check(lambda: baseline_mae, 64.00646146990485, hint='np.full(len(y_test), y_train.mean()) repeats the training mean.')
# Step 3. One feature: BMI
#
# Fit a straight line using BMI alone (Lesson 6). How much of the baseline error does it remove?
from sklearn.linear_model import LinearRegression
bmi_model = None  # TODO: fit LinearRegression on the bmi column only
bmi_pred = bmi_model.predict(X_test[["bmi"]])
bmi_mae, bmi_r2 = mean_absolute_error(y_test, bmi_pred), r2_score(y_test, bmi_pred)
print(f"slope {bmi_model.coef_[0]:.2f} per BMI unit · MAE {bmi_mae:.1f} · R² {bmi_r2:.3f}")
check(lambda: bmi_mae, 52.259976445345536, hint="Use X_train[['bmi']] (double brackets keep it a table).")
check(lambda: bmi_r2, 0.23335039815872138, hint='r2_score(y_test, bmi_pred).')
# Step 4. All ten features
#
# Now use every feature. Put a StandardScaler in a pipeline so the coefficients are comparable
# (Lesson 20).
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
full_model = None  # TODO: a pipeline of StandardScaler then LinearRegression
full_model.fit(X_train, y_train)
full_pred = full_model.predict(X_test)
full_mae, full_r2 = mean_absolute_error(y_test, full_pred), r2_score(y_test, full_pred)
print(f"MAE {full_mae:.1f} · R² {full_r2:.3f}")
print(pd.Series(full_model[-1].coef_, X.columns).sort_values().round(1))
check(lambda: full_mae, 42.79409467959994, hint='make_pipeline(StandardScaler(), LinearRegression()).')
check(lambda: full_r2, 0.4526027629719195, hint='Fit the pipeline on X_train, y_train first.')
# Step 5. Don't over-read the coefficients
#
# Look at s1 and s2: one has a large negative weight, the other a large positive one. Are they
# correlated? When two features move together, linear regression can split credit between them in
# strange ways — the individual weights become unreliable even if predictions are fine (Lesson
# 10).
corr_s1_s2 = None  # TODO: the correlation between s1 and s2 in the training data
print("correlation of s1 and s2:", round(corr_s1_s2, 3))
check(lambda: corr_s1_s2, 0.8910632483212737, hint="pandas: X_train['s1'].corr(X_train['s2']).")
# Step 6. Ridge, with the penalty chosen by cross-validation
#
# RidgeCV tries several penalty strengths with cross-validation and keeps the best (Lesson 10).
from sklearn.linear_model import RidgeCV
ridge = None  # TODO: a pipeline of StandardScaler then RidgeCV(alphas=np.logspace(-3, 3, 13))
ridge.fit(X_train, y_train)
ridge_pred = ridge.predict(X_test)
ridge_mae = mean_absolute_error(y_test, ridge_pred)
print("chosen alpha:", ridge[-1].alpha_, "· test MAE:", round(ridge_mae, 1))
check(lambda: ridge_mae, 42.81199941834887, hint='Same as the full model, but RidgeCV(alphas=np.logspace(-3, 3, 13)) as the last step.')
# Step 7. Compare fairly with cross-validation
#
# One test split is noisy. Compare the two models with 5-fold cross-validation on the training set
# (Lesson 5).
from sklearn.model_selection import cross_val_score
cv_lin = None  # TODO: 5-fold CV MAE for full_model (note the minus sign)
cv_ridge = -cross_val_score(ridge, X_train, y_train, cv=5, scoring="neg_mean_absolute_error")
print(f"linear: {cv_lin.mean():.1f} ± {cv_lin.std():.1f}   ridge: {cv_ridge.mean():.1f} ± {cv_ridge.std():.1f}")
check(lambda: cv_lin.mean(), 45.54332900504238, hint="cross_val_score(full_model, X_train, y_train, cv=5, scoring='neg_mean_absolute_error'), negated.")
# Go further
#
# - Add squared terms with PolynomialFeatures(degree=2) in the pipeline. Does cross-validated MAE
# improve?
# - Try LassoCV: which features does it switch off?
# - Plot predicted against actual progression for the test set. Where are the biggest errors?
