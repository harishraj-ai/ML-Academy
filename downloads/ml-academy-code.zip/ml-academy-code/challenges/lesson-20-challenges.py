"""Lesson 20 coding challenges. Each block has ONE missing line marked "your code here" or "replace".
Write the line, run this file, and each check prints ✅ or a hint.  Solutions: the SOLUTIONS list in tests/test_code.py
"""
# Checker used by the challenges below — run this cell first.
import numpy as np
def check(got, want, hint='', atol=1e-6):
    try:
        ok = got is not None and np.shape(got) == np.shape(want) and np.allclose(np.asarray(got, dtype=float), np.asarray(want, dtype=float), rtol=1e-4, atol=atol)
    except Exception:
        ok = False
    print('✅ Correct!' if ok else '❌ Not yet. Hint: ' + hint)

EXPECTED_1 = 2.449489742783178
EXPECTED_2 = 3


# ---- Challenge 1: Standardise with training statistics ----
# Standardise the new value using the training mean and standard deviation.
import numpy as np
train = np.array([10.0, 20.0, 30.0])
new = 40.0
z = None  # ← your code here
check(z, EXPECTED_1, hint='(new − training mean) / training standard deviation.')


# ---- Challenge 2: One-hot encoding ----
# One-hot encode the colour column with pandas and count the columns produced.
import pandas as pd
df = pd.DataFrame({"colour": ["red", "green", "blue", "green"]})
onehot = df[["colour"]]  # ← replace with one-hot encoding
n_cols = onehot.shape[1]
check(n_cols, EXPECTED_2, hint="pd.get_dummies(df['colour']) makes one column per category.")
