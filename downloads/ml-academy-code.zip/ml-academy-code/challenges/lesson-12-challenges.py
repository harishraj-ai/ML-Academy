"""Lesson 12 coding challenges. Each block has ONE missing line marked "your code here" or "replace".
Write the line, run this file, and each check prints ✅ or a hint.  Solutions: the SOLUTIONS list in tests/test_code.py
"""
# Checker used by the challenges below — run this cell first.
import numpy as np
def check(got, want, hint='', atol=1e-6):
    try:
        ok = got is not None and np.shape(got) == np.shape(want) and np.allclose(np.asarray(got, dtype=float), np.asarray(want, dtype=float), rtol=1e-4, atol=atol)
    except Exception:
        ok = False
    print('✅ Correct!' if ok else '❌ Not yet. Hint: ' + hint)

EXPECTED_1 = 0.013333333333333334
EXPECTED_2 = -12.53457671250221


# ---- Challenge 1: Add-one smoothing ----
# Compute P(word | spam) with add-one smoothing.
count, total_words, vocab_size = 3, 200, 100
p_word = None  # ← your code here
check(p_word, EXPECTED_1, hint='(count + 1) / (total + vocabulary size).')


# ---- Challenge 2: Scores in log space ----
# Add the log prior and the log likelihoods to get the class score.
import numpy as np
prior = 0.4
likelihoods = np.array([0.02, 0.15, 0.003])
log_score = None  # ← your code here
check(log_score, EXPECTED_2, hint='log(prior) + Σ log(likelihood).')
