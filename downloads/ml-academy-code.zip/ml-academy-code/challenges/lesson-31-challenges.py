"""Lesson 31 coding challenges. Each block has ONE missing line marked "your code here" or "replace".
Write the line, run this file, and each check prints ✅ or a hint.  Solutions: the SOLUTIONS list in tests/test_code.py
"""
# Checker used by the challenges below — run this cell first.
import numpy as np
def check(got, want, hint='', atol=1e-6):
    try:
        ok = got is not None and np.shape(got) == np.shape(want) and np.allclose(np.asarray(got, dtype=float), np.asarray(want, dtype=float), rtol=1e-4, atol=atol)
    except Exception:
        ok = False
    print('✅ Correct!' if ok else '❌ Not yet. Hint: ' + hint)

EXPECTED_1 = 6.0
EXPECTED_2 = 1.65


# ---- Challenge 1: A discounted return ----
# Compute the discounted return of the rewards with γ = 0.5.
rewards = [2, 4, 8]
gamma = 0.5
ret = sum(rewards)  # ← discount each reward
check(ret, EXPECTED_1, hint='Multiply each reward by γ to the power of its step.')


# ---- Challenge 2: A Q-learning update ----
# Apply one Q-learning update.
q, r, best_next, alpha, gamma = 1.0, 0.5, 2.0, 0.5, 0.9
q_new = r + gamma * best_next  # ← move only a fraction alpha of the way
check(q_new, EXPECTED_2, hint='Move q towards r + γ × best_next by a fraction α.')
