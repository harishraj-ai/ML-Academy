"""Lesson 30 coding challenges. Each block has ONE missing line marked "your code here" or "replace".
Write the line, run this file, and each check prints ✅ or a hint.  Solutions: the SOLUTIONS list in tests/test_code.py
"""
# Checker used by the challenges below — run this cell first.
import numpy as np
def check(got, want, hint='', atol=1e-6):
    try:
        ok = got is not None and np.shape(got) == np.shape(want) and np.allclose(np.asarray(got, dtype=float), np.asarray(want, dtype=float), rtol=1e-4, atol=atol)
    except Exception:
        ok = False
    print('✅ Correct!' if ok else '❌ Not yet. Hint: ' + hint)

EXPECTED_1 = 0.2282
EXPECTED_2 = 2


# ---- Challenge 1: Population stability index ----
# Compute the PSI between expected and actual bin shares.
import numpy as np
e = np.array([0.25, 0.25, 0.25, 0.25])
a = np.array([0.10, 0.20, 0.30, 0.40])
psi = np.sum(a - e)  # ← multiply by the log ratio
result = round(float(psi), 4)
check(result, EXPECTED_1, hint='Sum (a − e) × ln(a ÷ e) over the bins.')


# ---- Challenge 2: Validate a row ----
# Count the fields that are missing or not numbers.
row = {"income": 50.0, "debt": None, "age": "40"}
fields = ["income", "debt", "age"]
bad = 0  # ← count the fields that fail the check
check(bad, EXPECTED_2, hint="Check each field's type with isinstance and count the failures.")
