"""Lesson 8 coding challenges. Each block has ONE missing line marked "your code here" or "replace".
Write the line, run this file, and each check prints ✅ or a hint.  Solutions: the SOLUTIONS list in tests/test_code.py
"""
# Checker used by the challenges below — run this cell first.
import numpy as np
def check(got, want, hint='', atol=1e-6):
    try:
        ok = got is not None and np.shape(got) == np.shape(want) and np.allclose(np.asarray(got, dtype=float), np.asarray(want, dtype=float), rtol=1e-4, atol=atol)
    except Exception:
        ok = False
    print('✅ Correct!' if ok else '❌ Not yet. Hint: ' + hint)

EXPECTED_1 = [0.11920292202211755, 0.5, 0.8175744761936437]
EXPECTED_2 = 0.3375388286260044


# ---- Challenge 1: The sigmoid ----
# Write the sigmoid so it works on whole arrays.
import numpy as np
z = np.array([-2.0, 0.0, 1.5])
p = None  # ← your code here
check(p, EXPECTED_1, hint='σ(z) = 1 / (1 + e^(−z)); use np.exp.')


# ---- Challenge 2: Log loss ----
# Compute the average log loss for these predictions.
import numpy as np
y = np.array([1, 0, 1, 0])
p = np.array([0.9, 0.2, 0.6, 0.4])
loss = None  # ← your code here
check(loss, EXPECTED_2, hint='−mean(y·ln p + (1 − y)·ln(1 − p)).')
