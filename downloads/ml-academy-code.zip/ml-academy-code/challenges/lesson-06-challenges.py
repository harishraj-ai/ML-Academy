"""Lesson 6 coding challenges. Each block has ONE missing line marked "your code here" or "replace".
Write the line, run this file, and each check prints ✅ or a hint.  Solutions: the SOLUTIONS list in tests/test_code.py
"""
# Checker used by the challenges below — run this cell first.
import numpy as np
def check(got, want, hint='', atol=1e-6):
    try:
        ok = got is not None and np.shape(got) == np.shape(want) and np.allclose(np.asarray(got, dtype=float), np.asarray(want, dtype=float), rtol=1e-4, atol=atol)
    except Exception:
        ok = False
    print('✅ Correct!' if ok else '❌ Not yet. Hint: ' + hint)

EXPECTED_1 = 0.6
EXPECTED_2 = 0.6000000000000001


# ---- Challenge 1: The least-squares slope ----
# Compute the slope with the formula from the lesson.
import numpy as np
x = np.array([1, 2, 3, 4, 5.0]); y = np.array([2, 4, 5, 4, 5.0])
xm, ym = x.mean(), y.mean()
w = None  # ← your code here
check(w, EXPECTED_1, hint='w = Σ(x − x̄)(y − ȳ) / Σ(x − x̄)². It should be 0.6.')


# ---- Challenge 2: R² ----
# Compute R² for the predictions of the line ŷ = 0.6x + 2.2.
import numpy as np
x = np.array([1, 2, 3, 4, 5.0]); y = np.array([2, 4, 5, 4, 5.0])
y_hat = 0.6 * x + 2.2
ss_res = np.sum((y - y_hat) ** 2)
ss_tot = np.sum((y - y.mean()) ** 2)
r2 = None  # ← your code here
check(r2, EXPECTED_2, hint='1 − SS_res / SS_tot.')
