"""Lesson 2 coding challenges. Each block has ONE missing line marked "your code here" or "replace".
Write the line, run this file, and each check prints ✅ or a hint.  Solutions: the SOLUTIONS list in tests/test_code.py
"""
# Checker used by the challenges below — run this cell first.
import numpy as np
def check(got, want, hint='', atol=1e-6):
    try:
        ok = got is not None and np.shape(got) == np.shape(want) and np.allclose(np.asarray(got, dtype=float), np.asarray(want, dtype=float), rtol=1e-4, atol=atol)
    except Exception:
        ok = False
    print('✅ Correct!' if ok else '❌ Not yet. Hint: ' + hint)

EXPECTED_1 = 0.5962847939999439
EXPECTED_2 = [-1.5, -2.5, -3.5]


# ---- Challenge 1: Cosine similarity ----
# Compute the cosine of the angle between a and b.
import numpy as np
a = np.array([1.0, 2.0, 2.0])
b = np.array([2.0, 0.0, 1.0])
cos_sim = None  # ← your code here
check(cos_sim, EXPECTED_1, hint='Dot product divided by the product of the two lengths (np.linalg.norm).')


# ---- Challenge 2: Predictions for every row ----
# Compute the prediction X·w for all three examples in one line.
import numpy as np
X = np.array([[1, 2], [3, 4], [5, 6]])
w = np.array([0.5, -1.0])
preds = None  # ← your code here
check(preds, EXPECTED_2, hint='Matrix-vector product: X @ w.')
