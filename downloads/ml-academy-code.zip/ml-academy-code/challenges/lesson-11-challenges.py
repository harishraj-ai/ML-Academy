"""Lesson 11 coding challenges. Each block has ONE missing line marked "your code here" or "replace".
Write the line, run this file, and each check prints ✅ or a hint.  Solutions: the SOLUTIONS list in tests/test_code.py
"""
# Checker used by the challenges below — run this cell first.
import numpy as np
def check(got, want, hint='', atol=1e-6):
    try:
        ok = got is not None and np.shape(got) == np.shape(want) and np.allclose(np.asarray(got, dtype=float), np.asarray(want, dtype=float), rtol=1e-4, atol=atol)
    except Exception:
        ok = False
    print('✅ Correct!' if ok else '❌ Not yet. Hint: ' + hint)

EXPECTED_1 = [2.23606797749979, 1.0, 3.605551275463989, 4.242640687119285, 3.1622776601683795]
EXPECTED_2 = [1, 0, 4]


# ---- Challenge 1: Distances to every point ----
# Compute the Euclidean distance from q to each row of X in one line.
import numpy as np
X = np.array([[0, 0], [1, 1], [4, 4], [5, 4], [1, 4.0]])
q = np.array([2, 1.0])
d = None  # ← your code here
check(d, EXPECTED_1, hint='Subtract q from every row, square, sum along axis=1, square root.')


# ---- Challenge 2: Indices of the 3 nearest ----
# Find the indices of the 3 nearest points, nearest first.
import numpy as np
d = np.array([2.24, 1.0, 3.61, 4.24, 3.16])
nearest = None  # ← your code here
check(nearest, EXPECTED_2, hint='np.argsort gives the order from smallest to largest; keep the first 3.')
