"""Lesson 26 coding challenges. Each block has ONE missing line marked "your code here" or "replace".
Write the line, run this file, and each check prints ✅ or a hint.  Solutions: the SOLUTIONS list in tests/test_code.py
"""
# Checker used by the challenges below — run this cell first.
import numpy as np
def check(got, want, hint='', atol=1e-6):
    try:
        ok = got is not None and np.shape(got) == np.shape(want) and np.allclose(np.asarray(got, dtype=float), np.asarray(want, dtype=float), rtol=1e-4, atol=atol)
    except Exception:
        ok = False
    print('✅ Correct!' if ok else '❌ Not yet. Hint: ' + hint)

EXPECTED_1 = 2.0
EXPECTED_2 = [12.0, 14.0]


# ---- Challenge 1: The seasonal naive forecast ----
# Forecast each of the last 7 days with the value from 7 days earlier, and compute the MAE.
import numpy as np
y = np.array([50, 52, 49, 70, 75, 51, 53, 54, 51, 50, 72, 78, 50, 55])
actual = y[7:]
forecast = actual  # ← replace with the values from 7 days earlier
result = round(float(np.mean(np.abs(actual - forecast))), 2)
check(result, EXPECTED_1, hint='The forecast for day i is y[i - 7].')


# ---- Challenge 2: A past-only rolling mean ----
# Make a 3-day rolling mean that only uses days before each day (shift first).
import pandas as pd
s = pd.Series([10, 12, 14, 16, 18])
roll = s.rolling(3).mean()  # ← this includes the current day; fix it
result = roll.tolist()[3:]
check(result, EXPECTED_2, hint='Shift by one, then roll.')
