"""Lesson 23 coding challenges. Each block has ONE missing line marked "your code here" or "replace".
Write the line, run this file, and each check prints ✅ or a hint.  Solutions: the SOLUTIONS list in tests/test_code.py
"""
# Checker used by the challenges below — run this cell first.
import numpy as np
def check(got, want, hint='', atol=1e-6):
    try:
        ok = got is not None and np.shape(got) == np.shape(want) and np.allclose(np.asarray(got, dtype=float), np.asarray(want, dtype=float), rtol=1e-4, atol=atol)
    except Exception:
        ok = False
    print('✅ Correct!' if ok else '❌ Not yet. Hint: ' + hint)

EXPECTED_1 = 120
EXPECTED_2 = [0.001, 0.0056, 0.0316, 0.1778, 1.0]


# ---- Challenge 1: Count the grid ----
# Compute how many model fits a 5-fold grid search over this grid performs (not counting the refit).
grid = {"C": [0.1, 1, 10], "gamma": [0.01, 0.1, 1, 10], "kernel": ["rbf", "sigmoid"]}
folds = 5
fits = len(grid) * folds  # ← replace: count every combination
check(fits, EXPECTED_1, hint='Multiply the number of values of each hyperparameter, then by the number of folds.')


# ---- Challenge 2: Log-scale samples ----
# Draw 5 learning rates spread evenly on a log scale from 0.001 to 1.
import numpy as np
rates = np.linspace(0.001, 1, 5)  # ← replace with a log-spaced version
result = [round(float(v), 4) for v in rates]
check(result, EXPECTED_2, hint='np.logspace(start, stop, num) uses powers of ten: 10**-3 to 10**0.')
