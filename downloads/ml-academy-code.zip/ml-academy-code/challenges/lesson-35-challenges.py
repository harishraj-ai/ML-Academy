"""Lesson 35 coding challenges. Each block has ONE missing line marked "your code here" or "replace".
Write the line, run this file, and each check prints ✅ or a hint.  Solutions: the SOLUTIONS list in tests/test_code.py
"""
# Checker used by the challenges below — run this cell first.
import numpy as np
def check(got, want, hint='', atol=1e-6):
    try:
        ok = got is not None and np.shape(got) == np.shape(want) and np.allclose(np.asarray(got, dtype=float), np.asarray(want, dtype=float), rtol=1e-4, atol=atol)
    except Exception:
        ok = False
    print('✅ Correct!' if ok else '❌ Not yet. Hint: ' + hint)

EXPECTED_1 = 0.14035087719298245
EXPECTED_2 = [0.55, 0.45]


# ---- Challenge 1: Bayes in a two-node network ----
# Compute P(cause | effect).
p_cause = 0.02
p_eff_given_cause, p_eff_given_not = 0.8, 0.1
post = p_eff_given_cause  # ← apply Bayes' theorem
check(post, EXPECTED_1, hint='Prior × likelihood, divided by the total probability of the effect.')


# ---- Challenge 2: One step of a Markov chain ----
# Compute tomorrow's state probabilities.
import numpy as np
today = np.array([0.5, 0.5])
T = np.array([[0.9, 0.1], [0.2, 0.8]])
tomorrow = T @ today  # ← the row vector goes on the left
result = np.round(tomorrow, 2).tolist()
check(result, EXPECTED_2, hint='Multiply the row vector by the transition matrix.')
