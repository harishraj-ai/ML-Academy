"""Lesson 15 coding challenges. Each block has ONE missing line marked "your code here" or "replace".
Write the line, run this file, and each check prints ✅ or a hint.  Solutions: the SOLUTIONS list in tests/test_code.py
"""
# Checker used by the challenges below — run this cell first.
import numpy as np
def check(got, want, hint='', atol=1e-6):
    try:
        ok = got is not None and np.shape(got) == np.shape(want) and np.allclose(np.asarray(got, dtype=float), np.asarray(want, dtype=float), rtol=1e-4, atol=atol)
    except Exception:
        ok = False
    print('✅ Correct!' if ok else '❌ Not yet. Hint: ' + hint)

EXPECTED_1 = 0.4
EXPECTED_2 = 0.8


# ---- Challenge 1: Margin width ----
# Compute the margin of a linear SVM from its weight vector.
import numpy as np
w = np.array([3.0, 4.0])
margin = None  # ← your code here
check(margin, EXPECTED_1, hint='2 / ‖w‖.')


# ---- Challenge 2: Hinge loss ----
# Compute the average hinge loss for labels y (±1) and scores s.
import numpy as np
y = np.array([1, -1, 1, -1])
s = np.array([2.0, -0.5, 0.3, 1.0])
hinge = None  # ← your code here
check(hinge, EXPECTED_2, hint='max(0, 1 − y·s) for each point, then average.')
