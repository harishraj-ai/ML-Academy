"""Lesson 28 coding challenges. Each block has ONE missing line marked "your code here" or "replace".
Write the line, run this file, and each check prints ✅ or a hint.  Solutions: the SOLUTIONS list in tests/test_code.py
"""
# Checker used by the challenges below — run this cell first.
import numpy as np
def check(got, want, hint='', atol=1e-6):
    try:
        ok = got is not None and np.shape(got) == np.shape(want) and np.allclose(np.asarray(got, dtype=float), np.asarray(want, dtype=float), rtol=1e-4, atol=atol)
    except Exception:
        ok = False
    print('✅ Correct!' if ok else '❌ Not yet. Hint: ' + hint)

EXPECTED_1 = 0.6428571428571429
EXPECTED_2 = 0.2


# ---- Challenge 1: A Beta posterior ----
# Update a Beta(2, 2) prior with 7 successes and 3 failures, and compute the posterior mean.
a, b = 2, 2
s, f = 7, 3
mean = s / (s + f)  # ← that ignores the prior
check(mean, EXPECTED_1, hint='The posterior is Beta(a + s, b + f); its mean is a′/(a′ + b′).')


# ---- Challenge 2: A Metropolis acceptance ----
# Compute the acceptance probability for a proposal.
current, proposal = 0.25, 0.05
accept = proposal  # ← use the ratio, capped at 1
check(accept, EXPECTED_2, hint='Ratio of densities, capped at 1.')
