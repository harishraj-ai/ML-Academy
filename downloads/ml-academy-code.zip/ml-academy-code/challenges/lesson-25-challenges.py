"""Lesson 25 coding challenges. Each block has ONE missing line marked "your code here" or "replace".
Write the line, run this file, and each check prints ✅ or a hint.  Solutions: the SOLUTIONS list in tests/test_code.py
"""
# Checker used by the challenges below — run this cell first.
import numpy as np
def check(got, want, hint='', atol=1e-6):
    try:
        ok = got is not None and np.shape(got) == np.shape(want) and np.allclose(np.asarray(got, dtype=float), np.asarray(want, dtype=float), rtol=1e-4, atol=atol)
    except Exception:
        ok = False
    print('✅ Correct!' if ok else '❌ Not yet. Hint: ' + hint)

EXPECTED_1 = 0.6
EXPECTED_2 = [30]


# ---- Challenge 1: Recall and precision from counts ----
# A detector flags 30 cases, 12 of which are real anomalies, out of 20 anomalies in total. Compute recall.
flagged, true_in_flagged, total_anomalies = 30, 12, 20
recall = true_in_flagged / flagged  # ← that is precision; compute recall
check(recall, EXPECTED_1, hint='Recall is caught anomalies divided by all anomalies.')


# ---- Challenge 2: A z-score detector ----
# Flag the values whose z-score is above 2 in absolute value.
import numpy as np
x = np.array([10, 11, 9, 10, 12, 30, 10, 11])
z = (x - x.mean()) / x.std()
flags = z > 100  # ← replace with the right condition
result = x[flags].tolist()
check(result, EXPECTED_2, hint='Compare the absolute z-score with 2.')
