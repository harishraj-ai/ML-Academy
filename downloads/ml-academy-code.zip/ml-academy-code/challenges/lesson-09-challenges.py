"""Lesson 9 coding challenges. Each block has ONE missing line marked "your code here" or "replace".
Write the line, run this file, and each check prints ✅ or a hint.  Solutions: the SOLUTIONS list in tests/test_code.py
"""
# Checker used by the challenges below — run this cell first.
import numpy as np
def check(got, want, hint='', atol=1e-6):
    try:
        ok = got is not None and np.shape(got) == np.shape(want) and np.allclose(np.asarray(got, dtype=float), np.asarray(want, dtype=float), rtol=1e-4, atol=atol)
    except Exception:
        ok = False
    print('✅ Correct!' if ok else '❌ Not yet. Hint: ' + hint)

EXPECTED_1 = 0.8
EXPECTED_2 = 0.7272727272727272


# ---- Challenge 1: Precision ----
# Compute the precision from the confusion-matrix counts.
tp, fp, fn, tn = 40, 10, 20, 130
precision = None  # ← your code here
check(precision, EXPECTED_1, hint='Of everything flagged positive (TP + FP), how much was right?')


# ---- Challenge 2: F1 score ----
# Combine precision and recall into the F1 score.
precision, recall = 0.8, 2 / 3
f1 = None  # ← your code here
check(f1, EXPECTED_2, hint='The harmonic mean: 2PR / (P + R).')
