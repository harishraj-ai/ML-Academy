"""Lesson 34 coding challenges. Each block has ONE missing line marked "your code here" or "replace".
Write the line, run this file, and each check prints ✅ or a hint.  Solutions: the SOLUTIONS list in tests/test_code.py
"""
# Checker used by the challenges below — run this cell first.
import numpy as np
def check(got, want, hint='', atol=1e-6):
    try:
        ok = got is not None and np.shape(got) == np.shape(want) and np.allclose(np.asarray(got, dtype=float), np.asarray(want, dtype=float), rtol=1e-4, atol=atol)
    except Exception:
        ok = False
    print('✅ Correct!' if ok else '❌ Not yet. Hint: ' + hint)

EXPECTED_1 = [2, 1, 1]
EXPECTED_2 = 2


# ---- Challenge 1: Degrees from an adjacency matrix ----
# Compute each node's degree.
import numpy as np
A = np.array([[0, 1, 1], [1, 0, 0], [1, 0, 0]])
deg = A.sum()  # ← sum per row, not overall
result = deg.tolist()
check(result, EXPECTED_1, hint='Sum each row.')


# ---- Challenge 2: Common neighbours ----
# Count the neighbours that nodes 1 and 2 share.
import numpy as np
A = np.array([[0, 1, 1, 1], [1, 0, 1, 1], [1, 1, 0, 1], [1, 1, 1, 0]])
common = int(A[1].sum())  # ← count only shared neighbours
check(common, EXPECTED_2, hint='Combine the two rows with & and count.')
