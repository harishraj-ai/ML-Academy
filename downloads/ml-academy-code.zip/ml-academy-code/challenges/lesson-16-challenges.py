"""Lesson 16 coding challenges. Each block has ONE missing line marked "your code here" or "replace".
Write the line, run this file, and each check prints ✅ or a hint.  Solutions: the SOLUTIONS list in tests/test_code.py
"""
# Checker used by the challenges below — run this cell first.
import numpy as np
def check(got, want, hint='', atol=1e-6):
    try:
        ok = got is not None and np.shape(got) == np.shape(want) and np.allclose(np.asarray(got, dtype=float), np.asarray(want, dtype=float), rtol=1e-4, atol=atol)
    except Exception:
        ok = False
    print('✅ Correct!' if ok else '❌ Not yet. Hint: ' + hint)

EXPECTED_1 = [0, 0, 1, 1, 1]
EXPECTED_2 = [1.5, 7.0]


# ---- Challenge 1: The assign step ----
# Give each point the index of its nearest centroid (1D).
import numpy as np
x = np.array([1, 2, 6, 7, 8.0])
centroids = np.array([1.0, 8.0])
labels = None  # ← your code here
check(labels, EXPECTED_1, hint='Build a points × centroids table of distances, then argmin along axis=1.')


# ---- Challenge 2: The update step ----
# Move each centroid to the mean of its points.
import numpy as np
x = np.array([1, 2, 6, 7, 8.0])
labels = np.array([0, 0, 1, 1, 1])
new_centroids = None  # ← your code here
check(new_centroids, EXPECTED_2, hint='For each cluster k, average x[labels == k].')
