"""Lesson 7 coding challenges. Each block has ONE missing line marked "your code here" or "replace".
Write the line, run this file, and each check prints ✅ or a hint.  Solutions: the SOLUTIONS list in tests/test_code.py
"""
# Checker used by the challenges below — run this cell first.
import numpy as np
def check(got, want, hint='', atol=1e-6):
    try:
        ok = got is not None and np.shape(got) == np.shape(want) and np.allclose(np.asarray(got, dtype=float), np.asarray(want, dtype=float), rtol=1e-4, atol=atol)
    except Exception:
        ok = False
    print('✅ Correct!' if ok else '❌ Not yet. Hint: ' + hint)

EXPECTED_1 = -26.4
EXPECTED_2 = 0.6000000206173624


# ---- Challenge 1: The gradient of the MSE ----
# Compute ∂L/∂w for the model ŷ = wx + b at w = 0, b = 0.
import numpy as np
x = np.array([1, 2, 3, 4, 5.0]); y = np.array([2, 4, 5, 4, 5.0])
w, b = 0.0, 0.0
err = w * x + b - y
grad_w = None  # ← your code here
check(grad_w, EXPECTED_1, hint="2 × mean(error × x). The lesson's worked example gives −26.4.")


# ---- Challenge 2: The update rule ----
# Complete the loop so it runs 1000 steps of gradient descent. w should end near 0.6.
import numpy as np
x = np.array([1, 2, 3, 4, 5.0]); y = np.array([2, 4, 5, 4, 5.0])
w, b, lr = 0.0, 0.0, 0.05
for step in range(1000):
    err = w * x + b - y
    grad_w, grad_b = 2 * np.mean(err * x), 2 * np.mean(err)
    pass  # ← your code here: update w
    b = b - lr * grad_b
w_final = w
check(w_final, EXPECTED_2, hint='Mirror the line for b: w = w - lr * grad_w.')
