"""Lesson 21 coding challenges. Each block has ONE missing line marked "your code here" or "replace".
Write the line, run this file, and each check prints ✅ or a hint.  Solutions: the SOLUTIONS list in tests/test_code.py
"""
# Checker used by the challenges below — run this cell first.
import numpy as np
def check(got, want, hint='', atol=1e-6):
    try:
        ok = got is not None and np.shape(got) == np.shape(want) and np.allclose(np.asarray(got, dtype=float), np.asarray(want, dtype=float), rtol=1e-4, atol=atol)
    except Exception:
        ok = False
    print('✅ Correct!' if ok else '❌ Not yet. Hint: ' + hint)

EXPECTED_1 = 0.333
EXPECTED_2 = 0.75


# ---- Challenge 1: Selection rate per group ----
# Compute the share of applicants approved in each group.
import pandas as pd
df = pd.DataFrame({"group": ["A", "A", "A", "A", "B", "B", "B", "B"], "approved": [1, 1, 0, 1, 0, 1, 0, 0]})
rates = df["approved"]  # ← replace with the per-group mean
ratio = round(rates.min() / rates.max(), 3)
check(ratio, EXPECTED_1, hint='Group by the group column and take the mean of the 0/1 approval column.')


# ---- Challenge 2: True-positive rate for one group ----
# Compute the TPR: approved repayers divided by all repayers.
import numpy as np
repay = np.array([1, 1, 1, 1, 0, 0, 0, 0, 0, 0])
approve = np.array([1, 1, 1, 0, 1, 0, 0, 0, 0, 0])
tpr = approve.mean()  # ← replace: only count people who would repay
check(tpr, EXPECTED_2, hint='Look only at people with repay == 1 and take the share approved.')
