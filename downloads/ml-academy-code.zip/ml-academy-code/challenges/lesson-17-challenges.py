"""Lesson 17 coding challenges. Each block has ONE missing line marked "your code here" or "replace".
Write the line, run this file, and each check prints ✅ or a hint.  Solutions: the SOLUTIONS list in tests/test_code.py
"""
# Checker used by the challenges below — run this cell first.
import numpy as np
def check(got, want, hint='', atol=1e-6):
    try:
        ok = got is not None and np.shape(got) == np.shape(want) and np.allclose(np.asarray(got, dtype=float), np.asarray(want, dtype=float), rtol=1e-4, atol=atol)
    except Exception:
        ok = False
    print('✅ Correct!' if ok else '❌ Not yet. Hint: ' + hint)

EXPECTED_1 = [[0.0, -2.0], [-2.0, 0.0], [2.0, 2.0]]
EXPECTED_2 = [0.5, 0.25, 0.125, 0.0625, 0.0625]


# ---- Challenge 1: Centre the data ----
# Subtract each column's mean.
import numpy as np
X = np.array([[2, 0], [0, 2], [4, 4.0]])
Xc = None  # ← your code here
check(Xc, EXPECTED_1, hint='X.mean(axis=0) gives the column means; subtract them.')


# ---- Challenge 2: Explained variance ratio ----
# Turn the eigenvalues into the share of variance each component explains.
import numpy as np
eigenvalues = np.array([8.0, 4.0, 2.0, 1.0, 1.0])
ratio = None  # ← your code here
check(ratio, EXPECTED_2, hint='Each eigenvalue divided by their total.')
