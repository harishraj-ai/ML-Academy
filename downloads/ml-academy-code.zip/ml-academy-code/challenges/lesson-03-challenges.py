"""Lesson 3 coding challenges. Each block has ONE missing line marked "your code here" or "replace".
Write the line, run this file, and each check prints ✅ or a hint.  Solutions: the SOLUTIONS list in tests/test_code.py
"""
# Checker used by the challenges below — run this cell first.
import numpy as np
def check(got, want, hint='', atol=1e-6):
    try:
        ok = got is not None and np.shape(got) == np.shape(want) and np.allclose(np.asarray(got, dtype=float), np.asarray(want, dtype=float), rtol=1e-4, atol=atol)
    except Exception:
        ok = False
    print('✅ Correct!' if ok else '❌ Not yet. Hint: ' + hint)

EXPECTED_1 = 6.000001000927568
EXPECTED_2 = 2.0


# ---- Challenge 1: Numerical derivative ----
# Estimate the slope of f(x) = x² at x = 3 with a tiny step h.
def f(x):
    return x ** 2
h = 1e-6
slope = None  # ← your code here
check(slope, EXPECTED_1, hint='Rise over run: (f(3 + h) - f(3)) / h. It should be close to 6.')


# ---- Challenge 2: One gradient descent step ----
# L(w) = (w − 4)². Take one step from w = 0 with learning rate 0.25.
w, lr = 0.0, 0.25
grad = 2 * (w - 4)
w_new = None  # ← your code here
check(w_new, EXPECTED_2, hint='Move against the gradient: w - lr * grad.')
