"""Lesson 14 coding challenges. Each block has ONE missing line marked "your code here" or "replace".
Write the line, run this file, and each check prints ✅ or a hint.  Solutions: the SOLUTIONS list in tests/test_code.py
"""
# Checker used by the challenges below — run this cell first.
import numpy as np
def check(got, want, hint='', atol=1e-6):
    try:
        ok = got is not None and np.shape(got) == np.shape(want) and np.allclose(np.asarray(got, dtype=float), np.asarray(want, dtype=float), rtol=1e-4, atol=atol)
    except Exception:
        ok = False
    print('✅ Correct!' if ok else '❌ Not yet. Hint: ' + hint)

EXPECTED_1 = 0.7839999999999999
EXPECTED_2 = 0.622


# ---- Challenge 1: Majority vote ----
# Three independent models are each 70% accurate. Compute the accuracy of their majority vote.
p = 0.7
vote = None  # ← your code here
check(vote, EXPECTED_1, hint='All three right, plus exactly two right (3 ways).')


# ---- Challenge 2: A bootstrap sample ----
# Draw a bootstrap sample of indices (with replacement) and measure the share of distinct rows it contains.
import numpy as np
rng = np.random.default_rng(0)
n = 1000
idx = np.arange(n)  # ← replace: this takes every row exactly once, not a bootstrap sample
share_unique = len(np.unique(idx)) / n
check(share_unique, EXPECTED_2, hint='rng.integers(0, n, size=n) draws n indices with replacement. Expect about 63%.')
