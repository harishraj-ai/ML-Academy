"""Lesson 18 coding challenges. Each block has ONE missing line marked "your code here" or "replace".
Write the line, run this file, and each check prints ✅ or a hint.  Solutions: the SOLUTIONS list in tests/test_code.py
"""
# Checker used by the challenges below — run this cell first.
import numpy as np
def check(got, want, hint='', atol=1e-6):
    try:
        ok = got is not None and np.shape(got) == np.shape(want) and np.allclose(np.asarray(got, dtype=float), np.asarray(want, dtype=float), rtol=1e-4, atol=atol)
    except Exception:
        ok = False
    print('✅ Correct!' if ok else '❌ Not yet. Hint: ' + hint)

EXPECTED_1 = [0.0, 0.0, 3.5]
EXPECTED_2 = 0.5609254179424822


# ---- Challenge 1: ReLU ----
# Apply ReLU to every value.
import numpy as np
z = np.array([-2.0, 0.0, 3.5])
h = None  # ← your code here
check(h, EXPECTED_1, hint='np.maximum(0, z) keeps positives and turns negatives into 0.')


# ---- Challenge 2: A forward pass ----
# Finish the 2-2-1 network from the lesson: compute the output probability p.
import numpy as np
sigmoid = lambda z: 1 / (1 + np.exp(-z))
x = np.array([1.0, 0.0])
W = np.array([[0.5, 0.3], [-0.5, 0.8]])
v = np.array([1.0, -1.0])
h = sigmoid(W @ x)
p = None  # ← your code here
check(p, EXPECTED_2, hint='The output neuron: sigmoid of v · h. The lesson gets 0.5609.')
