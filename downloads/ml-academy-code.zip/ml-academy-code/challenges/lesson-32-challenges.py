"""Lesson 32 coding challenges. Each block has ONE missing line marked "your code here" or "replace".
Write the line, run this file, and each check prints ✅ or a hint.  Solutions: the SOLUTIONS list in tests/test_code.py
"""
# Checker used by the challenges below — run this cell first.
import numpy as np
def check(got, want, hint='', atol=1e-6):
    try:
        ok = got is not None and np.shape(got) == np.shape(want) and np.allclose(np.asarray(got, dtype=float), np.asarray(want, dtype=float), rtol=1e-4, atol=atol)
    except Exception:
        ok = False
    print('✅ Correct!' if ok else '❌ Not yet. Hint: ' + hint)

EXPECTED_1 = 0.1
EXPECTED_2 = 1


# ---- Challenge 1: Margin uncertainty ----
# Compute the margin between the two highest probabilities.
import numpy as np
p = np.array([0.2, 0.45, 0.35])
margin = p.max()  # ← subtract the second-highest probability
check(margin, EXPECTED_1, hint='Sort descending, then subtract the second from the first.')


# ---- Challenge 2: Pick the most uncertain ----
# Return the index of the row with the smallest margin.
import numpy as np
P = np.array([[0.9, 0.1], [0.55, 0.45], [0.7, 0.3]])
pick = int(np.argmax(P[:, 0]))  # ← that is the most confident
check(pick, EXPECTED_2, hint='The margin is the gap between the two probabilities; take the argmin.')
