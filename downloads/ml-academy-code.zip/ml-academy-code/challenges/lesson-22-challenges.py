"""Lesson 22 coding challenges. Each block has ONE missing line marked "your code here" or "replace".
Write the line, run this file, and each check prints ✅ or a hint.  Solutions: the SOLUTIONS list in tests/test_code.py
"""
# Checker used by the challenges below — run this cell first.
import numpy as np
def check(got, want, hint='', atol=1e-6):
    try:
        ok = got is not None and np.shape(got) == np.shape(want) and np.allclose(np.asarray(got, dtype=float), np.asarray(want, dtype=float), rtol=1e-4, atol=atol)
    except Exception:
        ok = False
    print('✅ Correct!' if ok else '❌ Not yet. Hint: ' + hint)

EXPECTED_1 = [15.0, 40.0]
EXPECTED_2 = [2.0, 0.0, 1.0, 0.0]


# ---- Challenge 1: Average price per area with SQL ----
# Complete the query so it returns the average price of each area.
import sqlite3
import pandas as pd
con = sqlite3.connect(":memory:")
pd.DataFrame({"area": ["A", "A", "B", "B", "B"], "price": [10, 20, 30, 40, 50]}).to_sql("t", con, index=False)
q = "SELECT area, price AS avg_price FROM t"  # ← replace with a GROUP BY query
result = pd.read_sql(q, con)["avg_price"].round(2).tolist()
check(result, EXPECTED_1, hint='SELECT the area and AVG(price) AS avg_price, then GROUP BY area (and ORDER BY area).')


# ---- Challenge 2: A left join in pandas ----
# Merge the counts onto every customer, keeping customers with no orders, and fill their count with 0.
import pandas as pd
customers = pd.DataFrame({"id": [1, 2, 3, 4]})
orders = pd.DataFrame({"customer_id": [1, 1, 3]})
counts = orders.groupby("customer_id").size().rename("n").reset_index()
merged = customers.merge(counts, left_on="id", right_on="customer_id")  # ← keep every customer
result = merged["n"].tolist()
check(result, EXPECTED_2, hint='Use how="left" and fill missing counts with 0.')
