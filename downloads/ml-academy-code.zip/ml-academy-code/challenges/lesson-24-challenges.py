"""Lesson 24 coding challenges. Each block has ONE missing line marked "your code here" or "replace".
Write the line, run this file, and each check prints ✅ or a hint.  Solutions: the SOLUTIONS list in tests/test_code.py
"""
# Checker used by the challenges below — run this cell first.
import numpy as np
def check(got, want, hint='', atol=1e-6):
    try:
        ok = got is not None and np.shape(got) == np.shape(want) and np.allclose(np.asarray(got, dtype=float), np.asarray(want, dtype=float), rtol=1e-4, atol=atol)
    except Exception:
        ok = False
    print('✅ Correct!' if ok else '❌ Not yet. Hint: ' + hint)

EXPECTED_1 = 17.3
EXPECTED_2 = 4.0


# ---- Challenge 1: Permutation importance by hand ----
# Shuffle one column and measure how much the score drops.
import numpy as np
rng = np.random.default_rng(0)
X = rng.normal(size=(500, 2)); y = 3 * X[:, 0] + 0.1 * rng.normal(size=500)
w = np.array([3.0, 0.0])
score = lambda X: -np.mean((X @ w - y) ** 2)
Xp = X.copy(); Xp[:, 0] = rng.permutation(Xp[:, 0])
drop = score(X)  # ← replace: subtract the shuffled score
result = round(float(drop), 1)
check(result, EXPECTED_1, hint='Original score minus the score with feature 0 shuffled.')


# ---- Challenge 2: Shapley values for two features ----
# For f(a, b) = 2a + 4ab at (1, 1) with baseline (0, 0), compute a's Shapley value as the average of its two marginal contributions.
f = lambda a, b: 2 * a + 4 * a * b
phi_a = f(1, 1)  # ← replace with the average marginal contribution
check(phi_a, EXPECTED_2, hint='a joins first (adds f(1,0) − f(0,0)) or second (adds f(1,1) − f(0,1)); average the two.')
