"""Lesson 5 coding challenges. Each block has ONE missing line marked "your code here" or "replace".
Write the line, run this file, and each check prints ✅ or a hint.  Solutions: the SOLUTIONS list in tests/test_code.py
"""
# Checker used by the challenges below — run this cell first.
import numpy as np
def check(got, want, hint='', atol=1e-6):
    try:
        ok = got is not None and np.shape(got) == np.shape(want) and np.allclose(np.asarray(got, dtype=float), np.asarray(want, dtype=float), rtol=1e-4, atol=atol)
    except Exception:
        ok = False
    print('✅ Correct!' if ok else '❌ Not yet. Hint: ' + hint)

EXPECTED_1 = 10
EXPECTED_2 = 0.9733333333333334


# ---- Challenge 1: Hold out a test set ----
# Split the 40 examples so that 25% go to the test set (use random_state=0).
import numpy as np
from sklearn.model_selection import train_test_split
X = np.arange(80).reshape(40, 2); y = np.arange(40) % 2
X_train, X_test, y_train, y_test = X, X, y, y  # ← replace: this 'split' keeps everything in both sets
n_test = len(X_test)
check(n_test, EXPECTED_1, hint='train_test_split(X, y, test_size=0.25, random_state=0) returns four arrays.')


# ---- Challenge 2: Cross-validation ----
# Get the mean 5-fold cross-validated accuracy of logistic regression on the iris data.
from sklearn.datasets import load_iris
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import cross_val_score
X, y = load_iris(return_X_y=True)
scores = cross_val_score(LogisticRegression(max_iter=1000), X, y, cv=5)
mean_acc = None  # ← your code here
check(mean_acc, EXPECTED_2, hint='scores is an array of five accuracies; average it.')
