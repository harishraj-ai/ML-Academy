"""Lesson 13 coding challenges. Each block has ONE missing line marked "your code here" or "replace".
Write the line, run this file, and each check prints ✅ or a hint.  Solutions: the SOLUTIONS list in tests/test_code.py
"""
# Checker used by the challenges below — run this cell first.
import numpy as np
def check(got, want, hint='', atol=1e-6):
    try:
        ok = got is not None and np.shape(got) == np.shape(want) and np.allclose(np.asarray(got, dtype=float), np.asarray(want, dtype=float), rtol=1e-4, atol=atol)
    except Exception:
        ok = False
    print('✅ Correct!' if ok else '❌ Not yet. Hint: ' + hint)

EXPECTED_1 = 0.375
EXPECTED_2 = 0.32


# ---- Challenge 1: Gini impurity ----
# Compute the Gini impurity of a node from its class counts.
import numpy as np
counts = np.array([3, 1])
p = counts / counts.sum()
gini = None  # ← your code here
check(gini, EXPECTED_1, hint='1 − Σ p².')


# ---- Challenge 2: Weighted impurity after a split ----
# Combine the two children's Gini values, weighted by their sizes.
n_left, g_left = 5, 0.32
n_right, g_right = 5, 0.32
weighted = None  # ← your code here
check(weighted, EXPECTED_2, hint="Each child's Gini times its share of the examples.")
