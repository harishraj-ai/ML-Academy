"""Lesson 4 coding challenges. Each block has ONE missing line marked "your code here" or "replace".
Write the line, run this file, and each check prints ✅ or a hint.  Solutions: the SOLUTIONS list in tests/test_code.py
"""
# Checker used by the challenges below — run this cell first.
import numpy as np
def check(got, want, hint='', atol=1e-6):
    try:
        ok = got is not None and np.shape(got) == np.shape(want) and np.allclose(np.asarray(got, dtype=float), np.asarray(want, dtype=float), rtol=1e-4, atol=atol)
    except Exception:
        ok = False
    print('✅ Correct!' if ok else '❌ Not yet. Hint: ' + hint)

EXPECTED_1 = 2.0
EXPECTED_2 = 0.15384615384615385


# ---- Challenge 1: Standard deviation by hand ----
# Compute the standard deviation (divide by n) without np.std.
import numpy as np
x = np.array([2, 4, 4, 4, 5, 5, 7, 9])
m = x.mean()
sd = None  # ← your code here
check(sd, EXPECTED_1, hint='Square root of the average squared deviation from the mean.')


# ---- Challenge 2: Bayes' rule ----
# 1% have a disease. The test catches 90% of cases and gives 5% false positives. Compute P(disease | positive).
p_d, p_pos_d, p_pos_h = 0.01, 0.90, 0.05
p_pos = p_pos_d * p_d + p_pos_h * (1 - p_d)
posterior = None  # ← your code here
check(posterior, EXPECTED_2, hint="P(+|disease)·P(disease) / P(+). (It's only about 15%!)")
