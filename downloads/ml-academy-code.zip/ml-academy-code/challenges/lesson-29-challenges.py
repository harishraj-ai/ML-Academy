"""Lesson 29 coding challenges. Each block has ONE missing line marked "your code here" or "replace".
Write the line, run this file, and each check prints ✅ or a hint.  Solutions: the SOLUTIONS list in tests/test_code.py
"""
# Checker used by the challenges below — run this cell first.
import numpy as np
def check(got, want, hint='', atol=1e-6):
    try:
        ok = got is not None and np.shape(got) == np.shape(want) and np.allclose(np.asarray(got, dtype=float), np.asarray(want, dtype=float), rtol=1e-4, atol=atol)
    except Exception:
        ok = False
    print('✅ Correct!' if ok else '❌ Not yet. Hint: ' + hint)

EXPECTED_1 = 10.0
EXPECTED_2 = [1.25, 5.000000000000001, 4.0, 2.0]


# ---- Challenge 1: Difference-in-differences ----
# Compute the DiD estimate from the four group averages.
treated_before, treated_after = 50.0, 70.0
control_before, control_after = 48.0, 58.0
did = treated_after - treated_before  # ← subtract the control group's change
check(did, EXPECTED_1, hint="Subtract the control group's change from the treated group's change.")


# ---- Challenge 2: Inverse propensity weights ----
# Compute the weight for each person: 1/p if treated, 1/(1 − p) if not.
import numpy as np
t = np.array([1, 0, 1, 0])
p = np.array([0.8, 0.8, 0.25, 0.5])
w = 1 / p  # ← untreated people need 1 / (1 - p)
result = w.tolist()
check(result, EXPECTED_2, hint='Use np.where on the treatment flag.')
