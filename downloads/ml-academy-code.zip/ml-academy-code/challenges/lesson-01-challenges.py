"""Lesson 1 coding challenges. Each block has ONE missing line marked "your code here" or "replace".
Write the line, run this file, and each check prints ✅ or a hint.  Solutions: the SOLUTIONS list in tests/test_code.py
"""
# Checker used by the challenges below — run this cell first.
import numpy as np
def check(got, want, hint='', atol=1e-6):
    try:
        ok = got is not None and np.shape(got) == np.shape(want) and np.allclose(np.asarray(got, dtype=float), np.asarray(want, dtype=float), rtol=1e-4, atol=atol)
    except Exception:
        ok = False
    print('✅ Correct!' if ok else '❌ Not yet. Hint: ' + hint)

EXPECTED_1 = 0.5625
EXPECTED_2 = [1, 3, 5, 7, 9]


# ---- Challenge 1: Mean squared error ----
# Compute the MSE of the predictions: the average of the squared errors.
import numpy as np
y = np.array([3.0, 5.0, 7.0, 9.0])
y_hat = np.array([2.5, 5.0, 8.0, 8.0])
mse = None  # ← your code here
check(mse, EXPECTED_1, hint='Square the errors (y_hat - y) ** 2, then take np.mean.')


# ---- Challenge 2: Predict with a line ----
# The model is ŷ = 2x + 1. Compute the predictions for every x at once.
import numpy as np
x = np.array([0, 1, 2, 3, 4])
y_hat = None  # ← your code here
check(y_hat, EXPECTED_2, hint='NumPy applies arithmetic to the whole array: 2 * x + 1.')
