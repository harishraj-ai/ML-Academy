"""Lesson 33 coding challenges. Each block has ONE missing line marked "your code here" or "replace".
Write the line, run this file, and each check prints ✅ or a hint.  Solutions: the SOLUTIONS list in tests/test_code.py
"""
# Checker used by the challenges below — run this cell first.
import numpy as np
def check(got, want, hint='', atol=1e-6):
    try:
        ok = got is not None and np.shape(got) == np.shape(want) and np.allclose(np.asarray(got, dtype=float), np.asarray(want, dtype=float), rtol=1e-4, atol=atol)
    except Exception:
        ok = False
    print('✅ Correct!' if ok else '❌ Not yet. Hint: ' + hint)

EXPECTED_1 = 0.6400000000000001
EXPECTED_2 = 2.01


# ---- Challenge 1: A Kaplan–Meier step ----
# Multiply the survival by the share that survives this event time.
s, at_risk, events = 0.8, 10, 2
s_new = s - events  # ← multiply by the surviving share instead
check(s_new, EXPECTED_1, hint='Multiply by 1 − d/n.')


# ---- Challenge 2: A hazard ratio ----
# Convert a Cox coefficient to a hazard ratio, rounded to 2 decimals.
import math
beta = 0.7
hr = beta  # ← exponentiate
check(hr, EXPECTED_2, hint='The hazard ratio is e to the power of beta.')
