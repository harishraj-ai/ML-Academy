"""Lesson 19 coding challenges. Each block has ONE missing line marked "your code here" or "replace".
Write the line, run this file, and each check prints ✅ or a hint.  Solutions: the SOLUTIONS list in tests/test_code.py
"""
# Checker used by the challenges below — run this cell first.
import numpy as np
def check(got, want, hint='', atol=1e-6):
    try:
        ok = got is not None and np.shape(got) == np.shape(want) and np.allclose(np.asarray(got, dtype=float), np.asarray(want, dtype=float), rtol=1e-4, atol=atol)
    except Exception:
        ok = False
    print('✅ Correct!' if ok else '❌ Not yet. Hint: ' + hint)

EXPECTED_1 = 32
EXPECTED_2 = [0.6652409557748219, 0.09003057317038046, 0.24472847105479764]


# ---- Challenge 1: Convolution output size ----
# Compute the output width for input 32, kernel 5, padding 2, stride 1.
n, k, p, s = 32, 5, 2, 1
out = None  # ← your code here
check(out, EXPECTED_1, hint='(n − k + 2p) / s + 1.')


# ---- Challenge 2: Softmax ----
# Turn the attention scores into weights that sum to 1.
import numpy as np
scores = np.array([2.0, 0.0, 1.0])
weights = None  # ← your code here
check(weights, EXPECTED_2, hint='e^score divided by the sum of all e^score.')
