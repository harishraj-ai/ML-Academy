"""Lesson 27 coding challenges. Each block has ONE missing line marked "your code here" or "replace".
Write the line, run this file, and each check prints ✅ or a hint.  Solutions: the SOLUTIONS list in tests/test_code.py
"""
# Checker used by the challenges below — run this cell first.
import numpy as np
def check(got, want, hint='', atol=1e-6):
    try:
        ok = got is not None and np.shape(got) == np.shape(want) and np.allclose(np.asarray(got, dtype=float), np.asarray(want, dtype=float), rtol=1e-4, atol=atol)
    except Exception:
        ok = False
    print('✅ Correct!' if ok else '❌ Not yet. Hint: ' + hint)

EXPECTED_1 = 3.8000000000000003
EXPECTED_2 = 0.4


# ---- Challenge 1: A bias baseline ----
# Predict a rating as the global mean plus the item's and the user's deviations.
mu, item_avg, user_avg = 3.5, 4.2, 3.1
pred = mu  # ← add the item and user deviations
check(pred, EXPECTED_1, hint='Add each deviation from the global mean.')


# ---- Challenge 2: Precision at k ----
# Compute precision@5 for these recommendations.
recommended = [4, 9, 1, 7, 3]
liked = {1, 2, 3, 8}
result = len(liked) / 5  # ← count only the hits
check(result, EXPECTED_2, hint='Count recommended items that are in liked, divided by k.')
