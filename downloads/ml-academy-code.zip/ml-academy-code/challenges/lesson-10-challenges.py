"""Lesson 10 coding challenges. Each block has ONE missing line marked "your code here" or "replace".
Write the line, run this file, and each check prints ✅ or a hint.  Solutions: the SOLUTIONS list in tests/test_code.py
"""
# Checker used by the challenges below — run this cell first.
import numpy as np
def check(got, want, hint='', atol=1e-6):
    try:
        ok = got is not None and np.shape(got) == np.shape(want) and np.allclose(np.asarray(got, dtype=float), np.asarray(want, dtype=float), rtol=1e-4, atol=atol)
    except Exception:
        ok = False
    print('✅ Correct!' if ok else '❌ Not yet. Hint: ' + hint)

EXPECTED_1 = 2.0
EXPECTED_2 = 7


# ---- Challenge 1: Ridge by hand ----
# One feature, no intercept: compute the ridge weight for λ = 5.
sum_xy, sum_xx, lam = 50.0, 20.0, 5.0
w = None  # ← your code here
check(w, EXPECTED_1, hint='w = Σxy / (Σx² + λ).')


# ---- Challenge 2: Lasso switches features off ----
# Fit Lasso(alpha=1.0) and count how many weights are exactly zero.
import numpy as np
from sklearn.datasets import load_diabetes
from sklearn.linear_model import Lasso
X, y = load_diabetes(return_X_y=True)
model = Lasso(alpha=1.0).fit(X, y)
n_zero = None  # ← your code here
check(n_zero, EXPECTED_2, hint='Compare model.coef_ with 0 and count the True values.')
