"""Lesson 0 coding challenges. Each block has ONE missing line marked "your code here" or "replace".
Write the line, run this file, and each check prints ✅ or a hint.  Solutions: the SOLUTIONS list in tests/test_code.py
"""
from pathlib import Path
DATA = Path(__file__).resolve().parent.parent / "data"   # the course's data folder
# Checker used by the challenges below — run this cell first.
import numpy as np
def check(got, want, hint='', atol=1e-6):
    try:
        ok = got is not None and np.shape(got) == np.shape(want) and np.allclose(np.asarray(got, dtype=float), np.asarray(want, dtype=float), rtol=1e-4, atol=atol)
    except Exception:
        ok = False
    print('✅ Correct!' if ok else '❌ Not yet. Hint: ' + hint)

EXPECTED_1 = 75.8
EXPECTED_2 = 4


# ---- Challenge 1: Average with a loop ----
# Use a for-loop to add up the prices, then divide by how many there are.
prices = [58, 82, 55, 88, 96]
total = 0
for p in prices:
    total = total + p
average = None  # ← your code here
check(average, EXPECTED_1, hint='Divide the total by len(prices).')


# ---- Challenge 2: Filter a table ----
# Keep only the Central houses from the Chennai Homes data.
import pandas as pd
df = pd.read_csv(DATA / "houses.csv")
central = df  # ← replace: keep only rows where area is Central
n_central = len(central)
check(n_central, EXPECTED_2, hint='Put the condition df["area"] == "Central" inside df[...].')
